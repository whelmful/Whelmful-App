# Whelmful — Best Version App

A full GitHub-ready React + TypeScript app for Whelmful: an earthy, grown-up, interactive behaviour-change reflection app for all types of parents.

## What this build includes

- Earthy, tactile, grown-up Whelmful UI based on the approved concept direction
- Interactive landing page with 3D tilt app cards and particle CTA bursts
- Inclusive pathway onboarding for mums, dads/non-birthing parents, single parents, co-parents, FIFO/shift-work families, step-parents, and parents who do not want a label
- Full guided flow:
  1. Dump
  2. Share or keep private
  3. Body-Brain Translator
  4. Choice Point
  5. Tiny Move Commitment
  6. One Tiny Good Thing Lab
  7. Check-in
  8. Complete
- Embedded local Body-Brain Translator fallback model
- Supabase Edge Function scaffold for server-side AI translator
- Anonymous wall with honest starter notes and moderation states
- Opt-in patterns dashboard with non-clinical pattern tracking
- Saved notes and Whelmful path settings
- Resources, privacy and admin moderation pages
- Supabase migration and seeded starter notes

## Important scope

Whelmful provides general AI-supported reflection and behaviour-change tools. It does not provide therapy, diagnosis, treatment, crisis support, mental health monitoring, or emergency care.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL that Vite prints.

## Build

```bash
npm run build
```

## Supabase setup

The app works locally using browser storage and a safe translator fallback. To connect Supabase:

1. Create a Supabase project.
2. Run the migration in `supabase/migrations/001_whelmful.sql`.
3. Deploy functions in `supabase/functions`.
4. Copy `.env.example` to `.env` and fill in:

```bash
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
OPENAI_API_KEY=
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
ADMIN_MODERATION_SECRET=
```

Only `VITE_` variables are used by the frontend. Keep service keys and OpenAI key server-side.

## Design notes

The design intentionally avoids hearts, stars, sparkles, cute doodles, stock people and generic wellness UI. The visual system uses olive, cream, apricot, blush, lilac, butter, taped paper, noticeboard cards, editorial serif headings and tactile interactions.

## Translator model

The translator uses a combined behaviour-change model drawing privately from values, choice, self-compassion, protective parts language, body awareness, autonomic safety cues, attachment-informed repair, pattern recognition, identity flexibility and tiny committed action. The user-facing app does not name therapy modalities or make therapy claims.

## Wall ethics

Starter notes are labelled as `anonymous starter note`. Real submissions should only appear as `anonymous parent` after moderation. No fake usernames, fake dates, fake likes or fake community.
