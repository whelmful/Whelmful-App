import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const systemPrompt = `You are Whelmful's Body-Brain Translator. You are not a therapist, doctor, clinician, diagnostic tool, crisis worker, or emergency service. You provide general AI-supported behaviour-change reflection. Never diagnose, treat, monitor, assess, prevent, predict, manage or alleviate any condition. Translate a parent dump into: body clue, what is loud, what it might protect, what might be needed, what matters underneath, kinder sentence, old move, next move, tiny move. Never name ACT, CBT, IFS, EMDR, schema, somatic therapy, polyvagal, trauma response, vagus nerve, diagnosis, disorder, treatment, therapy, clinical, symptom, intervention, pathology, maladaptive, exposure. Return JSON only.`;

function fallback(text: string) {
  const urgent = /suicide|kill myself|hurt my baby|harm my child|i have a plan|self harm/i.test(text);
  if (urgent) {
    return {
      risk_level: 'urgent', public_wall_safe: false, publish_tier: 'blocked', translator: null, choice_point: null, tiny_move: null, anonymous_wall_version: null, tags: ['safety'],
      safety_message: 'I am really glad you put that into words. Because there is a chance someone could be hurt or unsafe, this needs real-life backup now. If you or someone else is in immediate danger, call Triple Zero now. For crisis support in Australia, contact Lifeline on 13 11 14. For perinatal mental health support, contact PANDA on 1300 726 306.'
    };
  }
  return {
    risk_level: 'low', public_wall_safe: true, publish_tier: 'safe_fast_queue',
    translator: {
      body_clue: 'Your body might be bracing because this has felt like too much for too long.',
      whats_loud: 'The pressure voice is trying to turn one hard moment into your whole identity.',
      what_it_might_be_protecting: 'It may be protecting you from judgement, rejection, or carrying the whole load alone.',
      what_you_might_need: 'You might need space, support, and a next step small enough to actually do.',
      what_matters_underneath: 'Under this, steadiness, care and repair still matter.',
      kinder_sentence: 'A hard moment is not my whole identity. I can own it and still choose one tiny move.'
    },
    choice_point: { old_move: 'pushing through until the feeling leaks out sideways', old_move_cost: 'It costs energy, connection and self-trust.', next_move: 'send one honest text asking for a check-in', why_this_move_fits: 'It is small, specific and points toward support instead of isolation.' },
    tiny_move: { move: 'send one honest text asking for a check-in', when: 'next_ten_minutes', where: 'wherever you are', smallest_version: 'open the message thread. that is enough for now.', category: 'support' },
    anonymous_wall_version: text.toLowerCase().slice(0, 180), tags: ['support', 'overload'], safety_message: null
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const body = await req.json();
    const dumpText = String(body.dump_text || '').trim();
    if (!dumpText) return new Response(JSON.stringify({ error: 'Missing dump_text' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const apiKey = Deno.env.get('OPENAI_API_KEY');
    if (!apiKey) return new Response(JSON.stringify(fallback(dumpText)), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: JSON.stringify({ dump_text: dumpText, share_intent: body.share_intent || 'undecided', parent_pathway: body.parent_pathway || 'just_overwhelmed' }) }
        ]
      })
    });
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    return new Response(content || JSON.stringify(fallback(dumpText)), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Translator failed safely' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
