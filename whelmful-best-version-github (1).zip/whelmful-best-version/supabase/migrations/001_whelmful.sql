create extension if not exists "pgcrypto";

create table if not exists anonymous_sessions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  consent_version text,
  data_tracking_consent boolean not null default false,
  deletion_code text not null default encode(gen_random_bytes(12), 'hex'),
  parent_pathway text default 'just_overwhelmed',
  selected_themes text[] default '{}',
  onboarding_completed boolean not null default false,
  preferred_language_style text default 'gentle_direct',
  avoid_gendered_language boolean not null default false
);

create table if not exists dumps (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  raw_text text not null,
  risk_level text not null check (risk_level in ('low','medium','high','urgent')),
  status text not null default 'private' check (status in ('private','pending_moderation','published','unsafe','deleted')),
  source text not null default 'user',
  deleted_at timestamptz
);

create table if not exists translations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  dump_id uuid references dumps(id) on delete cascade,
  body_clue text,
  whats_loud text,
  what_it_might_be_protecting text,
  what_you_might_need text,
  what_matters_underneath text,
  kinder_sentence text,
  dominant_body_brain_state text,
  dominant_pattern text,
  dominant_need text,
  dominant_value text,
  risk_level text not null check (risk_level in ('low','medium','high','urgent'))
);

create table if not exists choice_points (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  dump_id uuid references dumps(id) on delete cascade,
  old_move text,
  old_move_cost text,
  next_move text,
  why_this_move_fits text
);

create table if not exists tiny_moves (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  dump_id uuid references dumps(id) on delete cascade,
  move_text text,
  move_category text,
  commit_when text,
  commit_where text,
  confidence integer check (confidence between 1 and 5),
  smallest_version text,
  completed_status text check (completed_status in ('planned','tried','completed','shrunk','skipped')) default 'planned'
);

create table if not exists tiny_good_things (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  dump_id uuid references dumps(id) on delete cascade,
  text text not null,
  sensory_detail text,
  why_it_matters text
);

create table if not exists check_ins (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  dump_id uuid references dumps(id) on delete cascade,
  result text not null,
  shift_rating integer check (shift_rating between 0 and 5),
  learning text
);

create table if not exists wall_notes (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete set null,
  dump_id uuid references dumps(id) on delete set null,
  public_text text not null,
  original_public_text text,
  theme text,
  tags text[],
  pathway text,
  pathway_visible boolean not null default false,
  is_seeded boolean not null default false,
  label text not null default 'anonymous parent' check (label in ('anonymous starter note','common thought','anonymous parent')),
  publish_tier text not null default 'manual_review' check (publish_tier in ('safe_fast_queue','manual_review','blocked')),
  status text not null default 'pending_moderation' check (status in ('draft','fast_queue','pending_moderation','approved','published','rejected','unsafe','deleted')),
  support_count integer not null default 0,
  report_count integer not null default 0,
  risk_level text not null default 'low' check (risk_level in ('low','medium','high','urgent')),
  moderation_reason text,
  moderated_at timestamptz,
  moderator_notes text
);

create table if not exists wall_reports (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  wall_note_id uuid references wall_notes(id) on delete cascade,
  reason text not null,
  notes text
);

create table if not exists moderation_events (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  wall_note_id uuid references wall_notes(id) on delete cascade,
  action text not null,
  notes text
);

create table if not exists user_pattern_snapshots (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  session_id uuid references anonymous_sessions(id) on delete cascade,
  period_start timestamptz,
  period_end timestamptz,
  top_patterns text[],
  top_needs text[],
  top_values text[],
  top_body_brain_states text[],
  tiny_moves_tried integer not null default 0,
  tiny_moves_completed integer not null default 0,
  most_helpful_move_category text,
  summary_text text
);

alter table anonymous_sessions enable row level security;
alter table dumps enable row level security;
alter table translations enable row level security;
alter table choice_points enable row level security;
alter table tiny_moves enable row level security;
alter table tiny_good_things enable row level security;
alter table check_ins enable row level security;
alter table wall_notes enable row level security;
alter table wall_reports enable row level security;
alter table moderation_events enable row level security;
alter table user_pattern_snapshots enable row level security;

create policy "Public can read published wall notes" on wall_notes for select using (status = 'published');

insert into wall_notes (public_text, theme, tags, is_seeded, label, publish_tier, status, risk_level, support_count)
values
('i love my kids but omg i just want no one to need me for like five minutes', 'burnout', array['burnout','space'], true, 'anonymous starter note', 'safe_fast_queue', 'published', 'low', 0),
('the crying doesnt make me angry because i dont care. it makes me angry because im already cooked', 'rage', array['rage','overload'], true, 'anonymous starter note', 'manual_review', 'published', 'medium', 0),
('i miss who i was before i became the person who remembers everything for everyone', 'identity_loss', array['identity','mental load'], true, 'anonymous starter note', 'safe_fast_queue', 'published', 'low', 0),
('i dont feel bonded the way i thought i would and i hate admitting that', 'not_bonding', array['bonding','shame'], true, 'anonymous starter note', 'manual_review', 'published', 'medium', 0)
on conflict do nothing;
