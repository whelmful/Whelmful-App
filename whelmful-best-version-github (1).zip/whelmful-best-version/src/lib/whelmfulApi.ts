import type { ParentPathway } from '../types';
import { translateDumpLocally } from './brainTranslator';

export async function translateDump(payload: { text: string; pathway: ParentPathway; shareIntent?: 'wall' | 'private' | 'undecided' }) {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  if (supabaseUrl && anonKey) {
    try {
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, anonKey);
      const { data, error } = await supabase.functions.invoke('body-brain-translator', {
        body: { dump_text: payload.text, parent_pathway: payload.pathway, share_intent: payload.shareIntent ?? 'undecided' }
      });
      if (!error && data) return data;
    } catch {
      // Offline/local fallback below. This keeps the app usable before Supabase is connected.
    }
  }

  await new Promise((resolve) => setTimeout(resolve, 550));
  return translateDumpLocally(payload);
}
