import type { ParentPathway, RiskLevel, TranslatorResult } from '../types';

const safetyCopy = 'If you or someone else is in immediate danger, call Triple Zero now. For crisis support in Australia, contact Lifeline on 13 11 14. For perinatal mental health support, contact PANDA on 1300 726 306.';

const urgentPatterns = [
  /suicide|kill myself|end my life|i have a plan|take my life|hurt myself tonight|self harm|cut myself/i,
  /hurt my baby|shake my baby|harm my child|hurt my child|hurt someone|kill them|hit my child/i,
  /unsafe right now|in immediate danger|violence happening|abuse happening/i
];

const mediumPatterns = [
  /run away|disappear|scary thoughts|intrusive|drinking every night|wine every night|vaping|not bonded|dont feel bonded|regret becoming/i,
  /rage|snap|screamed|lost it|hate myself|body|birth|grief/i
];

function riskLevel(text: string): RiskLevel {
  if (urgentPatterns.some((p) => p.test(text))) return /plan|tonight|immediate|hurt my baby|hurt my child|kill|means/i.test(text) ? 'urgent' : 'high';
  if (mediumPatterns.some((p) => p.test(text))) return 'medium';
  return 'low';
}

function includesAny(text: string, words: string[]) {
  const lower = text.toLowerCase();
  return words.some((word) => lower.includes(word));
}

function classify(text: string, pathway: ParentPathway) {
  const lower = text.toLowerCase();
  let state = 'rulebook_mode';
  let pattern = 'self_criticism';
  let need = 'support';
  let value = 'steadiness';
  let oldMove = 'over-explaining or pushing through';

  if (includesAny(lower, ['angry', 'rage', 'snap', 'screamed', 'crying', 'furious'])) {
    state = 'alarm_mode'; pattern = 'rage'; need = 'space'; value = 'repair'; oldMove = 'snapping or bracing for impact';
  }
  if (includesAny(lower, ['guilty', 'guilt', 'terrible parent', 'bad parent', 'hate myself'])) {
    state = 'rulebook_mode'; pattern = 'shame_spiral'; need = 'repair_without_punishment'; value = 'kindness'; oldMove = 'turning one hard moment into your whole identity';
  }
  if (includesAny(lower, ['compare', 'online', 'everyone else', 'perfect mums', 'perfect parents'])) {
    state = 'rulebook_mode'; pattern = 'comparison'; need = 'self_trust'; value = 'belonging'; oldMove = 'using other people as instructions';
  }
  if (includesAny(lower, ['touched', 'body', 'need me', 'space', 'no one to touch'])) {
    state = 'protect_me_mode'; pattern = 'body_boundary'; need = 'space'; value = 'dignity'; oldMove = 'pulling away until no one can reach you';
  }
  if (includesAny(lower, ['partner', 'resent', 'switch off', 'invisible load', 'remember everything'])) {
    state = 'connection_mode'; pattern = 'resentment'; need = 'fairness'; value = 'honesty'; oldMove = 'swallowing the unfairness until it leaks out sideways';
  }
  if (includesAny(lower, ['bonded', 'bonding', 'stranger', 'baby feels'])) {
    state = 'connection_mode'; pattern = 'slow_bonding_shame'; need = 'gentleness'; value = 'connection'; oldMove = 'measuring real connection against a myth';
  }
  if (includesAny(lower, ['single', 'only backup', 'no one to hand it', 'whole backup plan'])) {
    state = 'protect_me_mode'; pattern = 'overfunctioning'; need = 'practical_help'; value = 'protection'; oldMove = 'being the whole safety net until your body goes flat';
  }
  if (pathway === 'dad_non_birthing_parent') {
    state = 'connection_mode'; pattern = pattern === 'self_criticism' ? 'feeling_outside_the_circle' : pattern; need = need === 'support' ? 'a_clear_way_in' : need; value = value === 'steadiness' ? 'connection' : value;
  }
  return { state, pattern, need, value, oldMove };
}

function wallVersion(text: string) {
  const cleaned = text
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, 'someone')
    .replace(/\b\d{3,}\b/g, 'a number')
    .replace(/\b[A-Z][a-z]+\b/g, (m) => (['I', 'Im'].includes(m) ? m : 'someone'))
    .trim();
  if (cleaned.length < 12) return 'some days the tiny thing is not tiny at all. it is the whole load.';
  return cleaned.length > 180 ? cleaned.slice(0, 177).trim() + '...' : cleaned;
}

export function translateDumpLocally(input: { text: string; pathway: ParentPathway; shareIntent?: 'wall' | 'private' | 'undecided' }): TranslatorResult {
  const risk = riskLevel(input.text);
  const map = classify(input.text, input.pathway);

  if (risk === 'high' || risk === 'urgent') {
    return {
      risk_level: risk,
      public_wall_safe: false,
      publish_tier: 'blocked',
      translator: null,
      choice_point: null,
      tiny_move: null,
      anonymous_wall_version: null,
      tags: ['safety'],
      safety_message: `I am really glad you put that into words. Because there is a chance someone could be hurt or unsafe, this needs real-life backup now. ${safetyCopy}`,
      internal_map: {
        dominant_body_brain_state: 'safety_escalation',
        dominant_pattern: 'safety_escalation',
        dominant_need: 'real_life_support',
        dominant_value: 'safety',
        old_move: 'trying to hold danger alone'
      }
    };
  }

  const bodyClue = map.state === 'alarm_mode'
    ? 'Your body might be bracing like something needs to be handled right now, even if the whole picture is not clear yet.'
    : map.state === 'protect_me_mode'
      ? 'Your body might be asking for distance, quiet, or fewer demands before it can make sense of anything.'
      : map.state === 'connection_mode'
        ? 'Your body might be carrying the ache of wanting closeness, fairness, or a clearer place to belong.'
        : 'Your body might be tightening around a rule that says you should be coping better than this.';

  const loud = map.pattern === 'comparison'
    ? 'The comparison voice is using someone else’s polished life as instructions for yours.'
    : map.pattern === 'rage'
      ? 'The alarm is loud and trying to get space before you run completely out.'
      : map.pattern === 'slow_bonding_shame'
        ? 'The shame voice is saying connection should have arrived instantly and beautifully.'
        : map.pattern === 'resentment'
          ? 'The fairness alarm is getting loud because something has felt unequal for too long.'
          : 'The pressure voice is trying to turn one hard moment into proof you are failing.';

  const protecting = map.need === 'space'
    ? 'It may be protecting your last tiny scrap of space.'
    : map.need === 'fairness'
      ? 'It may be protecting the part of you that knows the load has not been shared fairly.'
      : map.need === 'a_clear_way_in'
        ? 'It may be protecting you from feeling useless before you even get a chance to try.'
        : map.need === 'gentleness'
          ? 'It may be protecting you from being judged for a feeling that is arriving slowly.'
          : 'It may be trying to protect you from rejection, judgement, or the fear that you are not enough.';

  const need = map.need === 'repair_without_punishment'
    ? 'You might need repair without turning it into a full-night self-punishment session.'
    : map.need === 'practical_help'
      ? 'You might need real backup, not another reminder to be strong.'
      : map.need === 'a_clear_way_in'
        ? 'You might need one clear way to be useful, connected, and part of the moment.'
        : `You might need ${map.need.replace(/_/g, ' ')}, and permission to make the next step smaller.`;

  const value = map.value === 'repair'
    ? 'Under the guilt, repair still matters. That is not failure. That is care trying to find a way back.'
    : map.value === 'dignity'
      ? 'Under the overload, dignity matters: your body and time are not endless resources.'
      : `Under this, ${map.value.replace(/_/g, ' ')} still matters. That is the compass, not the shame.`;

  const nextMove = map.pattern === 'rage'
    ? 'Use one repair sentence, then stop punishing yourself for ten minutes.'
    : map.pattern === 'comparison'
      ? 'Mute one comparison trigger and choose one thing that fits your real day.'
      : map.pattern === 'resentment'
        ? 'Ask for one specific thing without listing every reason you deserve it.'
        : map.pattern === 'slow_bonding_shame'
          ? 'Notice one neutral thing about your child without forcing a feeling.'
          : map.need === 'a_clear_way_in'
            ? 'Do one useful thing and say, “I’m here. What is the next small thing?”'
            : 'Send one honest text asking for a check-in.';

  return {
    risk_level: risk,
    public_wall_safe: risk === 'low',
    publish_tier: risk === 'low' ? 'safe_fast_queue' : 'manual_review',
    translator: {
      body_clue: bodyClue,
      whats_loud: loud,
      what_it_might_be_protecting: protecting,
      what_you_might_need: need,
      what_matters_underneath: value,
      kinder_sentence: 'A hard moment is not my whole identity. I can own it and still choose one tiny move.'
    },
    choice_point: {
      old_move: map.oldMove,
      old_move_cost: 'It may protect you for a second, but it usually costs energy, connection, self-trust, or dignity.',
      next_move: nextMove,
      why_this_move_fits: 'It is small enough to try while you are tired, and it points toward the kind of parent or person you are trying to be.'
    },
    tiny_move: {
      move: nextMove,
      when: 'next_ten_minutes',
      where: 'wherever you are most likely to actually do it',
      smallest_version: nextMove.includes('text') ? 'Open the message thread. That is the move for now.' : 'Say it in your head first. That counts as making it smaller.',
      category: map.pattern === 'rage' ? 'repair' : map.pattern === 'comparison' ? 'boundary' : map.need === 'space' ? 'rest' : 'support'
    },
    anonymous_wall_version: input.shareIntent === 'wall' ? wallVersion(input.text.toLowerCase()) : wallVersion(input.text.toLowerCase()),
    tags: [map.pattern, map.need, map.value].map((x) => x.replace(/_/g, ' ')),
    safety_message: null,
    internal_map: {
      dominant_body_brain_state: map.state,
      dominant_pattern: map.pattern,
      dominant_need: map.need,
      dominant_value: map.value,
      old_move: map.oldMove
    }
  };
}
