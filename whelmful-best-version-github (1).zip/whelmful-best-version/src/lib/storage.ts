import { starterWallNotes } from '../data/content';
import type { FlowEntry, SessionProfile, WallNote } from '../types';

const SESSION_KEY = 'whelmful.session.v2';
const ENTRIES_KEY = 'whelmful.entries.v2';
const WALL_KEY = 'whelmful.wall.v2';

export function uid(prefix = 'id') {
  return `${prefix}-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
}

export function loadSession(): SessionProfile {
  const raw = localStorage.getItem(SESSION_KEY);
  if (raw) return JSON.parse(raw) as SessionProfile;
  const session: SessionProfile = {
    id: uid('session'),
    parentPathway: 'just_overwhelmed',
    selectedThemes: [],
    onboardingCompleted: false,
    dataTrackingConsent: false,
    avoidGenderedLanguage: false,
    createdAt: new Date().toISOString()
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function saveSession(session: SessionProfile) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function loadEntries(): FlowEntry[] {
  const raw = localStorage.getItem(ENTRIES_KEY);
  return raw ? JSON.parse(raw) as FlowEntry[] : [];
}

export function saveEntry(entry: FlowEntry) {
  const existing = loadEntries();
  localStorage.setItem(ENTRIES_KEY, JSON.stringify([entry, ...existing].slice(0, 80)));
}

export function deleteEntry(id: string) {
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(loadEntries().filter((entry) => entry.id !== id)));
}

export function loadWall(): WallNote[] {
  const raw = localStorage.getItem(WALL_KEY);
  if (!raw) {
    localStorage.setItem(WALL_KEY, JSON.stringify(starterWallNotes));
    return starterWallNotes;
  }
  return JSON.parse(raw) as WallNote[];
}

export function saveWall(notes: WallNote[]) {
  localStorage.setItem(WALL_KEY, JSON.stringify(notes));
}

export function addWallNote(note: WallNote) {
  const notes = loadWall();
  saveWall([note, ...notes]);
}

export function supportWallNote(id: string) {
  const notes = loadWall().map((note) => note.id === id ? { ...note, supportCount: note.supportCount + 1 } : note);
  saveWall(notes);
  return notes;
}

export function reportWallNote(id: string) {
  const notes = loadWall().map((note) => note.id === id ? { ...note, reportCount: note.reportCount + 1, status: note.isSeeded ? note.status : 'pending_moderation' as const } : note);
  saveWall(notes);
  return notes;
}

export function moderateWallNote(id: string, status: WallNote['status']) {
  const notes = loadWall().map((note) => note.id === id ? { ...note, status } : note);
  saveWall(notes);
  return notes;
}
