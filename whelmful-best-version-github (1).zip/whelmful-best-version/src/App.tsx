import { useMemo, useRef, useState } from 'react';
import type React from 'react';
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ArrowRight, BookOpen, Brain, CircleDot, Compass, Flag, HandHeart, Layers, Menu, MessageCircle, MousePointerClick, NotebookTabs, ShieldCheck, Sprout, X } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { pathwayLabels, pathwayThoughts, themeOptions, tinyGoodThingPrompts } from './data/content';
import { translateDump } from './lib/whelmfulApi';
import { addWallNote, deleteEntry, loadEntries, loadSession, loadWall, moderateWallNote, reportWallNote, saveEntry, saveSession, supportWallNote, uid } from './lib/storage';
import type { FlowEntry, ParentPathway, SessionProfile, Theme, TranslatorResult, WallNote } from './types';

type View = 'home' | 'app' | 'wall' | 'patterns' | 'saved' | 'resources' | 'privacy' | 'admin';
type FlowStep = 'dump' | 'share' | 'translate' | 'choice' | 'move' | 'good' | 'checkin' | 'complete';

type Draft = {
  dumpText: string;
  shareChoice: 'wall' | 'private';
  translation?: TranslatorResult;
  commitment: { move: string; when: string; where: string; confidence: number; finalMove: string };
  good: { text: string; sensoryDetail: string; whyItMatters: string };
  checkIn: { result: string; shiftRating: number; learning: string };
};

const flowSteps: { key: FlowStep; label: string }[] = [
  { key: 'dump', label: 'Dump' },
  { key: 'share', label: 'Share' },
  { key: 'translate', label: 'Translate' },
  { key: 'choice', label: 'Choose' },
  { key: 'move', label: 'Move' },
  { key: 'good', label: 'Good thing' },
  { key: 'checkin', label: 'Check-in' },
  { key: 'complete', label: 'Done' }
];

const emptyDraft: Draft = {
  dumpText: '',
  shareChoice: 'private',
  commitment: { move: '', when: 'next_ten_minutes', where: 'wherever I am', confidence: 3, finalMove: '' },
  good: { text: '', sensoryDetail: '', whyItMatters: '' },
  checkIn: { result: '', shiftRating: 0, learning: '' }
};

export default function App() {
  const [view, setView] = useState<View>('home');
  const [session, setSession] = useState<SessionProfile>(() => loadSession());
  const [entries, setEntries] = useState<FlowEntry[]>(() => loadEntries());
  const [wall, setWall] = useState<WallNote[]>(() => loadWall());
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  function updateSession(next: SessionProfile) {
    setSession(next);
    saveSession(next);
  }

  function persistEntry(entry: FlowEntry) {
    saveEntry(entry);
    setEntries(loadEntries());
  }

  function navigate(next: View) {
    setView(next);
    setMobileNavOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="wf-app-shell">
      <Header view={view} navigate={navigate} mobileNavOpen={mobileNavOpen} setMobileNavOpen={setMobileNavOpen} />
      <main>
        <AnimatePresence mode="wait">
          {view === 'home' && <Home key="home" navigate={navigate} />}
          {view === 'app' && <FlowApp key="flow" session={session} updateSession={updateSession} save={persistEntry} addWall={(note) => { addWallNote(note); setWall(loadWall()); }} navigate={navigate} />}
          {view === 'wall' && <WallPage key="wall" wall={wall} setWall={setWall} session={session} navigate={navigate} />}
          {view === 'patterns' && <PatternsPage key="patterns" entries={entries} session={session} updateSession={updateSession} navigate={navigate} />}
          {view === 'saved' && <SavedPage key="saved" entries={entries} deleteEntryById={(id) => { deleteEntry(id); setEntries(loadEntries()); }} navigate={navigate} session={session} updateSession={updateSession} />}
          {view === 'resources' && <ResourcesPage key="resources" />}
          {view === 'privacy' && <PrivacyPage key="privacy" />}
          {view === 'admin' && <AdminPage key="admin" wall={wall} setWall={setWall} />}
        </AnimatePresence>
      </main>
      <MobileDock view={view} navigate={navigate} />
      <Footer navigate={navigate} />
    </div>
  );
}

function Header({ view, navigate, mobileNavOpen, setMobileNavOpen }: { view: View; navigate: (v: View) => void; mobileNavOpen: boolean; setMobileNavOpen: (open: boolean) => void }) {
  const items: { label: string; view: View }[] = [
    { label: 'Dump', view: 'app' },
    { label: 'Wall', view: 'wall' },
    { label: 'Patterns', view: 'patterns' },
    { label: 'Saved', view: 'saved' },
    { label: 'Resources', view: 'resources' }
  ];
  return (
    <header className="topbar">
      <button className="brand" onClick={() => navigate('home')} aria-label="Go home"><span className="brand-mark" /> whelmful</button>
      <nav className="nav-links" aria-label="Main navigation">
        {items.map((item) => <button key={item.view} className={view === item.view ? 'active' : ''} onClick={() => navigate(item.view)}>{item.label}</button>)}
      </nav>
      <div className="topbar-actions">
        <button className="btn btn-primary" onClick={() => navigate('app')}>Start a dump</button>
        <button className="icon-btn mobile-menu" onClick={() => setMobileNavOpen(!mobileNavOpen)} aria-label="Open menu">{mobileNavOpen ? <X /> : <Menu />}</button>
      </div>
      {mobileNavOpen && <div className="mobile-menu-panel">{items.map((item) => <button key={item.view} onClick={() => navigate(item.view)}>{item.label}</button>)}</div>}
    </header>
  );
}

function Home({ navigate }: { navigate: (v: View) => void }) {
  return (
    <PageMotion className="home-page">
      <section className="hero-grid">
        <div className="hero-copy">
          <motion.div className="pill" initial={{ y: 8, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>for the parent carrying too much</motion.div>
          <motion.h1 initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.05 }}>Dump the heavy bit. Translate the pattern. Choose one tiny move.</motion.h1>
          <motion.p initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.1 }}>A warm behaviour-change reflection app for the messy thoughts you usually keep to yourself. Built for mums, dads, solo parents, co-parents, step-parents, FIFO families, and the parent who does not want a label.</motion.p>
          <motion.div className="hero-actions" initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.16 }}>
            <ParticleButton onClick={() => navigate('app')}>Start a dump <ArrowRight size={18} /></ParticleButton>
            <button className="btn btn-secondary" onClick={() => navigate('wall')}>See the wall</button>
          </motion.div>
          <div className="trust-row">
            <span><ShieldCheck size={16} /> reviewed wall notes</span>
            <span><Compass size={16} /> choice-point behaviour loop</span>
            <span><NotebookTabs size={16} /> opt-in pattern tracking</span>
          </div>
        </div>
        <InteractiveProductStage navigate={navigate} />
      </section>
      <section className="section split-section">
        <div>
          <p className="hand-label">the behaviour loop</p>
          <h2>It is not just a dump. It teaches a different next move.</h2>
          <p>Whelmful combines body clues, protective-pattern language, values, identity reframing, self-compassion, attachment-informed repair and tiny committed action into one practical flow.</p>
        </div>
        <div className="loop-grid">
          {['Dump', 'Translate', 'Choice point', 'Tiny move', 'Tiny good thing', 'Check-in'].map((label, index) => <motion.article whileHover={{ rotate: 0, y: -6 }} className={`loop-card tone-${index % 5}`} key={label}><span>0{index + 1}</span><h3>{label}</h3></motion.article>)}
        </div>
      </section>
      <section className="wall-preview-section">
        <div className="wall-copy"><p className="hand-label">the wall</p><h2>normalise the thoughts people whisper to themselves.</h2><p>Starter notes are labelled honestly. Real parent notes only appear after review. The point is less isolation, not a crisis feed.</p><button className="btn btn-paper" onClick={() => navigate('wall')}>Open the wall</button></div>
        <div className="noticeboard">
          {['i love my kids but omg i just want no one to need me for five minutes', 'i dont regret my child. i regret how much of me disappeared', 'everyone online looks calm and gentle and im over here losing it over socks'].map((n, i) => <WallSticky key={n} text={n} label="anonymous starter note" index={i} />)}
        </div>
      </section>
      <section className="section pathways-section">
        <p className="hand-label">one app. different parent loads.</p>
        <h2>Personalised without splitting the community.</h2>
        <div className="pathway-mini-grid">
          {Object.values(pathwayLabels).map((p) => <article key={p.title} className="pathway-mini"><CircleDot size={18} /><strong>{p.title}</strong><p>{p.description}</p></article>)}
        </div>
      </section>
    </PageMotion>
  );
}

function InteractiveProductStage({ navigate }: { navigate: (v: View) => void }) {
  const cards = [
    { title: 'what do you want to dump today?', body: 'today i need to dump…', tone: 'olive', cta: 'dump it' },
    { title: 'share this anonymously?', body: 'raw version stays yours. wall version gets reviewed.', tone: 'paper', cta: 'choose' },
    { title: 'let’s translate the spiral.', body: 'body clue · what’s loud · what it protects · what you need', tone: 'lilac', cta: 'translate' },
    { title: 'one tiny move.', body: 'send one honest text asking for help.', tone: 'blush', cta: 'make it real' }
  ];
  return (
    <div className="product-stage">
      <span className="tape tape-one" /><span className="tape tape-two" />
      <div className="phone-row">
        {cards.map((card, i) => <TiltPhone key={card.title} card={card} index={i} onClick={() => navigate('app')} />)}
      </div>
    </div>
  );
}

function TiltPhone({ card, index, onClick }: { card: { title: string; body: string; tone: string; cta: string }; index: number; onClick: () => void }) {
  const ref = useRef<HTMLButtonElement | null>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-80, 80], [8, -8]), { stiffness: 180, damping: 16 });
  const rotateY = useSpring(useTransform(x, [-80, 80], [-8, 8]), { stiffness: 180, damping: 16 });
  function handleMove(e: React.MouseEvent) {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    x.set(e.clientX - rect.left - rect.width / 2);
    y.set(e.clientY - rect.top - rect.height / 2);
  }
  return (
    <motion.button ref={ref} className={`phone phone-${card.tone}`} style={{ rotateX, rotateY }} onMouseMove={handleMove} onMouseLeave={() => { x.set(0); y.set(0); }} onClick={onClick} initial={{ opacity: 0, y: 20, rotate: index % 2 ? 1.5 : -1.5 }} animate={{ opacity: 1, y: index % 2 ? 26 : 0, rotate: index % 2 ? 1.5 : -1.5 }} transition={{ delay: 0.1 + index * 0.07 }}>
      <span className="phone-dots"><i /><i /><i /></span>
      <h3>{card.title}</h3>
      <p>{card.body}</p>
      <span className="phone-cta">{card.cta}</span>
    </motion.button>
  );
}

function FlowApp({ session, updateSession, save, addWall, navigate }: { session: SessionProfile; updateSession: (s: SessionProfile) => void; save: (entry: FlowEntry) => void; addWall: (note: WallNote) => void; navigate: (v: View) => void }) {
  const [step, setStep] = useState<FlowStep>(session.onboardingCompleted ? 'dump' : 'dump');
  const [showOnboarding, setShowOnboarding] = useState(!session.onboardingCompleted);
  const [draft, setDraft] = useState<Draft>(emptyDraft);
  const [loading, setLoading] = useState(false);
  const activeIndex = flowSteps.findIndex((s) => s.key === step);
  const prompts = useMemo(() => prioritisedPrompts(session), [session]);

  if (showOnboarding) {
    return <Onboarding session={session} updateSession={(s) => { updateSession(s); setShowOnboarding(false); }} skip={() => { updateSession({ ...session, onboardingCompleted: true }); setShowOnboarding(false); }} />;
  }

  async function runTranslator() {
    setLoading(true);
    const result = await translateDump({ text: draft.dumpText, pathway: session.parentPathway, shareIntent: draft.shareChoice });
    setDraft((d) => ({ ...d, translation: result, commitment: { ...d.commitment, move: result.tiny_move?.move ?? '', finalMove: result.tiny_move?.move ?? '' } }));
    setLoading(false);
    setStep(result.safety_message ? 'translate' : 'translate');
  }

  function finishFlow() {
    if (!draft.translation) return;
    const entry: FlowEntry = {
      id: uid('entry'),
      createdAt: new Date().toISOString(),
      pathway: session.parentPathway,
      dumpText: draft.dumpText,
      shareChoice: draft.shareChoice,
      translation: draft.translation,
      tinyMoveCommitment: draft.commitment,
      tinyGoodThing: draft.good,
      checkIn: draft.checkIn
    };
    save(entry);
    if (draft.shareChoice === 'wall' && draft.translation.anonymous_wall_version && draft.translation.publish_tier !== 'blocked') {
      addWall({
        id: uid('wall'),
        publicText: draft.translation.anonymous_wall_version,
        label: 'anonymous parent',
        isSeeded: false,
        status: draft.translation.publish_tier === 'safe_fast_queue' ? 'fast_queue' : 'pending_moderation',
        publishTier: draft.translation.publish_tier,
        supportCount: 0,
        reportCount: 0,
        pathway: session.parentPathway,
        tags: draft.translation.tags
      });
    }
    setStep('complete');
  }

  return (
    <PageMotion className="flow-page">
      <section className="flow-shell">
        <span className="tape tape-one" /><span className="tape tape-two" />
        <div className="flow-topline">
          <ProgressTabs activeIndex={activeIndex} />
          <button className="btn btn-paper btn-sm" onClick={() => setShowOnboarding(true)}>change path</button>
        </div>
        <AnimatePresence mode="wait">
          {step === 'dump' && <motion.div key="dump" className="flow-step olive-step" {...stepAnim}><p className="step-pill">Step one · {pathwayLabels[session.parentPathway].short}</p><h2>What do you want to dump today?</h2><p>No judgement. Just a safe space to get it out.</p><textarea value={draft.dumpText} onChange={(e) => setDraft({ ...draft, dumpText: e.target.value })} placeholder="today i need to dump…" autoFocus /><div className="prompt-panel"><p className="hand-label">Stuff parents quietly carry</p><p>Tap one if it feels close, or write your own.</p><div className="chip-grid">{prompts.slice(0, 5).map((p) => <button key={p.dumpPrompt} className="prompt-chip" onClick={() => setDraft({ ...draft, dumpText: p.dumpPrompt })}>{p.dumpPrompt}</button>)}</div></div><div className="actions"><ParticleButton disabled={draft.dumpText.trim().length < 3} onClick={() => setStep('share')}>dump it <ArrowRight size={18} /></ParticleButton><button className="btn btn-secondary" onClick={() => setDraft({ ...draft, dumpText: prompts[Math.floor(Math.random() * prompts.length)].dumpPrompt })}>need a prompt?</button></div></motion.div>}
          {step === 'share' && <motion.div key="share" className="flow-step" {...stepAnim}><p className="step-pill">Share or private</p><h2>Do you want this to help someone else feel less alone?</h2><p>Raw version stays yours. Wall version gets softened, risk-checked and reviewed.</p><div className="choice-grid"><button className={`choice-card ${draft.shareChoice === 'wall' ? 'selected' : ''}`} onClick={() => setDraft({ ...draft, shareChoice: 'wall' })}><MessageCircle /><strong>Share anonymously</strong><span>Send a softened version to the review queue.</span></button><button className={`choice-card ${draft.shareChoice === 'private' ? 'selected' : ''}`} onClick={() => setDraft({ ...draft, shareChoice: 'private' })}><ShieldCheck /><strong>Keep private</strong><span>Save the learning just for you.</span></button></div><div className="actions"><button className="btn btn-secondary" onClick={() => setStep('dump')}>back</button><ParticleButton onClick={runTranslator}>{loading ? 'translating…' : 'translate it'} <Brain size={18} /></ParticleButton></div></motion.div>}
          {step === 'translate' && <TranslatorStep draft={draft} loading={loading} back={() => setStep('share')} next={() => draft.translation?.safety_message ? navigate('resources') : setStep('choice')} />}
          {step === 'choice' && <motion.div key="choice" className="flow-step" {...stepAnim}><p className="step-pill">Choice point</p><h2>Here’s the tiny gap.</h2><p>This is where the old pattern does not have to run the whole show.</p><div className="choice-point-grid"><article className="paper-card blush-card"><span>The old move</span><h3>{draft.translation?.choice_point?.old_move}</h3><p>{draft.translation?.choice_point?.old_move_cost}</p></article><article className="paper-card olive-card"><span>The next move</span><h3>{draft.translation?.choice_point?.next_move}</h3><p>{draft.translation?.choice_point?.why_this_move_fits}</p></article></div><div className="cost-row"><p className="hand-label">What does the old move usually cost you?</p>{['my energy', 'my self-trust', 'my connection', 'my calm', 'my dignity', 'my body'].map((c) => <button className="tiny-chip" key={c}>{c}</button>)}</div><div className="actions"><button className="btn btn-secondary" onClick={() => setStep('translate')}>back</button><ParticleButton onClick={() => setStep('move')}>choose the next move</ParticleButton></div></motion.div>}
          {step === 'move' && <motion.div key="move" className="flow-step" {...stepAnim}><p className="step-pill">Tiny move commitment</p><h2>Make the tiny move real.</h2><p>Not impressive. Doable. That is the point.</p><div className="form-grid"><label>My tiny move is<input value={draft.commitment.finalMove || draft.translation?.tiny_move?.move || ''} onChange={(e) => setDraft({ ...draft, commitment: { ...draft.commitment, finalMove: e.target.value } })} /></label><label>I’ll do it<select value={draft.commitment.when} onChange={(e) => setDraft({ ...draft, commitment: { ...draft.commitment, when: e.target.value } })}><option value="now">now</option><option value="next_ten_minutes">in the next ten minutes</option><option value="before_bed">before bed</option><option value="tomorrow_morning">tomorrow morning</option><option value="next_time">next time this shows up</option></select></label><label>Where?<input value={draft.commitment.where} onChange={(e) => setDraft({ ...draft, commitment: { ...draft.commitment, where: e.target.value } })} /></label><label>Doable? {draft.commitment.confidence}/5<input type="range" min={1} max={5} value={draft.commitment.confidence} onChange={(e) => setDraft({ ...draft, commitment: { ...draft.commitment, confidence: Number(e.target.value), finalMove: Number(e.target.value) < 3 ? draft.translation?.tiny_move?.smallest_version ?? draft.commitment.finalMove : draft.commitment.finalMove } })} /></label></div>{draft.commitment.confidence < 3 && <article className="paper-card butter-card"><span>Make it smaller</span><p>If it feels too hard, it is not tiny enough. Try: {draft.translation?.tiny_move?.smallest_version}</p></article>}<div className="actions"><button className="btn btn-secondary" onClick={() => setStep('choice')}>back</button><ParticleButton onClick={() => setStep('good')}>I’ll try this</ParticleButton></div></motion.div>}
          {step === 'good' && <GoodThingStep draft={draft} setDraft={setDraft} back={() => setStep('move')} next={() => setStep('checkin')} />}
          {step === 'checkin' && <motion.div key="checkin" className="flow-step" {...stepAnim}><p className="step-pill">Check-in</p><h2>Did anything shift by one percent?</h2><p>No pressure for a miracle. We are teaching your brain to notice what happens after a different move.</p><div className="check-grid">{['a tiny bit lighter', 'still heavy, but I chose differently', 'no shift yet', 'i couldn’t do the move', 'make it smaller'].map((r) => <button key={r} className={draft.checkIn.result === r ? 'selected check-card' : 'check-card'} onClick={() => setDraft({ ...draft, checkIn: { ...draft.checkIn, result: r, learning: r.includes('couldn') ? 'The move was probably too big. That is useful data, not failure.' : 'Tiny counts because it is a vote for the person I am becoming.' } })}>{r}</button>)}</div><label>Save the learning<textarea value={draft.checkIn.learning} onChange={(e) => setDraft({ ...draft, checkIn: { ...draft.checkIn, learning: e.target.value } })} placeholder="What did this teach you about what helps, even one percent?" /></label><div className="actions"><button className="btn btn-secondary" onClick={() => setStep('good')}>back</button><ParticleButton onClick={finishFlow}>save the learning</ParticleButton></div></motion.div>}
          {step === 'complete' && <motion.div key="complete" className="flow-step complete-step" {...stepAnim}><p className="step-pill">Complete</p><h2>You moved something.</h2><p>You dumped it, translated the pattern, chose a different move, spotted one tiny good thing and saved what you learned. That counts.</p><div className="actions centered"><ParticleButton onClick={() => { setDraft(emptyDraft); setStep('dump'); }}>start another dump</ParticleButton><button className="btn btn-secondary" onClick={() => navigate('wall')}>visit the wall</button><button className="btn btn-paper" onClick={() => navigate('patterns')}>see my patterns</button></div></motion.div>}
        </AnimatePresence>
      </section>
    </PageMotion>
  );
}

function TranslatorStep({ draft, loading, back, next }: { draft: Draft; loading: boolean; back: () => void; next: () => void }) {
  const t = draft.translation;
  if (loading || !t) return <motion.div key="loading" className="flow-step" {...stepAnim}><h2>Translating the spiral…</h2><p>Looking for the body clue, the protection underneath, the need, the value and the next move.</p><div className="loader-stack"><span /><span /><span /></div></motion.div>;
  if (t.safety_message) return <motion.div key="safety" className="flow-step safety-step" {...stepAnim}><p className="step-pill">Safety first</p><h2>This needs real-life backup.</h2><p>{t.safety_message}</p><div className="actions"><button className="btn btn-secondary" onClick={back}>back</button><button className="btn btn-primary" onClick={next}>open resources</button></div></motion.div>;
  const cards = [
    ['Body clue', t.translator?.body_clue, 'blush'],
    ['What’s loud right now', t.translator?.whats_loud, 'butter'],
    ['What it might be protecting', t.translator?.what_it_might_be_protecting, 'lilac'],
    ['What you might actually need', t.translator?.what_you_might_need, 'paper'],
    ['What matters underneath', t.translator?.what_matters_underneath, 'olive'],
    ['A kinder sentence', t.translator?.kinder_sentence, 'blush']
  ];
  return <motion.div key="translate" className="flow-step" {...stepAnim}><p className="step-pill">Body-Brain Translator</p><h2>Let’s translate the spiral.</h2><p>Not a diagnosis. Not a lecture. Just a softer way to understand what your body and brain might be trying to say.</p><div className="translator-grid">{cards.map(([label, text, tone], index) => <motion.article layout whileHover={{ y: -6, rotate: 0 }} className={`paper-card ${tone}-card`} key={label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.04 }}><span>{label}</span><p>{text}</p></motion.article>)}</div><div className="actions"><button className="btn btn-secondary" onClick={back}>back</button><ParticleButton onClick={next}>find the choice point</ParticleButton></div></motion.div>;
}

function GoodThingStep({ draft, setDraft, back, next }: { draft: Draft; setDraft: (d: Draft) => void; back: () => void; next: () => void }) {
  return <motion.div key="good" className="flow-step good-step" {...stepAnim}><p className="step-pill">One Tiny Good Thing</p><h2>Make the good thing stronger.</h2><p>Not toxic positivity. This is behavioural learning: helping the brain notice proof that not everything was only awful.</p><div className="good-lab"><label>One tiny good thing I can notice is…<textarea value={draft.good.text} onChange={(e) => setDraft({ ...draft, good: { ...draft.good, text: e.target.value } })} placeholder="one tiny thing that was not terrible…" /></label><label>Where did you feel or see it?<input value={draft.good.sensoryDetail} onChange={(e) => setDraft({ ...draft, good: { ...draft.good, sensoryDetail: e.target.value } })} placeholder="warm cup, quiet room, tiny laugh, light through window…" /></label><label>Why does it matter, even one percent?<input value={draft.good.whyItMatters} onChange={(e) => setDraft({ ...draft, good: { ...draft.good, whyItMatters: e.target.value } })} placeholder="because it proves I can still notice something steady…" /></label></div><div className="chip-grid">{tinyGoodThingPrompts.map((p) => <button className="prompt-chip" key={p} onClick={() => setDraft({ ...draft, good: { ...draft.good, text: p } })}>{p}</button>)}</div><div className="actions"><button className="btn btn-secondary" onClick={back}>back</button><ParticleButton onClick={next}>save this tiny proof</ParticleButton></div></motion.div>;
}

function Onboarding({ session, updateSession, skip }: { session: SessionProfile; updateSession: (s: SessionProfile) => void; skip: () => void }) {
  const [selectedPathway, setSelectedPathway] = useState<ParentPathway>(session.parentPathway);
  const [themes, setThemes] = useState<Theme[]>(session.selectedThemes);
  function toggleTheme(t: Theme) { setThemes((prev) => prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]); }
  return <PageMotion className="onboarding-page"><section className="onboarding-shell"><span className="tape tape-one" /><p className="hand-label">make it feel less generic</p><h1>What kind of support feels closest today?</h1><p>You can change this anytime. Pathways personalise examples, but everyone stays in one shared Whelmful community.</p><div className="pathway-grid">{(Object.keys(pathwayLabels) as ParentPathway[]).map((key) => <motion.button whileHover={{ y: -5, rotate: 0 }} className={selectedPathway === key ? 'path-card selected' : 'path-card'} key={key} onClick={() => setSelectedPathway(key)}><span>{pathwayLabels[key].short}</span><p>{pathwayLabels[key].description}</p></motion.button>)}</div><h2>What shows up most?</h2><div className="theme-chip-row">{themeOptions.map((t) => <button className={themes.includes(t.key) ? 'selected tiny-chip' : 'tiny-chip'} key={t.key} onClick={() => toggleTheme(t.key)}>{t.label}</button>)}</div><div className="actions"><ParticleButton onClick={() => updateSession({ ...session, parentPathway: selectedPathway, selectedThemes: themes, onboardingCompleted: true })}>Start Whelmful</ParticleButton><button className="btn btn-secondary" onClick={skip}>skip for now</button></div></section></PageMotion>;
}

function WallPage({ wall, setWall, session, navigate }: { wall: WallNote[]; setWall: (n: WallNote[]) => void; session: SessionProfile; navigate: (v: View) => void }) {
  const [filter, setFilter] = useState<string>('all');
  const filters = ['all', 'mums', 'dads', 'single parents', 'co-parenting', 'fifo', 'step-parents', 'identity loss', 'burnout', 'rage', 'guilt', 'not bonding', 'invisible load', 'repair'];
  const visible = wall.filter((note) => note.status === 'published' && (filter === 'all' || note.tags.join(' ').toLowerCase().includes(filter.replace(' parents', '').replace('mums', 'mum').replace('dads', 'dad'))));
  const starter = visible.filter((n) => n.isSeeded);
  const real = visible.filter((n) => !n.isSeeded);
  return <PageMotion className="wall-page"><section className="wall-hero"><div><p className="hand-label">the wall</p><h1>Messy thoughts. safely held.</h1><p>The wall is one shared space. Filters just help you find the kind of “same” you need today.</p></div><ParticleButton onClick={() => navigate('app')}>leave a note</ParticleButton></section><div className="filter-row">{filters.map((f) => <button key={f} onClick={() => setFilter(f)} className={filter === f ? 'selected tiny-chip' : 'tiny-chip'}>{f}</button>)}</div><section className="noticeboard big"><div className="wall-section-title"><h2>Starter notes</h2><p>Fictionalised common thoughts so the wall does not feel empty while the community grows.</p></div>{starter.map((note, i) => <WallSticky key={note.id} text={note.publicText} label={note.label} index={i} support={note.supportCount} onSupport={() => setWall(supportWallNote(note.id))} onReport={() => setWall(reportWallNote(note.id))} />)}</section><section className="community-section"><h2>Anonymous parent notes</h2><p>Submitted by real users and reviewed before appearing.</p>{real.length ? <div className="wall-grid">{real.map((note, i) => <WallSticky key={note.id} text={note.publicText} label={note.label} index={i} support={note.supportCount} onSupport={() => setWall(supportWallNote(note.id))} onReport={() => setWall(reportWallNote(note.id))} />)}</div> : <article className="empty-card"><MessageCircle /><h3>No reviewed parent notes yet.</h3><p>Starter notes keep the wall warm while real submissions move through review.</p></article>}</section></PageMotion>;
}

function PatternsPage({ entries, session, updateSession, navigate }: { entries: FlowEntry[]; session: SessionProfile; updateSession: (s: SessionProfile) => void; navigate: (v: View) => void }) {
  const data = useMemo(() => buildPatterns(entries), [entries]);
  if (!session.dataTrackingConsent) return <PageMotion className="patterns-page"><section className="consent-card"><p className="hand-label">private patterns</p><h1>Not a scorecard. Just clues.</h1><p>Whelmful can privately track repeated patterns so you can notice what tends to show up for you. This is for reflection only. It is not mental health monitoring, diagnosis, treatment, or crisis support.</p><div className="actions"><ParticleButton onClick={() => updateSession({ ...session, dataTrackingConsent: true })}>turn on private patterns</ParticleButton><button className="btn btn-secondary" onClick={() => navigate('app')}>start a dump instead</button></div></section></PageMotion>;
  return <PageMotion className="patterns-page"><section className="section-head"><p className="hand-label">my patterns</p><h1>Not a scorecard. A map of what keeps showing up.</h1><p>These insights use your saved flows only. No clinical labels, no symptom tracking, no red warning dashboards.</p></section><div className="pattern-card-grid"><PatternCard title="Your loudest old move lately" value={data.oldMove || 'not enough data yet'} copy="This is the pattern Whelmful sees most often in your check-ins." /><PatternCard title="What you seem to need" value={data.need || 'not enough data yet'} copy="Needs are not weakness. They are information." /><PatternCard title="What still matters underneath" value={data.value || 'not enough data yet'} copy="The value is the compass, not the shame." /><PatternCard title="Tiny moves tried" value={String(data.tried)} copy="Small actions become behaviour change when you notice them." /></div><section className="chart-panel"><h2>Repeated themes</h2><ResponsiveContainer width="100%" height={260}><BarChart data={data.chart}><CartesianGrid strokeDasharray="4 8" vertical={false} /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#E8793E" radius={[12, 12, 0, 0]} /></BarChart></ResponsiveContainer></section></PageMotion>;
}

function SavedPage({ entries, deleteEntryById, navigate, session, updateSession }: { entries: FlowEntry[]; deleteEntryById: (id: string) => void; navigate: (v: View) => void; session: SessionProfile; updateSession: (s: SessionProfile) => void }) {
  return <PageMotion className="saved-page"><section className="section-head"><p className="hand-label">saved notes</p><h1>Your private learning stack.</h1><p>Dumps, translations, tiny moves, tiny good things and check-ins stay here locally unless you connect Supabase.</p></section><section className="settings-card"><h2>My Whelmful path</h2><select value={session.parentPathway} onChange={(e) => updateSession({ ...session, parentPathway: e.target.value as ParentPathway })}>{(Object.keys(pathwayLabels) as ParentPathway[]).map((p) => <option value={p} key={p}>{pathwayLabels[p].title}</option>)}</select><label className="inline-toggle"><input type="checkbox" checked={session.avoidGenderedLanguage} onChange={(e) => updateSession({ ...session, avoidGenderedLanguage: e.target.checked })} /> Avoid gendered language where possible</label></section>{entries.length ? <div className="saved-grid">{entries.map((entry) => <article className="saved-card" key={entry.id}><span>{new Date(entry.createdAt).toLocaleDateString()}</span><h3>{entry.translation.internal_map?.dominant_pattern?.replace(/_/g, ' ')}</h3><p>{entry.dumpText}</p><strong>Tiny move: {entry.tinyMoveCommitment?.finalMove}</strong><button className="btn btn-paper btn-sm" onClick={() => deleteEntryById(entry.id)}>delete</button></article>)}</div> : <article className="empty-card"><BookOpen /><h3>No saved flows yet.</h3><p>Start a dump and save the learning when you complete the flow.</p><button className="btn btn-primary" onClick={() => navigate('app')}>start a dump</button></article>}</PageMotion>;
}

function ResourcesPage() { return <PageMotion className="resources-page"><section className="section-head"><p className="hand-label">real-life backup</p><h1>When Whelmful is not enough.</h1><p>Whelmful is not emergency support. If someone could be hurt or unsafe, use real-world help now.</p></section><div className="resource-grid"><article><ShieldCheck /><h2>Immediate danger</h2><p>Call Triple Zero now.</p></article><article><HandHeart /><h2>Crisis support</h2><p>Lifeline Australia: 13 11 14.</p></article><article><Sprout /><h2>Perinatal support</h2><p>PANDA: 1300 726 306.</p></article></div></PageMotion>; }
function PrivacyPage() { return <PageMotion className="privacy-page"><section className="section-head"><p className="hand-label">privacy</p><h1>Built for sensitive thoughts.</h1><p>Do not enter identifying details. Starter notes are fictionalised. Real community notes are reviewed. Pattern tracking is opt-in. Whelmful does not provide emergency monitoring.</p></section><div className="legal-grid"><article><h2>Anonymous by default</h2><p>The local version stores your flow data in your browser. Supabase can be connected when you are ready.</p></article><article><h2>Wall review</h2><p>Real notes cannot auto-publish. They move through fast queue, manual review or blocked.</p></article><article><h2>Deletion</h2><p>When connected to Supabase, deletion requests can use anonymous deletion codes.</p></article></div></PageMotion>; }

function AdminPage({ wall, setWall }: { wall: WallNote[]; setWall: (n: WallNote[]) => void }) {
  const queues = wall.filter((n) => ['fast_queue', 'pending_moderation', 'unsafe'].includes(n.status));
  return <PageMotion className="admin-page"><section className="section-head"><p className="hand-label">moderation</p><h1>Review before publishing.</h1><p>Fast queue is for quick review, not auto-publishing. Manual review is for heavier notes. Unsafe never publishes.</p></section><div className="admin-list">{queues.length ? queues.map((note) => <article className="admin-card" key={note.id}><span>{note.publishTier} · {note.status}</span><p>{note.publicText}</p><div className="actions"><button className="btn btn-primary btn-sm" onClick={() => setWall(moderateWallNote(note.id, 'published'))}>publish</button><button className="btn btn-secondary btn-sm" onClick={() => setWall(moderateWallNote(note.id, 'rejected'))}>reject</button><button className="btn btn-paper btn-sm" onClick={() => setWall(moderateWallNote(note.id, 'unsafe'))}>unsafe</button></div></article>) : <article className="empty-card"><Flag /><h3>No notes waiting.</h3><p>Submissions will appear here before publication.</p></article>}</div></PageMotion>;
}

function ProgressTabs({ activeIndex }: { activeIndex: number }) { return <div className="progress-tabs">{flowSteps.map((step, index) => <span key={step.key} className={index <= activeIndex ? 'active' : ''}><i>{index + 1}</i>{step.label}</span>)}</div>; }
function PageMotion({ className, children }: { className: string; children: React.ReactNode }) { return <motion.div className={className} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.28 }}>{children}</motion.div>; }
const stepAnim = { initial: { opacity: 0, x: 18 }, animate: { opacity: 1, x: 0 }, exit: { opacity: 0, x: -18 }, transition: { duration: 0.25 } };

function ParticleButton({ children, onClick, disabled }: { children: React.ReactNode; onClick: () => void; disabled?: boolean }) {
  const [bursts, setBursts] = useState<{ id: string; x: number; y: number }[]>([]);
  return <button className="btn btn-primary particle-btn" disabled={disabled} onClick={(e) => { const rect = e.currentTarget.getBoundingClientRect(); setBursts((b) => [...b, { id: uid('burst'), x: e.clientX - rect.left, y: e.clientY - rect.top }]); onClick(); setTimeout(() => setBursts((b) => b.slice(1)), 750); }}>{children}{bursts.map((b) => <span className="burst" key={b.id} style={{ left: b.x, top: b.y }} />)}</button>;
}
function WallSticky({ text, label, index, support, onSupport, onReport }: { text: string; label: string; index: number; support?: number; onSupport?: () => void; onReport?: () => void }) { return <motion.article drag dragConstraints={{ left: -30, right: 30, top: -30, bottom: 30 }} whileHover={{ y: -7, rotate: 0 }} className={`wall-sticky note-${index % 4}`}><span>{label}</span><p>{text}</p><div><button onClick={onSupport}>i felt this too {support ? `· ${support}` : ''}</button><button onClick={onReport}>report</button></div></motion.article>; }
function PatternCard({ title, value, copy }: { title: string; value: string; copy: string }) { return <article className="pattern-card"><span>{title}</span><strong>{value}</strong><p>{copy}</p></article>; }
function MobileDock({ view, navigate }: { view: View; navigate: (v: View) => void }) { const items: { view: View; label: string; icon: React.ReactNode }[] = [{ view: 'app', label: 'Dump', icon: <MousePointerClick /> }, { view: 'wall', label: 'Wall', icon: <MessageCircle /> }, { view: 'patterns', label: 'Patterns', icon: <Layers /> }, { view: 'saved', label: 'Saved', icon: <BookOpen /> }]; return <nav className="mobile-dock">{items.map((item) => <button key={item.view} className={view === item.view ? 'active' : ''} onClick={() => navigate(item.view)}>{item.icon}<span>{item.label}</span></button>)}</nav>; }
function Footer({ navigate }: { navigate: (v: View) => void }) { return <footer className="footer"><p>Whelmful provides general AI-supported reflection and behaviour-change tools. It does not provide therapy, diagnosis, treatment, crisis support, mental health monitoring, or emergency care.</p><button onClick={() => navigate('privacy')}>Privacy</button><button onClick={() => navigate('admin')}>Admin</button></footer>; }

function prioritisedPrompts(session: SessionProfile) {
  const base = pathwayThoughts[session.parentPathway] || pathwayThoughts.just_overwhelmed;
  const matched = base.filter((p) => session.selectedThemes.includes(p.theme));
  const all = [...matched, ...base, ...pathwayThoughts.just_overwhelmed];
  return Array.from(new Map(all.map((p) => [p.dumpPrompt, p])).values());
}
function buildPatterns(entries: FlowEntry[]) {
  const counts = new Map<string, number>();
  const needs = new Map<string, number>();
  const values = new Map<string, number>();
  const oldMoves = new Map<string, number>();
  entries.forEach((entry) => {
    const map = entry.translation.internal_map;
    if (!map) return;
    counts.set(map.dominant_pattern, (counts.get(map.dominant_pattern) ?? 0) + 1);
    needs.set(map.dominant_need, (needs.get(map.dominant_need) ?? 0) + 1);
    values.set(map.dominant_value, (values.get(map.dominant_value) ?? 0) + 1);
    oldMoves.set(map.old_move, (oldMoves.get(map.old_move) ?? 0) + 1);
  });
  const top = (m: Map<string, number>) => [...m.entries()].sort((a, b) => b[1] - a[1])[0]?.[0]?.replace(/_/g, ' ');
  return { oldMove: top(oldMoves), need: top(needs), value: top(values), tried: entries.length, chart: [...counts.entries()].map(([name, count]) => ({ name: name.replace(/_/g, ' '), count })).slice(0, 6) };
}
