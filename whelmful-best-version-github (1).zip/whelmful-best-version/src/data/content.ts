import type { ParentPathway, Theme, WallNote } from '../types';

export const pathwayLabels: Record<ParentPathway, { title: string; description: string; short: string }> = {
  mum_birth_parent: {
    title: 'Mum / birth parent',
    short: 'Mum / birth parent',
    description: 'For missing yourself, feeling touched out, carrying the invisible load, or feeling like you should be coping better.'
  },
  dad_non_birthing_parent: {
    title: 'Dad / non-birthing parent',
    short: 'Dad / non-birthing parent',
    description: 'For feeling unsure where you fit, wanting to support better, or feeling like everyone else learned the rules before you did.'
  },
  single_parent: {
    title: 'Single parent',
    short: 'Single parent',
    description: 'For being the whole backup plan, making every decision, and having no real off-switch.'
  },
  co_parenting_separated: {
    title: 'Co-parenting / separated parent',
    short: 'Co-parenting',
    description: 'For handovers, split homes, conflict, guilt, loneliness, and trying to stay steady.'
  },
  fifo_shift_work: {
    title: 'FIFO / shift-work family',
    short: 'FIFO / shift-work',
    description: 'For holding the fort, leaving and returning, resentment, guilt, and uneven rhythms.'
  },
  step_parent_blended_family: {
    title: 'Step-parent / blended family',
    short: 'Step-parent',
    description: 'For loving, trying, holding back, not knowing your place, and carrying guilt that is hard to say out loud.'
  },
  reconnecting_with_self: {
    title: 'Reconnecting with myself',
    short: 'Reconnecting with self',
    description: 'For identity loss, body changes, resentment, comparison, and wanting to feel like a person again.'
  },
  just_overwhelmed: {
    title: 'Just overwhelmed — don’t label me',
    short: 'Just overwhelmed',
    description: 'For when labels are too much and you just need somewhere to put the heavy bit.'
  }
};

export const themeOptions: { key: Theme; label: string }[] = [
  { key: 'burnout', label: 'Burnout' },
  { key: 'rage', label: 'Rage' },
  { key: 'guilt', label: 'Guilt' },
  { key: 'invisible_load', label: 'Invisible load' },
  { key: 'touched_out', label: 'Touched out' },
  { key: 'comparison', label: 'Comparison' },
  { key: 'loneliness', label: 'Loneliness' },
  { key: 'not_bonding', label: 'Not bonding' },
  { key: 'regret', label: 'Regret' },
  { key: 'partner_disconnect', label: 'Partner resentment' },
  { key: 'work_parenting', label: 'Work-parent guilt' },
  { key: 'money_pressure', label: 'Money pressure' },
  { key: 'repair', label: 'Repair' }
];

export type CommonPrompt = {
  theme: Theme;
  dumpPrompt: string;
  wallVersion: string;
  translatorAngle: string;
  tags: string[];
};

export const pathwayThoughts: Record<ParentPathway, CommonPrompt[]> = {
  mum_birth_parent: [
    { theme: 'touched_out', dumpPrompt: 'my body does not feel like mine anymore. its just needed all the time', wallVersion: 'my body has been needed by everyone for so long that i miss feeling like it belongs to me', translatorAngle: 'The body may be asking for space, ownership and less demand.', tags: ['body', 'space'] },
    { theme: 'identity_loss', dumpPrompt: 'i miss who i was before i became the person who remembers everything', wallVersion: 'i miss the version of me who could exist without carrying the whole house in my head', translatorAngle: 'The grief may be about identity, freedom and being seen as a person.', tags: ['identity', 'invisible load'] },
    { theme: 'guilt', dumpPrompt: 'i feel guilty for wanting a break from my own kid', wallVersion: 'needing a break from my child does not mean i do not love them. it means i am human', translatorAngle: 'The guilt voice may be confusing needs with selfishness.', tags: ['guilt', 'rest'] }
  ],
  dad_non_birthing_parent: [
    { theme: 'dads_feeling_useless', dumpPrompt: 'i want to help but everything i do feels wrong', wallVersion: 'i want to be useful but sometimes i feel like i missed the part where everyone learned what to do', translatorAngle: 'The old move may be withdrawing when the value underneath is connection.', tags: ['dad', 'connection'] },
    { theme: 'not_bonding', dumpPrompt: 'i feel like a stranger in my own house since the baby arrived', wallVersion: 'i want to belong here, but sometimes i feel like i am standing outside my own family', translatorAngle: 'The need may be confidence, connection and a small way in.', tags: ['bonding', 'belonging'] },
    { theme: 'partner_disconnect', dumpPrompt: 'i dont know how to support my partner and i feel useless', wallVersion: 'i care, but i keep freezing because i dont know what the right move is', translatorAngle: 'The need may be a clear next step instead of a perfect answer.', tags: ['partner', 'support'] }
  ],
  single_parent: [
    { theme: 'single_parent_overload', dumpPrompt: 'i am tired of being the whole backup plan', wallVersion: 'i am not just tired. i am tired of being the entire safety net', translatorAngle: 'The need may be practical support, rest and not being the only one.', tags: ['single parent', 'support'] },
    { theme: 'burnout', dumpPrompt: 'there is no one to hand it to when im done', wallVersion: 'the hardest bit is there is no one to tap in when i have nothing left', translatorAngle: 'The body may be asking for genuine backup, not just encouragement.', tags: ['backup', 'burnout'] }
  ],
  co_parenting_separated: [
    { theme: 'guilt', dumpPrompt: 'i hate handover days and then feel guilty for hating them', wallVersion: 'handover days can make everything feel split open again', translatorAngle: 'The need may be steadiness, transition support and less self-blame.', tags: ['handover', 'co-parenting'] },
    { theme: 'resentment', dumpPrompt: 'i feel like i have to be calm even when the whole thing is unfair', wallVersion: 'trying to stay steady when things feel unfair is exhausting', translatorAngle: 'The old move may be swallowing everything when the need is dignity and support.', tags: ['dignity', 'fairness'] }
  ],
  fifo_shift_work: [
    { theme: 'fifo_loneliness', dumpPrompt: 'i know its work but i still resent being left with everything', wallVersion: 'i know why they leave, but i am still the one holding the days and nights', translatorAngle: 'The resentment may be about loneliness and uneven load.', tags: ['fifo', 'resentment'] },
    { theme: 'guilt', dumpPrompt: 'when im away i feel guilty and when im home i feel behind', wallVersion: 'it is hard to belong fully when every rhythm keeps changing', translatorAngle: 'The need may be reconnection rituals and realistic expectations.', tags: ['fifo', 'rhythm'] }
  ],
  step_parent_blended_family: [
    { theme: 'step_parent_guilt', dumpPrompt: 'i care but sometimes i dont know where i fit', wallVersion: 'being part of a family and still not knowing your place is such a weird lonely feeling', translatorAngle: 'The need may be clarity, permission and slow trust.', tags: ['step parent', 'belonging'] },
    { theme: 'resentment', dumpPrompt: 'i feel guilty for resenting a role i chose', wallVersion: 'sometimes choosing something does not mean it stops being hard', translatorAngle: 'The shame voice may be saying you cannot struggle with something you chose.', tags: ['guilt', 'resentment'] }
  ],
  reconnecting_with_self: [
    { theme: 'identity_loss', dumpPrompt: 'i dont know what i like anymore', wallVersion: 'somewhere in all the needing and doing, i lost track of what feels like me', translatorAngle: 'The need may be small identity cues, not a full reinvention.', tags: ['identity', 'self'] },
    { theme: 'comparison', dumpPrompt: 'everyone else seems to have themselves together and i feel like a mess', wallVersion: 'i keep comparing my real life to someone elses polished little square', translatorAngle: 'The rulebook voice may be using other people as instructions.', tags: ['comparison', 'online'] }
  ],
  just_overwhelmed: [
    { theme: 'burnout', dumpPrompt: 'i am so tired i feel angry at anyone who needs me', wallVersion: 'i am not angry because i do not care. i am angry because i have had nothing left for hours', translatorAngle: 'The body may be asking for space, rest and fewer demands.', tags: ['burnout', 'space'] },
    { theme: 'shame', dumpPrompt: 'i had one bad moment and now i feel like a terrible parent', wallVersion: 'one hard moment can make me forget every gentle thing i have ever done', translatorAngle: 'The shame voice may be turning behaviour into identity.', tags: ['shame', 'repair'] },
    { theme: 'regret', dumpPrompt: 'i dont regret my child. i regret how much of me disappeared', wallVersion: 'i dont regret my child. i regret how much of me disappeared', translatorAngle: 'The thought may be grief, overload, or lost identity, not lack of love.', tags: ['regret', 'identity'] }
  ]
};

export const starterWallNotes: WallNote[] = [
  { id: 'starter-1', publicText: 'i love my kids but omg i just want no one to need me for like five minutes', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'safe_fast_queue', supportCount: 0, reportCount: 0, theme: 'burnout', tags: ['burnout', 'space'] },
  { id: 'starter-2', publicText: 'the crying doesnt make me angry because i dont care. it makes me angry because im already cooked', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'manual_review', supportCount: 0, reportCount: 0, theme: 'rage', tags: ['rage', 'overload'] },
  { id: 'starter-3', publicText: 'i miss who i was before i became the person who remembers everything for everyone', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'safe_fast_queue', supportCount: 0, reportCount: 0, theme: 'identity_loss', tags: ['identity', 'mental load'] },
  { id: 'starter-4', publicText: 'i dont feel bonded the way i thought i would and i hate admitting that', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'manual_review', supportCount: 0, reportCount: 0, theme: 'not_bonding', tags: ['bonding', 'shame'] },
  { id: 'starter-5', publicText: 'everyone online looks calm and gentle and im over here losing it over socks', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'safe_fast_queue', supportCount: 0, reportCount: 0, theme: 'comparison', tags: ['comparison', 'social media'] },
  { id: 'starter-6', publicText: 'i apologised but my brain still keeps saying i ruined everything', label: 'anonymous starter note', isSeeded: true, status: 'published', publishTier: 'safe_fast_queue', supportCount: 0, reportCount: 0, theme: 'repair', tags: ['repair', 'guilt'] }
];

export const tinyGoodThingPrompts = [
  'I got through the sharp bit without giving up.',
  'There was one quiet second and I noticed it.',
  'I asked for help, even awkwardly.',
  'My coffee was warm for two sips.',
  'I repaired one thing instead of punishing myself all night.',
  'The sky looked good through the window.',
  'I made one tiny choice that matched who I want to be.'
];
