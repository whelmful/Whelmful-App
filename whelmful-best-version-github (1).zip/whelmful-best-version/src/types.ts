export type ParentPathway =
  | 'mum_birth_parent'
  | 'dad_non_birthing_parent'
  | 'single_parent'
  | 'co_parenting_separated'
  | 'fifo_shift_work'
  | 'step_parent_blended_family'
  | 'reconnecting_with_self'
  | 'just_overwhelmed';

export type Theme =
  | 'burnout'
  | 'rage'
  | 'guilt'
  | 'shame'
  | 'comparison'
  | 'identity_loss'
  | 'resentment'
  | 'not_bonding'
  | 'touched_out'
  | 'partner_disconnect'
  | 'invisible_load'
  | 'self_sacrifice'
  | 'loneliness'
  | 'regret'
  | 'body_shame'
  | 'birth_story'
  | 'grief'
  | 'money_pressure'
  | 'work_parenting'
  | 'dads_feeling_useless'
  | 'single_parent_overload'
  | 'fifo_loneliness'
  | 'step_parent_guilt'
  | 'repair';

export type RiskLevel = 'low' | 'medium' | 'high' | 'urgent';
export type PublishTier = 'safe_fast_queue' | 'manual_review' | 'blocked';
export type MoveCategory = 'body_anchor' | 'support' | 'repair' | 'boundary' | 'truth' | 'lower_standard' | 'practical' | 'rest' | 'connection' | 'nature' | 'movement';

export type SessionProfile = {
  id: string;
  parentPathway: ParentPathway;
  selectedThemes: Theme[];
  onboardingCompleted: boolean;
  dataTrackingConsent: boolean;
  avoidGenderedLanguage: boolean;
  createdAt: string;
};

export type TranslatorResult = {
  risk_level: RiskLevel;
  public_wall_safe: boolean;
  publish_tier: PublishTier;
  translator: null | {
    body_clue: string;
    whats_loud: string;
    what_it_might_be_protecting: string;
    what_you_might_need: string;
    what_matters_underneath: string;
    kinder_sentence: string;
  };
  choice_point: null | {
    old_move: string;
    old_move_cost: string;
    next_move: string;
    why_this_move_fits: string;
  };
  tiny_move: null | {
    move: string;
    when: 'now' | 'next_ten_minutes' | 'before_bed' | 'tomorrow_morning' | 'next_time_this_shows_up';
    where: string;
    smallest_version: string;
    category: MoveCategory;
  };
  anonymous_wall_version: string | null;
  tags: string[];
  safety_message: string | null;
  internal_map?: {
    dominant_body_brain_state: string;
    dominant_pattern: string;
    dominant_need: string;
    dominant_value: string;
    old_move: string;
  };
};

export type FlowEntry = {
  id: string;
  createdAt: string;
  pathway: ParentPathway;
  dumpText: string;
  shareChoice: 'wall' | 'private';
  translation: TranslatorResult;
  tinyMoveCommitment?: {
    move: string;
    when: string;
    where: string;
    confidence: number;
    finalMove: string;
  };
  tinyGoodThing?: {
    text: string;
    sensoryDetail: string;
    whyItMatters: string;
  };
  checkIn?: {
    result: string;
    shiftRating: number;
    learning: string;
  };
};

export type WallNote = {
  id: string;
  publicText: string;
  label: 'anonymous starter note' | 'anonymous parent';
  isSeeded: boolean;
  status: 'published' | 'fast_queue' | 'pending_moderation' | 'unsafe' | 'rejected' | 'deleted';
  publishTier: PublishTier;
  supportCount: number;
  reportCount: number;
  pathway?: ParentPathway;
  theme?: Theme;
  tags: string[];
};
