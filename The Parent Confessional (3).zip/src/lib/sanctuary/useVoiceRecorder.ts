import { useCallback, useEffect, useRef, useState } from "react";

type SpeechRecognitionLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> & { length: number } }) => void) | null;
  onerror: ((e: unknown) => void) | null;
  onend: (() => void) | null;
};

function getRecognition(): SpeechRecognitionLike | null {
  const w = typeof window !== "undefined" ? (window as unknown as Record<string, unknown>) : null;
  if (!w) return null;
  const Ctor =
    (w.SpeechRecognition as new () => SpeechRecognitionLike) ||
    (w.webkitSpeechRecognition as new () => SpeechRecognitionLike);
  if (!Ctor) return null;
  return new Ctor();
}

export function useVoiceRecorder({ maxSeconds = 60 }: { maxSeconds?: number } = {}) {
  const [isRecording, setIsRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [transcript, setTranscript] = useState("");
  const [supported, setSupported] = useState(true);
  const recogRef = useRef<SpeechRecognitionLike | null>(null);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    setSupported(!!getRecognition());
    return () => {
      recogRef.current?.abort();
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, []);

  const start = useCallback(() => {
    const rec = getRecognition();
    if (!rec) {
      setSupported(false);
      return;
    }
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = navigator.language || "en-AU";
    let finalText = "";
    rec.onresult = (e) => {
      let interim = "";
      for (let i = 0; i < e.results.length; i++) {
        const result = e.results[i] as unknown as ArrayLike<{ transcript: string }> & { isFinal: boolean; 0: { transcript: string } };
        const txt = result[0].transcript;
        if ((result as unknown as { isFinal: boolean }).isFinal) finalText += txt + " ";
        else interim += txt;
      }
      setTranscript((finalText + interim).trim());
    };
    rec.onerror = (err) => {
      console.warn("speech error", err);
    };
    rec.onend = () => {
      // auto-stop handler may have already fired
    };
    rec.start();
    recogRef.current = rec;
    setIsRecording(true);
    setSeconds(0);
    setTranscript("");
    timerRef.current = window.setInterval(() => {
      setSeconds((s) => {
        if (s + 1 >= maxSeconds) {
          stop();
          return maxSeconds;
        }
        return s + 1;
      });
    }, 1000) as unknown as number;
  }, [maxSeconds]);

  const stop = useCallback(() => {
    try { recogRef.current?.stop(); } catch {}
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsRecording(false);
  }, []);

  const reset = useCallback(() => {
    stop();
    setSeconds(0);
    setTranscript("");
  }, [stop]);

  return { isRecording, seconds, transcript, setTranscript, start, stop, reset, supported };
}
