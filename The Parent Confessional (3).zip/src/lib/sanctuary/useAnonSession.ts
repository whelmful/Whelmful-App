import { useEffect, useState } from "react";

const KEY = "sanctuary.anon_session_id";

export function useAnonSession() {
  const [id, setId] = useState("");
  useEffect(() => {
    let v = localStorage.getItem(KEY);
    if (!v) {
      v = crypto.randomUUID();
      localStorage.setItem(KEY, v);
    }
    setId(v);
  }, []);
  return id;
}
