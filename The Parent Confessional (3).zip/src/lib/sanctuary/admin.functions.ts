type QueueRow = {
  id: string;
  title: string | null;
  public_quote: string | null;
  raw_transcript: string;
  deidentified_confession: string | null;
  tags: string[] | null;
  image_url: string | null;
  status: string;
  risk_level: string;
  publish_recommendation: string;
  clinical_flags: string[] | null;
  brain_characters: string[] | null;
  dominant_character: string | null;
  internal_formulation: Record<string, string> | null;
  support_count: number;
  created_at: string;
};

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function admin() {
  const mod = await import("@/integrations/supabase/client.server");
  return mod.supabaseAdmin as unknown as {
    from: (t: string) => {
      select: (cols: string) => {
        eq: (col: string, val: unknown) => {
          order: (col: string, opts: { ascending: boolean }) => {
            limit: (n: number) => Promise<{ data: Record<string, unknown>[] | null; error: { message: string } | null }>;
          };
        };
        in: (col: string, vals: unknown[]) => {
          order: (col: string, opts: { ascending: boolean }) => {
            limit: (n: number) => Promise<{ data: Record<string, unknown>[] | null; error: { message: string } | null }>;
          };
        };
        order: (col: string, opts: { ascending: boolean }) => {
          limit: (n: number) => Promise<{ data: Record<string, unknown>[] | null; error: { message: string } | null }>;
        };
      };
      update: (row: Record<string, unknown>) => {
        eq: (col: string, val: unknown) => Promise<{ error: { message: string } | null }>;
      };
      insert: (row: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
    };
  };
}

async function assertStaff(supabase: { from: (t: string) => { select: (c: string) => { eq: (col: string, val: unknown) => Promise<{ data: unknown[] | null; error: { message: string } | null }> } } }, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId);
  if (error) throw new Error("Could not verify staff");
  const roles = (data ?? []) as Array<{ role: string }>;
  const isStaff = roles.some((r) => r.role === "admin" || r.role === "moderator");
  if (!isStaff) throw new Error("Forbidden");
}

export const listModerationQueue = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ status: z.enum(["pending_moderation","published","rejected","private"]).default("pending_moderation") }).parse(input))
  .handler(async ({ context, data }) => {
    await assertStaff(context.supabase as never, context.userId);
    const supabaseAdmin = await admin();
    const { data: rows, error } = await supabaseAdmin
      .from("confessions")
      .select("id, title, public_quote, raw_transcript, deidentified_confession, tags, image_url, status, risk_level, publish_recommendation, clinical_flags, brain_characters, dominant_character, internal_formulation, support_count, created_at")
      .eq("status", data.status)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error("Could not load queue");
    return (rows ?? []) as unknown as QueueRow[];
  });

export const moderateConfession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    confession_id: z.string().uuid(),
    action: z.enum(["approve","reject","edit","delete","restore"]),
    public_quote: z.string().max(1000).optional(),
    title: z.string().max(200).optional(),
    notes: z.string().max(2000).optional(),
  }).parse(input))
  .handler(async ({ context, data }) => {
    await assertStaff(context.supabase as never, context.userId);
    const supabaseAdmin = await admin();
    const update: Record<string, unknown> = {};
    if (data.action === "approve") update.status = "published";
    if (data.action === "reject") update.status = "rejected";
    if (data.action === "delete") update.status = "deleted";
    if (data.action === "restore") update.status = "pending_moderation";
    if (data.public_quote !== undefined) update.public_quote = data.public_quote;
    if (data.title !== undefined) update.title = data.title;

    if (Object.keys(update).length > 0) {
      const { error } = await supabaseAdmin
        .from("confessions")
        .update(update)
        .eq("id", data.confession_id);
      if (error) throw new Error("Could not update confession");
    }
    await supabaseAdmin.from("moderation_events").insert({
      confession_id: data.confession_id,
      moderator_id: context.userId,
      action: data.action,
      notes: data.notes ?? null,
      diff: update,
    });
    return { ok: true };
  });