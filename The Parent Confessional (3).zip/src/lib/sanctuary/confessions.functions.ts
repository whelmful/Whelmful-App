import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { CONFESSION_PROCESSING_PROMPT } from "@/config/sanctuaryPrompt";

/**
 * prepareWallSubmissionText
 * Returns the user's ORIGINAL words unchanged by default. Only redacts
 * obvious identifying details (names, locations, contact info, school /
 * workplace names). NEVER paraphrases, softens, summarises, or replaces
 * the post with an AI reframe. Server-side risk-check still runs separately
 * via processConfession + submitConfession.
 */
export function prepareWallSubmissionText(originalDumpText: string): string {
  if (!originalDumpText) return "";
  let s = originalDumpText;

  // Emails
  s = s.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/gi, "[removed]");
  // Phone numbers (loose international / local)
  s = s.replace(/(?:\+?\d[\d\s().-]{7,}\d)/g, "[removed]");
  // URLs
  s = s.replace(/\bhttps?:\/\/\S+/gi, "[removed]");
  // Social handles
  s = s.replace(/(^|\s)@[A-Za-z0-9_.]{2,}/g, "$1[removed]");
  // Bracketed identifiers from earlier UI: [specific daycare name] -> [removed]
  s = s.replace(/\[[^\]]{2,80}\]/g, "[removed]");
  // Names of common relations followed by a proper-noun first name
  // e.g. "my daughter Mila", "my partner James", "with Sarah from..."
  s = s.replace(
    /\b(my (?:son|daughter|child|kid|baby|partner|husband|wife|boyfriend|girlfriend|mum|mom|mother|dad|father|sister|brother|friend|boss|neighbour|neighbor|therapist|doctor|midwife))\s+([A-Z][a-z]{1,20})\b/g,
    "$1",
  );
  // "with NAME" / "to NAME" / "at NAME's" — drop the proper noun, keep the connector
  s = s.replace(/\b(with|to|at|told|asked|saw|hugged|called|texted|messaged)\s+([A-Z][a-z]{2,20})('s)?\b/g, "$1 my person$3");
  // Daycare / school / workplace named like "X Daycare", "Y Childcare", "Z Primary School"
  s = s.replace(/\b([A-Z][A-Za-z'-]+(?:\s+[A-Z][A-Za-z'-]+){0,3})\s+(Daycare|Childcare|Kindergarten|Preschool|Primary School|High School|School|Hospital|Clinic|Practice)\b/g, "$2");

  return s;
}

const ProcessInput = z.object({
  transcript: z.string().trim().min(1).max(6000),
});

const ProcessedShape = z.object({
  transcript: z.string().default(""),
  deidentified_confession: z.string().default(""),
  public_quote: z.string().default(""),
  title: z.string().default(""),
  tags: z.array(z.string()).default([]),
  risk_level: z.enum(["low", "medium", "high", "urgent"]),
  publish_recommendation: z.enum(["allow_review", "hold_for_moderation", "block_publication"]),
  support_message: z.string().default(""),
  image_prompt: z.string().default(""),
  clinical_flags: z.array(z.string()).default([]),
  brain_characters: z
    .array(z.enum(["c1_thinking", "c2_feeling_past", "c3_feeling_present", "c4_thinking_present"]))
    .default([]),
  dominant_character: z
    .enum(["c1_thinking", "c2_feeling_past", "c3_feeling_present", "c4_thinking_present"])
    .nullable()
    .default(null),
  internal_formulation: z
    .object({
      emotional_state: z.string().optional(),
      body_state: z.string().optional(),
      core_need: z.string().optional(),
      protective_pattern: z.string().optional(),
      identity_belief: z.string().optional(),
      values_thread: z.string().optional(),
      response_goal: z.string().optional(),
    })
    .partial()
    .default({}),
});

export type ProcessedConfession = z.infer<typeof ProcessedShape>;

export const processConfession = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ProcessInput.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI not configured");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: CONFESSION_PROCESSING_PROMPT },
          { role: "user", content: `RAW TRANSCRIPT:\n${data.transcript}` },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "submit_processed_confession",
              description: "Return the de-identified processed confession.",
              parameters: {
                type: "object",
                properties: {
                  transcript: { type: "string" },
                  deidentified_confession: { type: "string" },
                  public_quote: { type: "string" },
                  title: { type: "string" },
                  tags: { type: "array", items: { type: "string" } },
                  risk_level: { type: "string", enum: ["low", "medium", "high", "urgent"] },
                  publish_recommendation: {
                    type: "string",
                    enum: ["allow_review", "hold_for_moderation", "block_publication"],
                  },
                  support_message: { type: "string" },
                  image_prompt: { type: "string" },
                  clinical_flags: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: [
                        "self_harm",
                        "suicide",
                        "child_safety",
                        "family_violence",
                        "substance_use",
                        "eating_disorder",
                        "birth_trauma",
                        "grief_loss",
                        "medical_trauma",
                        "intrusive_thoughts",
                        "social_isolation",
                        "acute_panic",
                        "severe_sleep_deprivation",
                      ],
                    },
                  },
                  brain_characters: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: ["c1_thinking","c2_feeling_past","c3_feeling_present","c4_thinking_present"],
                    },
                  },
                  dominant_character: {
                    type: "string",
                    enum: ["c1_thinking","c2_feeling_past","c3_feeling_present","c4_thinking_present"],
                  },
                  internal_formulation: {
                    type: "object",
                    properties: {
                      emotional_state: { type: "string" },
                      body_state: { type: "string" },
                      core_need: { type: "string" },
                      protective_pattern: { type: "string" },
                      identity_belief: { type: "string" },
                      values_thread: { type: "string" },
                      response_goal: { type: "string" },
                    },
                  },
                },
                required: [
                  "deidentified_confession",
                  "public_quote",
                  "title",
                  "tags",
                  "risk_level",
                  "publish_recommendation",
                  "support_message",
                  "image_prompt",
                  "clinical_flags",
                  "brain_characters",
                  "dominant_character",
                  "internal_formulation",
                ],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "submit_processed_confession" } },
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      console.error("processConfession upstream", res.status, t);
      throw new Error("Could not process confession");
    }
    const payload = await res.json();
    const args = payload?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) throw new Error("AI returned no structured result");
    const parsed = ProcessedShape.parse(JSON.parse(args));
    if (!parsed.transcript) parsed.transcript = data.transcript;
    return parsed;
  });

const SubmitInput = z.object({
  anonymous_session_id: z.string().min(8).max(64),
  processed: ProcessedShape,
  user_public_consent: z.boolean(),
});

type AdminClient = {
  from: (table: string) => {
    insert: (
      row: Record<string, unknown>,
    ) => { select: (cols: string) => { single: () => Promise<{ data: Record<string, unknown> | null; error: { message: string } | null }> }; then?: never };
    select: (cols: string) => {
      eq: (col: string, val: unknown) => {
        single: () => Promise<{ data: Record<string, unknown> | null; error: { message: string } | null }>;
        order: (
          col: string,
          opts: { ascending: boolean },
        ) => {
          limit: (n: number) => Promise<{ data: Record<string, unknown>[] | null; error: { message: string } | null }>;
        };
      };
    };
    update: (row: Record<string, unknown>) => {
      eq: (col: string, val: unknown) => Promise<{ error: { message: string } | null }> & {
        eq: (col: string, val: unknown) => Promise<{ error: { message: string } | null }>;
      };
    };
  };
  storage: {
    from: (bucket: string) => {
      upload: (
        path: string,
        body: Uint8Array,
        opts: { contentType: string; upsert: boolean },
      ) => Promise<{ error: { message: string } | null }>;
      getPublicUrl: (path: string) => { data: { publicUrl: string } };
    };
  };
  rpc: unknown;
};

async function admin(): Promise<AdminClient> {
  const mod = await import("@/integrations/supabase/client.server");
  return mod.supabaseAdmin as unknown as AdminClient;
}

export const submitConfession = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SubmitInput.parse(input))
  .handler(async ({ data }) => {
    const supabaseAdmin = await admin();
    const p = data.processed;

    let status: string;
    let withheld = false;
    let withheld_reason: string | null = null;
    if (
      p.publish_recommendation === "block_publication" ||
      p.risk_level === "urgent" ||
      p.risk_level === "high"
    ) {
      status = "private";
      withheld = true;
      withheld_reason =
        p.risk_level === "urgent"
          ? "urgent_safety"
          : p.publish_recommendation === "block_publication"
            ? "inappropriate_for_wall"
            : "high_risk";
    } else if (!data.user_public_consent) {
      status = "private";
    } else {
      // Human moderation gate: wall submissions go to pending_moderation
      // (a.k.a. "pending review") and only publish after admin approval.
      status = "pending_moderation";
    }

    const deletionCode = crypto.randomUUID().slice(0, 8);

    const { data: row, error } = await supabaseAdmin
      .from("confessions")
      .insert({
        anonymous_session_id: data.anonymous_session_id,
        deletion_code: deletionCode,
        raw_transcript: p.transcript,
        deidentified_confession: p.deidentified_confession,
        public_quote: p.public_quote,
        title: p.title,
        tags: p.tags,
        risk_level: p.risk_level,
        publish_recommendation: p.publish_recommendation,
        status,
        image_prompt: p.image_prompt,
        user_public_consent: data.user_public_consent,
        audio_deleted: true,
        clinical_flags: p.clinical_flags,
        brain_characters: p.brain_characters,
        dominant_character: p.dominant_character,
        internal_formulation: p.internal_formulation,
      })
      .select("id, status")
      .single();

    if (error || !row) {
      console.error("submitConfession insert", error);
      throw new Error("Could not save confession");
    }
    return {
      id: row.id as string,
      status: row.status as string,
      deletion_code: deletionCode,
      withheld,
      withheld_reason,
      risk_level: p.risk_level,
    };
  });

const ImageInput = z.object({
  confession_id: z.string().uuid(),
});

export const generateConfessionImage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ImageInput.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI not configured");
    const supabaseAdmin = await admin();

    const { data: row, error: fetchErr } = await supabaseAdmin
      .from("confessions")
      .select("id, public_quote, image_prompt, status")
      .eq("id", data.confession_id)
      .single();
    if (fetchErr || !row) throw new Error("Confession not found");
    const publicQuote = row.public_quote as string | null;
    const imagePrompt = row.image_prompt as string | null;
    const rowId = row.id as string;
    if (!publicQuote || !imagePrompt) throw new Error("No quote to render");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        prompt: imagePrompt,
        size: "1024x1024",
      }),
    });
    if (!res.ok) {
      const t = await res.text();
      console.error("image gen upstream", res.status, t);
      throw new Error("Image generation failed");
    }
    const payload = await res.json();
    const b64: string | undefined = payload?.data?.[0]?.b64_json;
    if (!b64) throw new Error("No image returned");

    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const path = `${rowId}.png`;
    const { error: upErr } = await supabaseAdmin.storage
      .from("confession-images")
      .upload(path, bytes, { contentType: "image/png", upsert: true });
    if (upErr) {
      console.error("storage upload", upErr);
      throw new Error("Could not save image");
    }
    const { data: pub } = supabaseAdmin.storage
      .from("confession-images")
      .getPublicUrl(path);
    const imageUrl = pub.publicUrl;

    await supabaseAdmin
      .from("confessions")
      .update({ image_url: imageUrl })
      .eq("id", rowId);

    return { image_url: imageUrl };
  });

const ReportInput = z.object({
  confession_id: z.string().uuid(),
  reason: z.enum(["identifying_information", "unsafe_content", "harmful_advice", "child_safety", "other"]),
  notes: z.string().trim().max(1000).optional().default(""),
});

export const reportConfession = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ReportInput.parse(input))
  .handler(async ({ data }) => {
    const supabaseAdmin = await admin();
    const { error } = await supabaseAdmin.from("confession_reports").insert({
      confession_id: data.confession_id,
      reason: data.reason,
      notes: data.notes,
    }).select("id").single();
    if (error) throw new Error("Could not submit report");
    await supabaseAdmin
      .from("confessions")
      .update({ status: "pending_moderation" })
      .eq("id", data.confession_id);
    return { ok: true };
  });

export const getPublishedConfessions = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await admin();
  const { data, error } = await supabaseAdmin
    .from("confessions")
    .select("id, title, public_quote, tags, image_url, support_count, created_at, dominant_character")
    .eq("status", "published")
    .order("created_at", { ascending: false })
    .limit(60);
  if (error) {
    // Table may not exist yet (pre-migration) — fail soft so the wall renders empty instead of erroring.
    console.warn("getPublishedConfessions: returning empty wall", error.message);
    return [] as Array<{
      id: string;
      title: string | null;
      public_quote: string;
      tags: string[] | null;
      image_url: string | null;
      support_count: number;
      created_at: string;
      dominant_character: string | null;
    }>;
  }
  return (data ?? []) as Array<{
    id: string;
    title: string | null;
    public_quote: string;
    tags: string[] | null;
    image_url: string | null;
    support_count: number;
    created_at: string;
    dominant_character: string | null;
  }>;
});

/** Increment the "I felt this too" support counter for a published confession. */
const SupportInput = z.object({ confession_id: z.string().uuid() });
export const supportConfession = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SupportInput.parse(input))
  .handler(async ({ data }) => {
    const supabaseAdmin = await admin();
    const { data: row, error } = await (supabaseAdmin.rpc as unknown as (
      fn: string,
      args: Record<string, unknown>,
    ) => Promise<{ data: number | null; error: { message: string } | null }>)(
      "increment_support_count",
      { _confession_id: data.confession_id },
    );
    if (error) throw new Error("Could not record support");
    return { count: row ?? 0 };
  });
