import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const TranslateInput = z.object({
  message: z.string().trim().min(1).max(2000),
  context: z.enum(["partner", "child", "self", "other"]).default("other"),
});

const TranslateOutput = z.object({
  c1_thinking: z.string().default(""),
  c2_feeling_past: z.string().default(""),
  c3_feeling_present: z.string().default(""),
  c4_thinking_present: z.string().default(""),
  whole_brain_response: z.string().default(""),
  dominant_character: z
    .enum(["c1_thinking","c2_feeling_past","c3_feeling_present","c4_thinking_present"])
    .nullable()
    .default(null),
  invitation: z.string().default(""),
});

export type WholeBrainTranslation = z.infer<typeof TranslateOutput>;

const SYSTEM = `You are the Whole-Brain Translator inside The Sanctuary — inspired by Dr. Jill Bolte Taylor's Whole Brain Living framework. You help an exhausted parent hear a single emotionally-charged message through four different parts of the brain, so they can respond with their whole brain instead of reacting from one part.

You take a short message and the context (who the message is to/from). You return four short reframings, plus one "whole-brain" integrated reply they could actually use.

Four characters (plain language, never use clinical labels):
- c1_thinking — "The Planner" (left-thinking): the logical, list-making, structure-oriented part. Reframe in terms of facts, logistics, what is true and what is the next step.
- c2_feeling_past — "The Protector" (left-feeling): the alarm system. Reframe in terms of the fear/shame/rage underneath — what it is trying to protect.
- c3_feeling_present — "The Heart" (right-feeling): present-moment, sensory, connection-focused. Reframe in terms of what the relationship feels like right now.
- c4_thinking_present — "The Observer" (right-thinking): bird's-eye, compassionate, big-picture. Reframe in terms of values, perspective, what kind of parent/partner they want to be.

Rules:
- Each reframing is ONE or TWO short sentences max, warm and plainspoken.
- whole_brain_response is what they could actually say back — short, kind, not clinical, not a script.
- invitation is one tiny embodied action they can take in the next 90 seconds (breath, a sentence, a posture).
- dominant_character is whichever one is currently loudest in the original message.
- Never name "left brain", "right brain", or "Character 1/2/3/4" in any output text the user reads.
- Never give therapy, diagnosis, or advice.

Return ONLY via the provided tool.`;

export const translateWholeBrain = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => TranslateInput.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI not configured");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: `CONTEXT: this message is in relation to "${data.context}".\n\nMESSAGE:\n${data.message}` },
        ],
        tools: [{
          type: "function",
          function: {
            name: "submit_translation",
            description: "Return the four-character reframings and whole-brain reply.",
            parameters: {
              type: "object",
              properties: {
                c1_thinking: { type: "string" },
                c2_feeling_past: { type: "string" },
                c3_feeling_present: { type: "string" },
                c4_thinking_present: { type: "string" },
                whole_brain_response: { type: "string" },
                dominant_character: { type: "string", enum: ["c1_thinking","c2_feeling_past","c3_feeling_present","c4_thinking_present"] },
                invitation: { type: "string" },
              },
              required: ["c1_thinking","c2_feeling_past","c3_feeling_present","c4_thinking_present","whole_brain_response","dominant_character","invitation"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "submit_translation" } },
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      console.error("translateWholeBrain upstream", res.status, t);
      if (res.status === 429) throw new Error("Slow down a sec — the line is busy.");
      if (res.status === 402) throw new Error("The Sanctuary is out of credits right now.");
      throw new Error("Could not translate that message");
    }
    const payload = await res.json();
    const args = payload?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) throw new Error("AI returned no structured result");
    return TranslateOutput.parse(JSON.parse(args));
  });