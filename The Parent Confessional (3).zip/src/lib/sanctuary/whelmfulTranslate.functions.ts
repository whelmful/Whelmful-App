import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { bodyBrainTranslatorSystemPrompt } from "@/config/bodyBrainTranslatorPrompt";

const TranslateInput = z.object({
  thought: z.string().trim().min(1).max(4000),
  emotion_tags: z.array(z.string().min(1).max(40)).max(20).default([]),
  time_of_day: z.string().max(60).optional().default(""),
  role_pressures: z.array(z.string().min(1).max(40)).max(10).default([]),
  values: z.array(z.string().min(1).max(40)).max(10).default([]),
});

const str = (def = "") => z.preprocess((v) => (typeof v === "string" ? v : v == null ? def : String(v)), z.string()).default(def);
const strArr = z.preprocess(
  (v) => (Array.isArray(v) ? v.filter((x) => typeof x === "string") : []),
  z.array(z.string()),
).default([]);

const CardTypeEnum = z.enum(["part", "whole_brain", "values", "nervous_system"]);

const SelectedCardSchema = z.object({
  id: str(""),
  name: str(""),
  type: z.preprocess(
    (v) => (typeof v === "string" && ["part","whole_brain","values","nervous_system"].includes(v) ? v : "part"),
    CardTypeEnum,
  ).default("part"),
  priority: z.preprocess(
    (v) => (typeof v === "number" && Number.isFinite(v) ? v : 99),
    z.number(),
  ).default(99),
  why_selected: str(""),
  what_it_might_be_saying: str(""),
  what_it_is_protecting: str(""),
  what_it_might_need: str(""),
  soft_response: str(""),
  question: str(""),
});

const DigDeeperSchema = z.object({
  additional_cards: z.array(SelectedCardSchema).default([]),
  reflection_questions: strArr,
  why_this_helps: str(""),
}).default({ additional_cards: [], reflection_questions: [], why_this_helps: "" });

const RiskEnum = z.preprocess(
  (v) => (typeof v === "string" && ["low","moderate","urgent"].includes(v) ? v : "low"),
  z.enum(["low", "moderate", "urgent"]),
).default("low");

const TranslateOutput = z.object({
  schema_version: str("1.0"),
  input_summary: str(""),
  tone_markers: strArr,
  risk_level: RiskEnum,
  validation: z.object({
    title: str("First, this makes sense"),
    body: str(""),
  }).default({ title: "First, this makes sense", body: "" }),
  nervous_system: z.object({
    title: str("What your system might be protecting you from"),
    body: str(""),
  }).default({ title: "What your system might be protecting you from", body: "" }),
  selected_cards: z.array(SelectedCardSchema).default([]),
  reframe: z.object({
    old_thought: str(""),
    new_thought: str(""),
    why_it_feels_lighter: str(""),
  }).default({ old_thought: "", new_thought: "", why_it_feels_lighter: "" }),
  values_bridge: z.object({
    selected_value: str(""),
    alignment_statement: str(""),
    tiny_values_question: str(""),
  }).default({ selected_value: "", alignment_statement: "", tiny_values_question: "" }),
  tiny_next_step: z.object({
    title: str("One tiny next step"),
    body: str(""),
    time_required: str(""),
    difficulty: z.preprocess(
      (v) => (typeof v === "string" && ["tiny","small","medium"].includes(v) ? v : "tiny"),
      z.enum(["tiny", "small", "medium"]),
    ).default("tiny"),
  }).default({ title: "One tiny next step", body: "", time_required: "", difficulty: "tiny" }),
  self_compassion_phrase: str(""),
  wall_safe_version: str(""),
  dig_deeper: DigDeeperSchema,
  safety_note: str(""),
  // Back-compat: the old client referenced crisis_detected.
  crisis_detected: z.boolean().default(false).optional(),
  // === Body-Brain Translator block (preferred user-facing surface) ===
  body_brain: z.object({
    body_clue: str(""),
    whats_loud: str(""),
    what_it_might_be_protecting: str(""),
    what_you_might_need: str(""),
    what_matters_underneath: str(""),
    kinder_sentence: str(""),
    one_tiny_move: str(""),
  }).default({
    body_clue: "", whats_loud: "", what_it_might_be_protecting: "",
    what_you_might_need: "", what_matters_underneath: "",
    kinder_sentence: "", one_tiny_move: "",
  }),
  internal_map: z.object({
    dominant_body_brain_state: str(""),
    dominant_pattern: str(""),
    dominant_need: str(""),
    dominant_value: str(""),
    tiny_move_category: str(""),
  }).default({
    dominant_body_brain_state: "", dominant_pattern: "",
    dominant_need: "", dominant_value: "", tiny_move_category: "",
  }),
  public_wall_safe: z.boolean().default(true),
  anonymous_wall_version: str(""),
  safety_message: str(""),
});

export type WhelmfulTranslation = z.infer<typeof TranslateOutput>;
export type SelectedCard = z.infer<typeof SelectedCardSchema>;

const SYSTEM = `You are the Whelmful Whole Brain Translator — a compassionate, parent-specific reflective companion (not a therapist, not a diagnostician, not an emergency service).

You help overwhelmed parents take a raw, shame-laden, rage-filled, guilty, fearful, resentful, lonely, or overstimulated thought and translate it into self-compassion, parts-informed reflection, Whole Brain Living perspective, ACT-style values alignment, and one tiny realistic next step.

TONE
Warm, intelligent, grounded, emotionally honest, parent-specific, non-judgemental, gently forward-moving. Like a wise friend who understands 3am.

VARIETY (CRITICAL)
Do NOT reuse the same phrasing across users. Do NOT produce generic template responses. Every output must be specifically shaped around the user's exact words, emotional tags, values, time of day, role pressure, and intensity of language. Vary metaphors, sentence structure, examples, and the tiny next step. Keep the psychological framework consistent — but make the language feel personally written for THIS parent in THIS moment. Quote or echo at least one short fragment of their own wording somewhere in the response. Never start two outputs the same way.

PRINCIPLES
- Self-compassion first.
- Parts-informed reflection (without IFS jargon, without claiming therapy).
- Whole Brain Living inspired perspective-taking.
- ACT-style values + committed action.
- Nervous-system informed plain language ("may", "might", "could", "one way to see this").
- Shame reduction. Repair over perfection. Values over performance.

AVOID
Diagnosis. Therapy claims. Medical certainty. Toxic positivity. "Just be grateful." Implying the parent is broken. Implying the thought is dangerous unless there is clear urgent risk. Jargon. Repetitive stock phrases. Calling the parent selfish, toxic, narcissistic, abusive, or unsafe.

USE LANGUAGE LIKE
"A part of you may be…", "This could be overload, not failure.", "Both can be true.", "You can love them and need space.", "This part may be trying to protect…", "The next step is not perfection — it is repair, support, or one honest pause."

SELECTED CARDS — CHOOSE ONLY WHAT IS RELEVANT
Return between 3 and 6 selected_cards. Self-select the most relevant ones based on the thought, emotional tags, time of day, role pressure, values, language intensity, and signs of shame, guilt, rage, fear, depletion, identity loss, resentment, loneliness, overstimulation, or needing space. DO NOT return every possible card. Prefer cards that match what is actually happening for THIS parent. Set priority=1 for most relevant down to priority=6.

Examples of when to choose what (illustrative — adapt freely):
- Rage / overstimulation → The Alarm, The Tired Body, The Protector, The Wise Self.
- Guilt / failure → The Inner Critic, The Wounded Protector, The Wise Whole Self, The Rational Planner.
- Resentment / needing space → The Protector, The Tired Body, The Values Step, The Wise Self.

Card 'type' must be one of: "part", "whole_brain", "values", "nervous_system".
Use names from this palette where they fit, and feel free to add a contextually relevant card with its own descriptive name:
- Parts: "The Protector", "The Alarm", "The Fixer", "The Inner Critic", "The Tired Body", "The Wise Self", "The Wounded Protector".
- Whole-brain: "The Rational Planner", "The Creative Connector", "The Wise Whole Self".
- Values: "The Values Step".

For each selected_card include:
- name (short, human, never blank).
- type.
- priority (1 = most relevant).
- why_selected (one short sentence — why this card, for THIS thought).
- what_it_might_be_saying (first-person voice of that part, 1–2 sentences).
- what_it_is_protecting.
- what_it_might_need.
- soft_response (warm reply TO the part, not to the user).
- question (one gentle reflective question).

DIG DEEPER
dig_deeper.additional_cards: 0–4 extra cards the parent could explore later (same shape as selected_cards, but lower relevance).
dig_deeper.reflection_questions: 2–4 questions tailored to this thought.
dig_deeper.why_this_helps: 1–2 sentences in plain language about why slowing down with parts and perspectives can ease pressure.

REFRAME
reframe.old_thought: a short paraphrase of their thought (use a fragment of their own wording).
reframe.new_thought: a believable, non-fake-positive sentence they could actually say to themselves.
reframe.why_it_feels_lighter: one short sentence — why this is gentler without dismissing the pain.

VALUES BRIDGE
values_bridge.selected_value: one value word (prefer one of the user's selected values; otherwise infer from their language — e.g. rest, connection, honesty, repair, self-respect, steadiness, support).
values_bridge.alignment_statement: one short sentence linking the reframe to that value.
values_bridge.tiny_values_question: one short question that helps the parent take a values-aligned next breath.

TINY NEXT STEP
tiny_next_step.title: short label (e.g. "One hand on your chest").
tiny_next_step.body: one realistic, tiny, doable action — not requiring calm or perfection.
tiny_next_step.time_required: e.g. "30 seconds", "2 minutes".
tiny_next_step.difficulty: "tiny" | "small" | "medium" (prefer "tiny").

OTHER FIELDS
- schema_version: "1.0".
- input_summary: one short sentence that paraphrases what the parent is carrying right now.
- tone_markers: 2–5 short tags describing the emotional weather (e.g. "depleted", "raw", "guilt-soaked", "wired-but-tired").
- validation.body: 1–3 sentences of self-compassionate validation, specific to their words.
- nervous_system.body: 2–4 sentences in plain language about what the body/brain might be doing.
- self_compassion_phrase: one short sentence they could repeat.
- wall_safe_version: a short (<280 chars), identifier-free version of THEIR thought (no names, ages, places, partner identifiers). Soft, human, in their voice, not over-polished.
- safety_note: gentle short line. If risk_level=urgent, explicit safety guidance (e.g. local emergency, Lifeline 13 11 14 AU, 988 US, Samaritans 116 123 UK). Otherwise: a soft reminder that this is reflective support, not therapy or emergency care.

RISK LEVEL
- "urgent" → user expresses imminent intent to harm themselves, their baby/child, or another person. When urgent: keep all fields gentle and safety-oriented; do not produce a normal upbeat reframe; reframe.new_thought should orient toward reaching support; tiny_next_step should be "reach one safe person or service now".
- "moderate" → distressing but no imminent intent.
- "low" → everyday parent overwhelm.

OUTPUT
Return ONLY via the submit_whelmful_translation tool. Every string field must be a non-empty plain string when meaningful; if a field truly does not apply, leave it as an empty string — never null, never undefined, never JSON inside a string.

----
BODY-BRAIN TRANSLATOR BLOCK (REQUIRED)

In addition to all fields above, also fill the body_brain block. This is the user's primary surface. It must be plain-language, warm, non-clinical, Australian English, and tailored to THIS user's words.

body_brain.body_clue — one sentence naming what the body might be doing (e.g. "Your body sounds like it is bracing"). No vagus nerve, no polyvagal, no trauma claims.
body_brain.whats_loud — one sentence naming what is loud in the mind / which protective voice is talking.
body_brain.what_it_might_be_protecting — one sentence naming what this reaction may be trying to protect.
body_brain.what_you_might_need — one sentence in plain language (rest, space, support, repair, less pressure, comfort, etc.).
body_brain.what_matters_underneath — one sentence naming the value still alive under the mess.
body_brain.kinder_sentence — one short first-person sentence that separates the person from the pattern.
body_brain.one_tiny_move — one tiny, doable, values-aligned behaviour. Not impressive. Not a therapy exercise. Not a wellness cliché.

Also fill internal_map (NEVER shown to the user, used internally):
- dominant_body_brain_state: one of alarm_mode, rulebook_mode, protect_me_mode, connection_mode, body_wisdom_mode, compass_mode.
- dominant_pattern: perfectionism, self_sacrifice, comparison, rage, withdrawal, numbing, control, people_pleasing, collapse, external_validation, avoidance, reassurance_seeking, disconnection.
- dominant_need: rest, support, space, safety, repair, connection, permission, validation, grief, clarity, body_safety, practical_help, less_pressure, boundary.
- dominant_value: love, honesty, freedom, steadiness, kindness, dignity, repair, connection, courage, rest, protection, trust, belonging, presence.
- tiny_move_category: body_anchor, support, repair, boundary, truth, lower_standard, practical, rest, connection, nature, movement.

public_wall_safe — false if the dump contains active risk, abuse admissions, named third parties, identifying detail that cannot be softened, or content that should not be public; true otherwise.
anonymous_wall_version — a soft, identifier-free, single-line version of the user's own truth suitable for an anonymous wall (no names, ages, places, partner/child identifiers). Empty string when public_wall_safe is false.
safety_message — empty string for low/moderate risk. For high/urgent risk, set a short message that gently directs the user toward Triple Zero, Lifeline 13 11 14 (AU), PANDA 1300 726 306 (perinatal AU), or local emergency services.

Forbidden user-facing words in body_brain output: ACT, CBT, IFS, EMDR, schema, schema therapy, Circle of Security, attachment theory, somatic therapy, polyvagal therapy, trauma response, dysregulation, vagus nerve, diagnosis, disorder, treatment, therapy, clinical, symptom, intervention, pathology, maladaptive, exposure.

--- WHELMFUL BODY-BRAIN GUIDANCE (silent, for shaping output) ---
${bodyBrainTranslatorSystemPrompt}`;

const SELECTED_CARD_SCHEMA = {
  type: "object",
  properties: {
    id: { type: "string" },
    name: { type: "string" },
    type: { type: "string", enum: ["part", "whole_brain", "values", "nervous_system"] },
    priority: { type: "number" },
    why_selected: { type: "string" },
    what_it_might_be_saying: { type: "string" },
    what_it_is_protecting: { type: "string" },
    what_it_might_need: { type: "string" },
    soft_response: { type: "string" },
    question: { type: "string" },
  },
  required: [
    "id","name","type","priority","why_selected","what_it_might_be_saying",
    "what_it_is_protecting","what_it_might_need","soft_response","question",
  ],
  additionalProperties: false,
} as const;

function safeFallback(input: z.infer<typeof TranslateInput>): WhelmfulTranslation {
  return TranslateOutput.parse({
    schema_version: "1.0",
    input_summary: input.thought.slice(0, 180),
    tone_markers: input.emotion_tags.slice(0, 5),
    risk_level: "low",
    validation: {
      title: "First, this makes sense",
      body: "What you wrote is real. You're carrying a lot, and naming it out loud takes more than most people see.",
    },
    nervous_system: {
      title: "What your system might be protecting you from",
      body: "Your body and brain might just be running on too little — too little rest, too little space, too much input. That isn't failure. That's a system asking for support.",
    },
    selected_cards: [
      {
        id: "fallback_part",
        name: "The part trying to protect you",
        type: "part",
        priority: 1,
        why_selected: "Your words sound like a part of you is working very hard right now.",
        what_it_might_be_saying: "I have to hold all of this or it will fall apart.",
        what_it_is_protecting: "Your sense of being a good parent, and the people you love.",
        what_it_might_need: "Permission to put one thing down.",
        soft_response: "Thank you for trying so hard. You're allowed to be tired here.",
        question: "What would it feel like to let one small thing be imperfect tonight?",
      },
    ],
    reframe: {
      old_thought: input.thought.slice(0, 160),
      new_thought: "This is overload, not failure. I'm allowed to take one slow breath before the next thing.",
      why_it_feels_lighter: "It doesn't argue with the pain — it just gives your nervous system a place to land.",
    },
    values_bridge: {
      selected_value: input.values[0] ?? "rest",
      alignment_statement: "Choosing one small pause is still in line with the kind of parent you want to be.",
      tiny_values_question: "What would one breath in line with my values look like right now?",
    },
    tiny_next_step: {
      title: "One slow breath",
      body: "Take one slow breath and ask: what do I need less of right now?",
      time_required: "30 seconds",
      difficulty: "tiny",
    },
    self_compassion_phrase: "I'm a human in a hard moment, not a bad parent.",
    wall_safe_version: "Some days I love them so much and still need to disappear for five minutes. Both are true.",
    dig_deeper: { additional_cards: [], reflection_questions: [], why_this_helps: "" },
    safety_note: "This is reflective support, not therapy or emergency care. If things feel unsafe, please reach a local crisis line.",
    crisis_detected: false,
    body_brain: {
      body_clue: "Your body sounds like it has been bracing for a while.",
      whats_loud: "The pressure voice is saying you should be coping perfectly.",
      what_it_might_be_protecting: "It may be trying to stop you from feeling like you have failed.",
      what_you_might_need: "Less pressure, more support, and a moment where no one needs anything from you.",
      what_matters_underneath: "Under this, steadiness and being a kind parent still matter.",
      kinder_sentence: "This is a hard moment, not my whole identity.",
      one_tiny_move: "Place one hand on something solid and let your shoulders drop one percent.",
    },
    internal_map: {
      dominant_body_brain_state: "alarm_mode",
      dominant_pattern: "perfectionism",
      dominant_need: "rest",
      dominant_value: "steadiness",
      tiny_move_category: "body_anchor",
    },
    public_wall_safe: true,
    anonymous_wall_version: "Some days I love them so much and still need to disappear for five minutes. Both are true.",
    safety_message: "",
  });
}

function tryParseJson(s: string): unknown {
  try { return JSON.parse(s); } catch { /* try repair */ }
  // Strip code fences, leading prose
  const m = s.match(/\{[\s\S]*\}$/);
  if (m) {
    try { return JSON.parse(m[0]); } catch { /* noop */ }
  }
  return null;
}

/** Parse, validate, fill defaults, drop empty cards, sort by priority. UI-safe. */
export function normaliseWhelmfulTranslateResponse(
  raw: unknown,
  input: z.infer<typeof TranslateInput>,
): WhelmfulTranslation {
  let candidate: unknown = raw;
  if (typeof candidate === "string") candidate = tryParseJson(candidate);
  const parsed = TranslateOutput.safeParse(candidate);
  const base = parsed.success ? parsed.data : safeFallback(input);

  // Drop empty/unnamed cards, sort by priority asc.
  const cleanCards = (cards: SelectedCard[]): SelectedCard[] =>
    cards
      .filter((c) => (c.name ?? "").trim().length > 0)
      .map((c) => ({ ...c, priority: Number.isFinite(c.priority) ? c.priority : 99 }))
      .sort((a, b) => a.priority - b.priority);

  base.selected_cards = cleanCards(base.selected_cards ?? []);
  base.dig_deeper.additional_cards = cleanCards(base.dig_deeper.additional_cards ?? []);

  // Ensure at least one card.
  if (base.selected_cards.length === 0) {
    base.selected_cards = [
      {
        id: "fallback_part",
        name: "The part trying to protect you",
        type: "part",
        priority: 1,
        why_selected: "Something in you is working hard right now.",
        what_it_might_be_saying: "I have to hold all of this.",
        what_it_is_protecting: "The people you love, and your sense of being a good parent.",
        what_it_might_need: "Permission to put one thing down.",
        soft_response: "Thank you for trying so hard. You're allowed to be tired here.",
        question: "What would it feel like to let one small thing be imperfect tonight?",
      },
    ];
  }

  // Fallback reframe.
  if (!base.reframe.new_thought.trim()) {
    base.reframe.new_thought =
      base.validation.body.trim() ||
      "This is overload, not failure. I'm allowed to take one slow breath before the next thing.";
  }
  if (!base.reframe.old_thought.trim()) {
    base.reframe.old_thought = input.thought.slice(0, 160);
  }

  // Fallback tiny next step.
  if (!base.tiny_next_step.body.trim()) {
    base.tiny_next_step.body = "Take one slow breath and ask: what do I need less of right now?";
    if (!base.tiny_next_step.time_required) base.tiny_next_step.time_required = "30 seconds";
    if (!base.tiny_next_step.title.trim()) base.tiny_next_step.title = "One slow breath";
  }

  // Infer a value if missing.
  if (!base.values_bridge.selected_value.trim()) {
    const inferred =
      input.values[0] ??
      inferValueFromLanguage(input.thought, input.emotion_tags) ??
      "rest";
    base.values_bridge.selected_value = inferred;
    if (!base.values_bridge.alignment_statement.trim()) {
      base.values_bridge.alignment_statement =
        `Choosing one small pause is still in line with ${inferred}.`;
    }
  }

  if (!base.validation.title.trim()) base.validation.title = "First, this makes sense";
  if (!base.nervous_system.title.trim()) {
    base.nervous_system.title = "What your system might be protecting you from";
  }
  if (!base.validation.body.trim()) {
    base.validation.body = "What you're carrying is real. Naming it is already brave.";
  }
  if (!base.nervous_system.body.trim()) {
    base.nervous_system.body =
      "Your body and brain might be on alert from too little rest and too much input. This is a system asking for support, not a sign you're broken.";
  }
  if (!base.self_compassion_phrase.trim()) {
    base.self_compassion_phrase = "I'm a human in a hard moment, not a bad parent.";
  }
  if (!base.wall_safe_version.trim()) {
    base.wall_safe_version =
      "Some days I love them and still need five minutes that's just mine. Both can be true.";
  }
  if (!base.safety_note.trim()) {
    base.safety_note =
      "This is reflective support, not therapy or emergency care.";
  }

  // Move overflow beyond top-4 into dig_deeper.additional_cards for default view.
  if (base.selected_cards.length > 4) {
    const overflow = base.selected_cards.slice(4);
    base.selected_cards = base.selected_cards.slice(0, 4);
    base.dig_deeper.additional_cards = [
      ...base.dig_deeper.additional_cards,
      ...overflow,
    ];
  }

  // Back-compat boolean for any older caller.
  base.crisis_detected = base.risk_level === "urgent";

  // Body-Brain backfill — if the model skipped the new block, derive from
  // the existing fields so the new UI always renders 7 cards.
  const bb = base.body_brain;
  if (!bb.body_clue.trim()) {
    bb.body_clue = base.nervous_system.body.split(/(?<=\.)\s/)[0] || "Your body might be bracing right now.";
  }
  if (!bb.whats_loud.trim()) {
    bb.whats_loud = base.selected_cards[0]?.what_it_might_be_saying
      || base.validation.body
      || "Something loud is asking for attention.";
  }
  if (!bb.what_it_might_be_protecting.trim()) {
    bb.what_it_might_be_protecting = base.selected_cards[0]?.what_it_is_protecting
      || "It may be trying to protect a part of you that has been carrying too much.";
  }
  if (!bb.what_you_might_need.trim()) {
    bb.what_you_might_need = base.selected_cards[0]?.what_it_might_need
      || "You might need less pressure, more support, and a moment where no one needs anything from you.";
  }
  if (!bb.what_matters_underneath.trim()) {
    const v = base.values_bridge.selected_value;
    bb.what_matters_underneath = base.values_bridge.alignment_statement
      || (v ? `Under this, ${v} still matters.` : "Under this, something still matters to you.");
  }
  if (!bb.kinder_sentence.trim()) {
    bb.kinder_sentence = base.reframe.new_thought
      || base.self_compassion_phrase
      || "This is a hard moment, not my whole identity.";
  }
  if (!bb.one_tiny_move.trim()) {
    bb.one_tiny_move = base.tiny_next_step.body
      || "Place one hand on something solid and let your shoulders drop one percent.";
  }

  if (!base.anonymous_wall_version.trim()) {
    base.anonymous_wall_version = base.wall_safe_version;
  }
  if (base.risk_level === "urgent" && !base.safety_message.trim()) {
    base.safety_message =
      "If you or someone else is in immediate danger, call Triple Zero now. For crisis support in Australia, contact Lifeline on 13 11 14. For perinatal mental health support, contact PANDA on 1300 726 306.";
  }
  if (base.risk_level === "urgent") base.public_wall_safe = false;

  return base;
}

function inferValueFromLanguage(thought: string, tags: string[]): string | null {
  const t = (thought + " " + tags.join(" ")).toLowerCase();
  if (/\b(tired|exhausted|sleep|burn(t|ed)? out|depleted|drained|touched out)\b/.test(t)) return "rest";
  if (/\b(rage|angry|furious|snap|yell)\b/.test(t)) return "steadiness";
  if (/\b(guilt|shame|failure|bad mum|bad mom|not enough)\b/.test(t)) return "self-respect";
  if (/\b(lonely|alone|invisible|unseen|isolated)\b/.test(t)) return "connection";
  if (/\b(resent|resentful|space|breathe|suffocat)\b/.test(t)) return "honesty";
  if (/\b(lost myself|identity|miss me|miss myself)\b/.test(t)) return "self-respect";
  if (/\b(repair|sorry|apologi[sz]e)\b/.test(t)) return "repair";
  return null;
}

/** Return only the cards to show in the default (non-deep) view. */
export function getVisibleTranslatorCards(r: WhelmfulTranslation): SelectedCard[] {
  return (r.selected_cards ?? [])
    .filter((c) => (c.name ?? "").trim().length > 0)
    .slice(0, 4);
}

export const whelmfulTranslate = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => TranslateInput.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI not configured");

    const contextLines: string[] = [];
    if (data.emotion_tags.length) contextLines.push(`Emotion tags: ${data.emotion_tags.join(", ")}`);
    if (data.time_of_day) contextLines.push(`Time of day / moment: ${data.time_of_day}`);
    if (data.role_pressures.length) contextLines.push(`Role pressures: ${data.role_pressures.join(", ")}`);
    if (data.values.length) contextLines.push(`Values they want to live by: ${data.values.join(", ")}`);

    const userContent = [
      "RAW THOUGHT FROM THE PARENT:",
      data.thought,
      "",
      contextLines.length ? "CONTEXT:\n" + contextLines.join("\n") : "CONTEXT: (none provided)",
      "",
      "Remember: tailor every field to THIS parent's exact wording, tags, time, role pressure, and values. Vary metaphors and sentence structure. Echo at least one short fragment of their own words.",
    ].join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        temperature: 0.9,
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: userContent },
        ],
        tools: [{
          type: "function",
          function: {
            name: "submit_whelmful_translation",
            description: "Return the full Whelmful translation as structured JSON.",
            parameters: {
              type: "object",
              properties: {
                schema_version: { type: "string" },
                input_summary: { type: "string" },
                tone_markers: { type: "array", items: { type: "string" } },
                risk_level: { type: "string", enum: ["low", "moderate", "urgent"] },
                validation: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    body: { type: "string" },
                  },
                  required: ["title", "body"],
                  additionalProperties: false,
                },
                nervous_system: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    body: { type: "string" },
                  },
                  required: ["title", "body"],
                  additionalProperties: false,
                },
                selected_cards: { type: "array", items: SELECTED_CARD_SCHEMA },
                reframe: {
                  type: "object",
                  properties: {
                    old_thought: { type: "string" },
                    new_thought: { type: "string" },
                    why_it_feels_lighter: { type: "string" },
                  },
                  required: ["old_thought", "new_thought", "why_it_feels_lighter"],
                  additionalProperties: false,
                },
                values_bridge: {
                  type: "object",
                  properties: {
                    selected_value: { type: "string" },
                    alignment_statement: { type: "string" },
                    tiny_values_question: { type: "string" },
                  },
                  required: ["selected_value", "alignment_statement", "tiny_values_question"],
                  additionalProperties: false,
                },
                tiny_next_step: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    body: { type: "string" },
                    time_required: { type: "string" },
                    difficulty: { type: "string", enum: ["tiny", "small", "medium"] },
                  },
                  required: ["title", "body", "time_required", "difficulty"],
                  additionalProperties: false,
                },
                self_compassion_phrase: { type: "string" },
                wall_safe_version: { type: "string" },
                dig_deeper: {
                  type: "object",
                  properties: {
                    additional_cards: { type: "array", items: SELECTED_CARD_SCHEMA },
                    reflection_questions: { type: "array", items: { type: "string" } },
                    why_this_helps: { type: "string" },
                  },
                  required: ["additional_cards", "reflection_questions", "why_this_helps"],
                  additionalProperties: false,
                },
                safety_note: { type: "string" },
                body_brain: {
                  type: "object",
                  properties: {
                    body_clue: { type: "string" },
                    whats_loud: { type: "string" },
                    what_it_might_be_protecting: { type: "string" },
                    what_you_might_need: { type: "string" },
                    what_matters_underneath: { type: "string" },
                    kinder_sentence: { type: "string" },
                    one_tiny_move: { type: "string" },
                  },
                  required: [
                    "body_clue","whats_loud","what_it_might_be_protecting",
                    "what_you_might_need","what_matters_underneath",
                    "kinder_sentence","one_tiny_move",
                  ],
                  additionalProperties: false,
                },
                internal_map: {
                  type: "object",
                  properties: {
                    dominant_body_brain_state: { type: "string" },
                    dominant_pattern: { type: "string" },
                    dominant_need: { type: "string" },
                    dominant_value: { type: "string" },
                    tiny_move_category: { type: "string" },
                  },
                  required: [
                    "dominant_body_brain_state","dominant_pattern",
                    "dominant_need","dominant_value","tiny_move_category",
                  ],
                  additionalProperties: false,
                },
                public_wall_safe: { type: "boolean" },
                anonymous_wall_version: { type: "string" },
                safety_message: { type: "string" },
              },
              required: [
                "schema_version","input_summary","tone_markers","risk_level",
                "validation","nervous_system","selected_cards",
                "reframe","values_bridge","tiny_next_step","self_compassion_phrase",
                "wall_safe_version","dig_deeper","safety_note",
                "body_brain","internal_map","public_wall_safe",
                "anonymous_wall_version","safety_message",
              ],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "submit_whelmful_translation" } },
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      console.error("whelmfulTranslate upstream", res.status, t);
      if (res.status === 429) throw new Error("The line is a little busy. Try again in a moment.");
      if (res.status === 402) throw new Error("The translator is out of credits right now.");
      // Soft-fail with safe fallback so the UI never crashes.
      return safeFallback(data);
    }

    const payload = await res.json();
    const args = payload?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) {
      console.warn("whelmfulTranslate: no tool args, using fallback");
      return safeFallback(data);
    }
    return normaliseWhelmfulTranslateResponse(args, data);
  });