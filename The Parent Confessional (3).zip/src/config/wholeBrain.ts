/**
 * Whole Brain Living (Dr. Jill Bolte Taylor) — internal language module.
 *
 * PUBLIC FRAMING RULES
 * - Never call this therapy, diagnosis, treatment, or assessment.
 * - Never claim to be Dr. Taylor or her organisation.
 * - Always credit "inspired by Dr. Jill Bolte Taylor's Whole Brain Living framework".
 * - Use everyday, parent-friendly language ("Planner / Protector / Heart / Observer").
 */

export type BrainCharacterId =
  | "c1_thinking"           // L-brain thinking — Character 1
  | "c2_feeling_past"       // L-brain emotional — Character 2
  | "c3_feeling_present"    // R-brain emotional — Character 3
  | "c4_thinking_present";  // R-brain thinking — Character 4

export type BrainCharacter = {
  id: BrainCharacterId;
  number: 1 | 2 | 3 | 4;
  short: string;            // friendly nickname
  hemisphere: "left" | "right";
  mode: "thinking" | "feeling";
  color: string;            // CSS var
  vibe: string;             // one-line description
  strengths: string[];
  shadow: string[];
  parentExample: string;
  invitation: string;       // how to invite this character forward
};

export const BRAIN_CHARACTERS: BrainCharacter[] = [
  {
    id: "c1_thinking",
    number: 1,
    short: "The Planner",
    hemisphere: "left",
    mode: "thinking",
    color: "var(--teal-dark)",
    vibe: "Lists, logistics, time, structure, getting things done.",
    strengths: ["organises the chaos", "follows through", "remembers the appointment"],
    shadow: ["rigid", "perfectionist", "all 'shoulds' and no softness"],
    parentExample: "The voice that lays out tomorrow's lunchboxes at 11pm and resents that no one helped.",
    invitation: "Hand the Planner ONE next-tiny-step. Let everything else go for ten minutes.",
  },
  {
    id: "c2_feeling_past",
    number: 2,
    short: "The Protector",
    hemisphere: "left",
    mode: "feeling",
    color: "var(--hot-pink)",
    vibe: "The loud emotional alarm: fear, shame, rage, old wounds, threat.",
    strengths: ["keeps you safe", "names danger", "draws lines"],
    shadow: ["catastrophises", "shame-spirals", "blames partner / kid / self"],
    parentExample: "The voice that screams 'I'm a bad mum' the moment a toddler kicks off in public.",
    invitation: "Acknowledge the alarm out loud — 'I see you, Protector, you think we're in danger' — then ground the body.",
  },
  {
    id: "c3_feeling_present",
    number: 3,
    short: "The Heart",
    hemisphere: "right",
    mode: "feeling",
    color: "var(--bubblegum)",
    vibe: "Now-ness, play, joy, awe, connection, music, snuggles.",
    strengths: ["fully present", "delights in small things", "co-regulates with the kid"],
    shadow: ["overwhelmed by sensation", "fawns to keep peace", "loses self in others"],
    parentExample: "The voice that catches your kid's giggle and forgets, for two seconds, that the kitchen is a war zone.",
    invitation: "Take 90 seconds. Feet on floor, two slow breaths, one ordinary thing your senses can love.",
  },
  {
    id: "c4_thinking_present",
    number: 4,
    short: "The Observer",
    hemisphere: "right",
    mode: "thinking",
    color: "var(--lavender)",
    vibe: "Bird's-eye view, compassion, big-picture wisdom, 'I am bigger than this moment'.",
    strengths: ["sees patterns", "holds perspective", "responds instead of reacts"],
    shadow: ["bypasses the body", "spiritualises away real pain"],
    parentExample: "The voice that whispers 'this is hard AND it is not the whole story' while your kid melts down.",
    invitation: "Name what you see without judging it. 'Here is exhaustion. Here is love. Both are true.'",
  },
];

/** Dr. Taylor's BRAIN protocol — a 90-second whole-brain check-in. */
export const BRAIN_HUDDLE_STEPS = [
  {
    letter: "B",
    word: "Breathe",
    prompt: "Take one slow breath. Notice your body for three seconds.",
    placeholder: "What does your body feel like right now? (one word is enough)",
  },
  {
    letter: "R",
    word: "Recognise",
    prompt: "Which character is loudest right now? Planner, Protector, Heart, or Observer?",
    placeholder: "Who's at the wheel? Why?",
  },
  {
    letter: "A",
    word: "Appreciate",
    prompt: "Thank that part for trying to help you. Even rage was trying to protect something.",
    placeholder: "What is this part trying to protect, take care of, or get for you?",
  },
  {
    letter: "I",
    word: "Inquire",
    prompt: "Ask the other three characters what they want you to know.",
    placeholder: "What would the Heart / Observer / Planner add?",
  },
  {
    letter: "N",
    word: "Navigate",
    prompt: "Choose the next tiny move — not the whole plan. Just the next ten minutes.",
    placeholder: "What is the next small, kind move?",
  },
] as const;

export function characterById(id: BrainCharacterId): BrainCharacter {
  return BRAIN_CHARACTERS.find((c) => c.id === id) ?? BRAIN_CHARACTERS[0];
}

export const WHOLE_BRAIN_PUBLIC_DISCLAIMER =
  "Inspired by Dr. Jill Bolte Taylor's Whole Brain Living framework. The Sanctuary is not therapy, diagnosis, or treatment — it is a tool for slowing down and noticing which part of you is at the wheel.";

export const DAILY_PRACTICES = [
  { id: "p1", title: "90-second pause", body: "When a feeling crashes in, give it 90 seconds before you act. The chemistry of an emotion clears in about that long — what stays after is a story you can choose to engage with." },
  { id: "p2", title: "Cross-body shake", body: "Stand up. Shake your right arm, then your left, then both. 30 seconds. Talks to both hemispheres at once." },
  { id: "p3", title: "Name the driver", body: "Out loud: 'Right now, my Protector is driving.' Naming it gives the Observer the wheel for a second." },
  { id: "p4", title: "Ordinary delight", body: "One ordinary thing in the room your Heart can love for ten seconds. The mug. The window. Your kid's eyelashes." },
  { id: "p5", title: "Repair sentence", body: "If you snapped: 'I lost it. That wasn't about you. I'm sorry, and I love you.' Repair builds neuroplasticity faster than perfect performance." },
  { id: "p6", title: "Whole-brain breath", body: "Inhale through the nose for 4, hold for 4, exhale through the mouth for 6. Three rounds. Brings the Planner offline and the Heart back online." },
  { id: "p7", title: "Tiny next move", body: "Ask the Planner for ONE next-tiny-step. Not the plan. The step." },
];
