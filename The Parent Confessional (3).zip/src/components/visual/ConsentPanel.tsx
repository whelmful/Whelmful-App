import { useState } from "react";
import { TiltCard } from "./TiltCard";
import { StickerLabel } from "./StickerLabel";

const CONSENT_ITEMS = [
  "I understand this is not a crisis service.",
  "I understand my confession may be de-identified before publication.",
  "I want to preview and approve anything before it is public.",
  "I am not including names, locations, or identifying details.",
];

export function ConsentPanel({ onAgree }: { onAgree: () => void }) {
  const [checked, setChecked] = useState<boolean[]>(CONSENT_ITEMS.map(() => false));
  const all = checked.every(Boolean);
  return (
    <TiltCard tilt={-0.5} background="var(--cream)" className="max-w-2xl">
      <StickerLabel variant="pink" rotation={-4}>Read this first</StickerLabel>
      <h2 className="mt-3 font-[family-name:var(--font-display)] text-2xl">
        Your confession is safe here.
      </h2>
      <p className="mt-2 text-[var(--charcoal)]/80">
        Your confession is anonymous, but please do not include names, addresses, schools, workplaces, children's names, or details that identify anyone. Your voice recording is used only to create a transcript and is deleted after processing. Public confessions are edited to remove identifying details and reviewed before publishing.
      </p>
      <ul className="mt-5 space-y-3">
        {CONSENT_ITEMS.map((item, i) => (
          <li key={i}>
            <label className="flex cursor-pointer items-start gap-3">
              <input
                type="checkbox"
                checked={checked[i]}
                onChange={(e) =>
                  setChecked((c) => c.map((v, idx) => (idx === i ? e.target.checked : v)))
                }
                className="mt-1 h-5 w-5 cursor-pointer accent-[var(--hot-pink)]"
              />
              <span className="text-[var(--charcoal)]">{item}</span>
            </label>
          </li>
        ))}
      </ul>
      <button
        onClick={onAgree}
        disabled={!all}
        className="btn-chunky mt-6 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Take me to the booth
      </button>
    </TiltCard>
  );
}
