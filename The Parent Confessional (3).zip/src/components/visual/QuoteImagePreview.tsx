import { StickerLabel } from "./StickerLabel";
import { Sparkle } from "./Sparkle";
import { Squiggle } from "./Squiggle";

export function QuoteImagePreview({
  quote,
  title,
  imageUrl,
}: {
  quote: string;
  title?: string | null;
  imageUrl?: string | null;
}) {
  if (imageUrl) {
    return (
      <div className="relative mx-auto max-w-md">
        <img
          src={imageUrl}
          alt={title ?? "Confession quote card"}
          className="block w-full rounded-2xl border-[3px] border-[var(--charcoal)] shadow-[6px_6px_0_var(--charcoal)]"
        />
      </div>
    );
  }
  return (
    <div className="relative mx-auto aspect-square max-w-md overflow-hidden rounded-2xl border-[4px] border-[var(--charcoal)] bg-[var(--mint)] p-8 shadow-[6px_6px_0_var(--charcoal)]">
      <Sparkle size={28} color="var(--hot-pink)" className="absolute top-3 left-4 wiggle" />
      <Sparkle size={22} color="var(--lavender)" className="absolute bottom-6 right-6 wiggle" />
      <div className="absolute top-3 right-4">
        <StickerLabel variant="pink" rotation={6}>The Sanctuary</StickerLabel>
      </div>
      <div className="flex h-full flex-col items-center justify-center text-center">
        <p className="font-[family-name:var(--font-display)] text-2xl font-bold leading-tight text-[var(--charcoal)]">
          "{quote}"
        </p>
        <div className="mt-4"><Squiggle width={90} color="var(--teal-dark)" /></div>
        {title && (
          <p className="mt-3 font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/70">
            {title}
          </p>
        )}
      </div>
    </div>
  );
}
