import { Mic, Square } from "lucide-react";

export function RecordButton({
  isRecording,
  seconds,
  maxSeconds = 60,
  onStart,
  onStop,
}: {
  isRecording: boolean;
  seconds: number;
  maxSeconds?: number;
  onStart: () => void;
  onStop: () => void;
}) {
  const remaining = Math.max(maxSeconds - seconds, 0);
  return (
    <div className="flex flex-col items-center gap-3">
      <button
        onClick={isRecording ? onStop : onStart}
        className="btn-chunky"
        style={{
          background: isRecording ? "var(--coral)" : "var(--hot-pink)",
          padding: "1.5rem 2rem",
          fontSize: "1.1rem",
        }}
        aria-pressed={isRecording}
      >
        {isRecording ? <Square size={20} fill="white" /> : <Mic size={22} />}
        {isRecording ? `Stop · ${remaining}s left` : "Start my one-minute confession"}
      </button>
      {isRecording && (
        <div className="flex items-center gap-2 text-sm text-[var(--coral)]">
          <span className="inline-block h-3 w-3 animate-pulse rounded-full bg-[var(--coral)]" />
          Recording…
        </div>
      )}
    </div>
  );
}
