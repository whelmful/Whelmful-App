import type { SVGProps } from "react";

// Legacy decorative squiggle — neutralised in the new Whelmful design system.
// Kept as a no-op so existing imports continue to compile without rendering
// busy background patterns.
export function Squiggle(_props: { width?: number; color?: string } & SVGProps<SVGSVGElement>) {
  return null;
}
