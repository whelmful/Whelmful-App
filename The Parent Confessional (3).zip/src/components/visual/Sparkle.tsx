import type { SVGProps } from "react";

export function Sparkle({ size = 28, color = "currentColor", ...props }: { size?: number; color?: string } & SVGProps<SVGSVGElement>) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" {...props}>
      <path
        d="M16 2 L18.5 13.5 L30 16 L18.5 18.5 L16 30 L13.5 18.5 L2 16 L13.5 13.5 Z"
        fill={color}
        stroke="var(--charcoal)"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
}
