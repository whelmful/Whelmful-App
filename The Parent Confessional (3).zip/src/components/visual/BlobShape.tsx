// Legacy decorative blob — neutralised in the new Whelmful design system.
// Returns null so floating blobs no longer render anywhere in the app.
export function BlobShape(_props: {
  size?: number;
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}) {
  return null;
}
