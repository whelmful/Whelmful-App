import { cn } from "@/lib/utils";

const variants = {
  peach: "bg-[var(--peach)]",
  mint: "bg-[var(--mint)]",
  pink: "bg-[var(--hot-pink)] text-[var(--paper)]",
  lavender: "bg-[var(--lavender)]",
  cream: "bg-[var(--cream)]",
  teal: "bg-[var(--teal)]",
} as const;

export function StickerLabel({
  children,
  variant = "peach",
  rotation = -3,
  className,
}: {
  children: React.ReactNode;
  variant?: keyof typeof variants;
  rotation?: number;
  className?: string;
}) {
  return (
    <span
      className={cn("sticker", variants[variant], className)}
      style={{ transform: `rotate(${rotation}deg)` }}
    >
      {children}
    </span>
  );
}
