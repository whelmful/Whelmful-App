import { TiltCard } from "./TiltCard";
import { StickerLabel } from "./StickerLabel";
import { Sparkle } from "./Sparkle";
import { CharacterBadge } from "./CharacterBadge";
import type { BrainCharacterId } from "@/config/wholeBrain";
import { Heart, Share2, Flag } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface ConfessionCardData {
  id: string;
  title: string | null;
  public_quote: string;
  tags: string[] | null;
  image_url: string | null;
  support_count: number;
  dominant_character?: string | null;
}

const tiltSeed = (id: string) => {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return ((h % 7) - 3) * 0.6;
};

export function ConfessionCard({
  confession,
  onReport,
}: {
  confession: ConfessionCardData;
  onReport?: (id: string) => void;
}) {
  const [supported, setSupported] = useState(false);
  const [count, setCount] = useState(confession.support_count);

  const handleSupport = async () => {
    if (supported) return;
    setSupported(true);
    setCount((c) => c + 1);
    const { data, error } = await (supabase.rpc as unknown as (
      fn: string,
      args: Record<string, unknown>,
    ) => Promise<{ data: number | null; error: { message: string } | null }>)(
      "increment_support_count",
      { _confession_id: confession.id },
    );
    if (error) {
      setSupported(false);
      setCount((c) => c - 1);
      return;
    }
    if (typeof data === "number") setCount(data);
  };

  const handleShare = async () => {
    const url = typeof window !== "undefined" ? `${window.location.origin}/confessions#${confession.id}` : "";
    const text = `"${confession.public_quote}" — from The Sanctuary`;
    try {
      if (typeof navigator !== "undefined" && (navigator as Navigator & { share?: (data: ShareData) => Promise<void> }).share) {
        await (navigator as Navigator & { share: (data: ShareData) => Promise<void> }).share({ text, url });
      } else {
        await navigator.clipboard.writeText(`${text}\n${url}`);
        toast.success("Copied. Send it to someone who needs it.");
      }
    } catch {
      /* user cancelled */
    }
  };

  return (
    <TiltCard tilt={tiltSeed(confession.id)} className="flex flex-col gap-3" background="white">
      {confession.image_url ? (
        <div className="relative overflow-hidden rounded-2xl border-[3px] border-[var(--charcoal)]">
          <img
            src={confession.image_url}
            alt={confession.title ?? "Anonymous confession quote card"}
            loading="lazy"
            className="block w-full h-auto"
          />
        </div>
      ) : (
        <div className="rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--mint-light)] p-5">
          <p className="font-[family-name:var(--font-display)] text-xl leading-snug text-[var(--charcoal)]">
            "{confession.public_quote}"
          </p>
        </div>
      )}

      {confession.title && (
        <h3 className="font-[family-name:var(--font-chunky)] text-lg text-[var(--charcoal)]">
          {confession.title}
        </h3>
      )}

      {confession.tags && confession.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {confession.tags.slice(0, 4).map((t, i) => (
            <StickerLabel key={t} variant={i % 2 ? "lavender" : "mint"} rotation={i % 2 ? 2 : -2}>
              #{t}
            </StickerLabel>
          ))}
        </div>
      )}

      {confession.dominant_character && (
        <div><CharacterBadge id={confession.dominant_character as BrainCharacterId} size="sm" /></div>
      )}

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button
          onClick={handleSupport}
          disabled={supported}
          className="btn-chunky mint text-sm disabled:opacity-90"
          style={{ paddingBlock: "0.55rem", paddingInline: "1rem" }}
        >
          <Heart size={16} fill={supported ? "var(--hot-pink)" : "none"} />
          {supported ? "Yeah. You are not the only one." : "I felt this too"}
          {count > 0 && <span className="ml-1 text-[var(--charcoal)]/70">· {count}</span>}
        </button>
        <button onClick={handleShare} className="btn-chunky cream text-sm" style={{ paddingBlock: "0.55rem", paddingInline: "1rem" }}>
          <Share2 size={16} /> Send to someone
        </button>
        <button
          onClick={() => onReport?.(confession.id)}
          className="ml-auto inline-flex items-center gap-1 text-xs text-[var(--charcoal)]/60 hover:text-[var(--coral)]"
        >
          <Flag size={12} /> Report
        </button>
      </div>

      <Sparkle size={20} color="var(--hot-pink)" className="absolute -top-2 -right-2 wiggle" style={{ position: "absolute" }} />
    </TiltCard>
  );
}
