import { characterById, type BrainCharacterId } from "@/config/wholeBrain";

export function CharacterBadge({ id, size = "md" }: { id: BrainCharacterId; size?: "sm" | "md" }) {
  const c = characterById(id);
  const padding = size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-3 py-1 text-xs";
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border-2 border-[var(--charcoal)] font-[family-name:var(--font-chunky)] uppercase tracking-wider ${padding}`}
      style={{ background: c.color, color: c.hemisphere === "left" ? "white" : "var(--charcoal)" }}
    >
      <span className="opacity-80">C{c.number}</span> {c.short}
    </span>
  );
}