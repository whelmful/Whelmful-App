import type { SVGProps } from "react";

export function DoodleArrow({ size = 80, color = "var(--charcoal)", flip = false, ...props }: { size?: number; color?: string; flip?: boolean } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 80 80"
      fill="none"
      style={{ transform: flip ? "scaleX(-1)" : undefined }}
      {...props}
    >
      <path
        d="M8 60 C 20 20, 50 18, 70 38"
        stroke={color}
        strokeWidth="3.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M60 30 L70 38 L62 48"
        stroke={color}
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}
