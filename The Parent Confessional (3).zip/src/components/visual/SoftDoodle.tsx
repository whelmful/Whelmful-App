/**
 * Minimal, intentional doodles. Used sparingly — one or two per viewport.
 * No floating animations, no random placement.
 */
import type { CSSProperties } from "react";

type Props = { size?: number; color?: string; className?: string; style?: CSSProperties };

export function TinyHeart({ size = 18, color = "var(--w-apricot)", className, style }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} style={style} aria-hidden>
      <path
        d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

export function TinyStar({ size = 18, color = "var(--w-apricot)", className, style }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} style={style} aria-hidden>
      <path
        d="M12 3v6M12 15v6M3 12h6M15 12h6"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function DoodleUnderline({ color = "var(--w-apricot)", className, style }: { color?: string; className?: string; style?: CSSProperties }) {
  return (
    <svg viewBox="0 0 160 14" width="100%" height="10" className={className} style={style} aria-hidden>
      <path
        d="M3 9 C 40 2, 90 14, 157 5"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

export function TapeNote({ children, rotation = -1.5, className }: { children: React.ReactNode; rotation?: number; className?: string }) {
  return (
    <div
      className={className}
      style={{
        background: "var(--w-warm-cream)",
        border: "1px solid rgba(47,47,47,0.12)",
        borderRadius: 14,
        padding: "0.85rem 1rem",
        transform: `rotate(${rotation}deg)`,
        boxShadow: "0 6px 18px rgba(47,47,47,0.06)",
        color: "var(--w-charcoal)",
      }}
    >
      {children}
    </div>
  );
}

export function NextArrow({ size = 28, color = "var(--w-apricot)", className }: { size?: number; color?: string; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" className={className} aria-hidden>
      <path
        d="M5 22 C 14 12, 26 12, 33 20 M33 20 l -6 -3 M33 20 l -3 6"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}