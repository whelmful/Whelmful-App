import { cn } from "@/lib/utils";

export function TiltCard({
  children,
  className,
  tilt = -1.5,
  background = "var(--cream)",
  style,
}: {
  children: React.ReactNode;
  className?: string;
  tilt?: number;
  background?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={cn("tilt-card paper-card p-6", className)}
      style={{ transform: `rotate(${tilt}deg)`, background, ...style }}
    >
      {children}
    </div>
  );
}
