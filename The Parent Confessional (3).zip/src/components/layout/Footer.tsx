import { Link } from "@tanstack/react-router";
import { DAILY_PRACTICES } from "@/config/wholeBrain";

export function Footer() {
  // Rotate a tiny whole-brain micropractice per hour — taught quietly, never labelled.
  const idx = Math.floor(Date.now() / (1000 * 60 * 60)) % DAILY_PRACTICES.length;
  const practice = DAILY_PRACTICES[idx];
  return (
    <footer className="relative z-10 mx-auto mt-24 max-w-6xl px-5 pb-10 wm-ui text-sm" style={{ color: "var(--wm-espresso)" }}>
      <div className="mb-5 wm-card" style={{ background: "var(--wm-lime)" }}>
        <p className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
          One tiny thing for right now
        </p>
        <p className="mt-1 wm-display text-xl">
          {practice.title}.
        </p>
        <p className="mt-1" style={{ opacity: 0.85 }}>{practice.body}</p>
      </div>
      <div className="wm-card" style={{ background: "var(--wm-warm-white)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="wm-display text-lg">
            For reflection and support, not emergency care.
          </p>
          <Link to="/resources" className="wm-btn wm-btn-pink" style={{ minHeight: 42, padding: "0.55rem 1.1rem", fontSize: "0.9rem" }}>
            Need urgent help?
          </Link>
        </div>
        <p className="mt-3 text-[13px]" style={{ opacity: 0.8 }}>
          Whelmful is a reflection and anonymous-connection space. It is not therapy, diagnosis, treatment, medical advice, or crisis support.
          If you or someone else is in immediate danger, contact your local emergency services. In Australia: Triple Zero (000), Lifeline 13 11 14, PANDA 1300 726 306.
        </p>
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs">
          <Link to="/about" className="underline underline-offset-4">About</Link>
          <Link to="/resources" className="underline underline-offset-4">Resources</Link>
          <Link to="/free-guide" className="underline underline-offset-4">Free guide</Link>
          <Link to="/whole-brain" className="underline underline-offset-4">Whole Brain</Link>
          <Link to="/huddle" className="underline underline-offset-4">Huddle</Link>
          <Link to="/translator" className="underline underline-offset-4">Translator</Link>
        </div>
        <p className="mt-4 wm-marker text-base" style={{ color: "var(--wm-olive)" }}>
          made with mess + tenderness — for mums in the thick of it.
        </p>
      </div>
    </footer>
  );
}
