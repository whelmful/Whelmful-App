import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

// Primary nav: 4 obvious options. Translator + Whole Brain remain available as
// secondary "More tools" inside the drawer; they still have standalone routes.
const primary = [
  { to: "/app", label: "Start" },
  { to: "/confessions", label: "Wall" },
  { to: "/translator", label: "Translator" },
  { to: "/saved-notes", label: "Saved Notes" },
  { to: "/resources", label: "Resources" },
] as const;

const secondary = [
  { to: "/about", label: "About" },
  { to: "/one-tiny-good-thing", label: "One Tiny Good Thing" },
  { to: "/whole-brain", label: "Whole Brain" },
  { to: "/huddle", label: "Huddle" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="relative z-30 mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 pt-6">
      <Link to="/" className="group flex items-center gap-2" onClick={() => setOpen(false)}>
        <span
          className="wm-display text-2xl sm:text-3xl"
        >
          Whelmful<span style={{ color: "var(--wm-terracotta)" }}>.</span>
        </span>
        <span className="wm-sticker wm-sticker-pink hidden sm:inline-block" style={{ transform: "rotate(-6deg)" }}>3am safe</span>
      </Link>

      {/* Desktop nav */}
      <nav className="hidden lg:flex flex-wrap items-center gap-x-2 gap-y-2 text-sm font-semibold wm-ui" style={{ color: "var(--wm-espresso)" }}>
        {primary.map((l) => (
          <Link
            key={l.to}
            to={l.to}
            className="rounded-full px-3 py-2 hover:bg-[var(--wm-warm-white)]"
            activeProps={{ className: "rounded-full bg-[var(--wm-warm-white)] px-3 py-2" }}
          >
            {l.label}
          </Link>
        ))}
        <Link to="/app" className="wm-btn wm-btn-primary text-sm" style={{ minHeight: 40, padding: "0.5rem 1rem" }}>
          Start a dump
        </Link>
      </nav>

      {/* Mobile toggle */}
      <button
        type="button"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-full"
        style={{ background: "var(--wm-warm-white)", border: "2px solid var(--wm-espresso)", boxShadow: "3px 3px 0 0 var(--wm-espresso)" }}
      >
        {open ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile drawer */}
      {open && (
        <div className="absolute left-0 right-0 top-full z-40 mt-3 lg:hidden">
          <nav
            className="mx-5 rounded-3xl p-4 wm-ui"
            style={{
              background: "var(--wm-warm-white)",
              border: "2px solid var(--wm-espresso)",
              boxShadow: "6px 6px 0 0 var(--wm-espresso)",
            }}
          >
            <ul className="flex flex-col gap-1 text-base font-semibold" style={{ color: "var(--wm-espresso)" }}>
              {primary.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block min-h-11 rounded-2xl px-4 py-3 hover:bg-[var(--wm-cream)]"
                    activeProps={{ className: "block min-h-11 rounded-2xl bg-[var(--wm-cream)] px-4 py-3" }}
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
              <li className="mt-2 px-3 text-[11px] uppercase tracking-[0.18em]" style={{ color: "var(--wm-olive)" }}>
                More tools
              </li>
              {secondary.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block min-h-11 rounded-2xl px-4 py-3 text-sm hover:bg-[var(--wm-cream)]"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
              <li className="pt-2">
                <Link
                  to="/app"
                  onClick={() => setOpen(false)}
                  className="wm-btn wm-btn-primary w-full"
                >
                  Start a dump
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
}
