import type { CSSProperties, ReactNode } from "react";

type Tone = "cream" | "paper" | "blush" | "lilac" | "butter" | "olive";

const BG: Record<Tone, string> = {
  cream: "var(--cream)",
  paper: "var(--paper)",
  blush: "var(--blush)",
  lilac: "var(--lilac)",
  butter: "var(--butter)",
  olive: "var(--olive)",
};

type Props = {
  children: ReactNode;
  tone?: Tone;
  tape?: boolean;
  rotate?: number;
  className?: string;
  style?: CSSProperties;
};

/** A simple paper / sticky note card. Used for saved entries and wall items. */
export function PaperCard({ children, tone = "paper", tape, rotate = 0, className, style }: Props) {
  return (
    <div
      className={className}
      style={{
        position: "relative",
        background: BG[tone],
        color: tone === "olive" ? "var(--paper)" : "var(--charcoal)",
        border: "1.5px solid rgba(47,47,47,0.18)",
        borderRadius: 22,
        padding: "1.1rem 1.2rem",
        boxShadow: "4px 4px 0 rgba(47,47,47,0.12)",
        transform: rotate ? `rotate(${rotate}deg)` : undefined,
        ...style,
      }}
    >
      {tape && (
        <span
          aria-hidden
          style={{
            position: "absolute",
            top: -10,
            left: "50%",
            transform: "translateX(-50%) rotate(-4deg)",
            width: 90,
            height: 18,
            background: "rgba(242, 198, 107, 0.85)",
            border: "1px solid rgba(47,47,47,0.18)",
            borderRadius: 2,
          }}
        />
      )}
      {children}
    </div>
  );
}