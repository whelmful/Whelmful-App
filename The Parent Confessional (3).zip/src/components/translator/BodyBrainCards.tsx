import type { WhelmfulTranslation } from "@/lib/sanctuary/whelmfulTranslate.functions";
import { TINY_MOVE_OPTIONS } from "@/config/bodyBrainTranslatorPrompt";
import { useState } from "react";

type Card = { sticker: string; body: string; tone: "blush" | "lilac" | "butter" | "apricot" | "cream" | "lime" };

const TONE: Record<Card["tone"], { bg: string; sticker: string; fg: string }> = {
  blush:   { bg: "var(--wm-blush)",       sticker: "wm-sticker-pink",     fg: "var(--wm-espresso)" },
  lilac:   { bg: "var(--wm-lavender)",    sticker: "wm-sticker-lavender", fg: "var(--wm-espresso)" },
  butter:  { bg: "var(--wm-butter)",      sticker: "",                    fg: "var(--wm-espresso)" },
  apricot: { bg: "var(--wm-apricot)",     sticker: "wm-sticker-apricot",  fg: "#FFFDF8" },
  cream:   { bg: "var(--wm-warm-white)",  sticker: "",                    fg: "var(--wm-espresso)" },
  lime:    { bg: "var(--wm-lime)",        sticker: "wm-sticker-lime",     fg: "var(--wm-espresso)" },
};

function Tile({ card, index }: { card: Card; index: number }) {
  const t = TONE[card.tone];
  const tilt = index % 2 === 0 ? -0.4 : 0.5;
  return (
    <div className="wm-card" style={{ background: t.bg, transform: `rotate(${tilt}deg)` }}>
      <span className={`wm-sticker ${t.sticker}`}>{card.sticker}</span>
      <p className="mt-3 text-base md:text-lg" style={{ color: t.fg, lineHeight: 1.5 }}>
        {card.body}
      </p>
    </div>
  );
}

export function BodyBrainCards({
  translation,
  onChooseTinyMove,
}: {
  translation: WhelmfulTranslation;
  onChooseTinyMove?: (move: string) => void;
}) {
  const bb = translation.body_brain;
  const [picked, setPicked] = useState<string | null>(null);

  if (!bb || !bb.body_clue) return null;

  const cards: Card[] = [
    { sticker: "Body clue",                  body: bb.body_clue,                  tone: "lilac"   },
    { sticker: "What's loud right now",      body: bb.whats_loud,                 tone: "blush"   },
    { sticker: "What it might be protecting",body: bb.what_it_might_be_protecting,tone: "cream"   },
    { sticker: "What you might actually need",body: bb.what_you_might_need,       tone: "butter"  },
    { sticker: "What matters underneath",    body: bb.what_matters_underneath,    tone: "lime"    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2">
        {cards.map((c, i) => <Tile key={c.sticker} card={c} index={i} />)}
      </div>

      {/* A kinder sentence */}
      {bb.kinder_sentence && (
        <div className="wm-card" style={{ background: "var(--wm-warm-white)", borderColor: "var(--wm-bubblegum)", borderWidth: 3 }}>
          <span className="wm-sticker wm-sticker-pink">A kinder sentence</span>
          <p className="mt-3 text-2xl md:text-3xl" style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.2 }}>
            &ldquo;{bb.kinder_sentence}&rdquo;
          </p>
        </div>
      )}

      {/* One tiny move */}
      {bb.one_tiny_move && (
        <div className="wm-card" style={{ background: "var(--wm-apricot)" }}>
          <span className="wm-sticker wm-sticker-apricot">One tiny move</span>
          <p className="mt-3 text-2xl md:text-3xl" style={{ fontFamily: "var(--font-display)", color: "#FFFDF8", lineHeight: 1.25 }}>
            {bb.one_tiny_move}
          </p>
          <p className="mt-3 text-xs uppercase tracking-[0.16em]" style={{ color: "#FFFDF8", opacity: 0.9 }}>
            What tiny move feels most doable?
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {TINY_MOVE_OPTIONS.map((m) => (
              <button
                key={m}
                type="button"
                className="wm-chip"
                data-on={picked === m}
                onClick={() => { setPicked(m); onChooseTinyMove?.(m); }}
              >
                {m}
              </button>
            ))}
          </div>
          {picked && (
            <p className="wm-marker mt-4 text-lg" style={{ color: "#FFFDF8" }}>
              Good. Not impressive. Doable. That is the point.
            </p>
          )}
        </div>
      )}
    </div>
  );
}