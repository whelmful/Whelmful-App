import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Copy, Lock, Sparkles, Bookmark, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import {
  whelmfulTranslate,
  getVisibleTranslatorCards,
  type WhelmfulTranslation,
  type SelectedCard,
} from "@/lib/sanctuary/whelmfulTranslate.functions";
import {
  processConfession,
  submitConfession,
  prepareWallSubmissionText,
} from "@/lib/sanctuary/confessions.functions";
import { useAnonSession } from "@/lib/sanctuary/useAnonSession";
import { BodyBrainCards } from "@/components/translator/BodyBrainCards";

const PLACEHOLDERS = [
  "I love my baby but I want to run away tonight.",
  "I feel like a terrible mum because I need space.",
  "I resent everyone needing me.",
  "I miss my old life and then I feel guilty for thinking that.",
  "I feel like I am failing even though I am doing everything.",
];

const EMOTION_CHIPS = [
  "touched out","rage","guilt","resentment","shame","lonely","invisible",
  "overstimulated","not good enough","identity loss","panic spiral",
  "sensory overload","grief","pressure","exhaustion","needing space","missing myself",
];

const TIMES = [
  "3am","5pm witching hour","after bedtime","before school/daycare",
  "during a feed","after an argument","after a long day",
];

const ROLES = [
  "mother","partner","worker","daughter","friend","household manager",
  "the one who holds everything",
];

const VALUES = [
  "calm","connection","honesty","freedom","rest","play","presence","repair",
  "self-respect","kindness","courage","boundaries",
];

const LOADING_LINES = [
  "Listening for the part underneath…",
  "Finding the softer truth…",
  "Translating without judgement…",
];

const PART_COLORS: Record<string, { bg: string; sticker: string }> = {
  "The Protector":   { bg: "var(--wm-lavender)", sticker: "wm-sticker-lavender" },
  "The Alarm":       { bg: "var(--wm-apricot)",  sticker: "wm-sticker-apricot" },
  "The Fixer":       { bg: "var(--wm-butter)",   sticker: "wm-sticker" },
  "The Inner Critic":{ bg: "var(--wm-blush)",    sticker: "wm-sticker-pink" },
  "The Tired Body":  { bg: "#CDB4E7",            sticker: "wm-sticker-lavender" },
  "The Wise Self":   { bg: "var(--wm-lime)",     sticker: "wm-sticker-lime" },
  "The Wounded Protector": { bg: "var(--wm-blush)", sticker: "wm-sticker-pink" },
  "The Rational Planner":  { bg: "var(--wm-warm-white)", sticker: "wm-sticker" },
  "The Creative Connector":{ bg: "var(--wm-butter)", sticker: "wm-sticker" },
  "The Wise Whole Self":   { bg: "var(--wm-lime)",  sticker: "wm-sticker-lime" },
  "The Values Step":       { bg: "var(--wm-lime)",  sticker: "wm-sticker-lime" },
};

type Props = {
  onBusyChange?: (b: boolean) => void;
  initialThought?: string;
  initialTags?: string[];
};

export function WhelmfulTranslator({ onBusyChange, initialThought, initialTags }: Props) {
  const [thought, setThought] = useState(initialThought ?? "");
  const [tags, setTags] = useState<string[]>(initialTags ?? []);
  const [time, setTime] = useState<string>("");
  const [roles, setRoles] = useState<string[]>([]);
  const [values, setValues] = useState<string[]>([]);
  const [showContext, setShowContext] = useState(false);

  const [busy, setBusy] = useState(false);
  const [loadingIdx, setLoadingIdx] = useState(0);
  const [result, setResult] = useState<WhelmfulTranslation | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [confirmPost, setConfirmPost] = useState(false);
  const [postText, setPostText] = useState("");
  const [posting, setPosting] = useState(false);
  const [withheldNotice, setWithheldNotice] = useState<null | { reason: string | null }>(null);
  const [digDeeper, setDigDeeper] = useState(false);

  const translateFn = useServerFn(whelmfulTranslate);
  const processFn = useServerFn(processConfession);
  const submitFn = useServerFn(submitConfession);
  const sessionId = useAnonSession();
  const outputRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    onBusyChange?.(busy);
  }, [busy, onBusyChange]);

  useEffect(() => {
    if (!busy) return;
    const t = setInterval(() => setLoadingIdx((i) => (i + 1) % LOADING_LINES.length), 1800);
    return () => clearInterval(t);
  }, [busy]);

  const placeholder = useMemo(
    () => PLACEHOLDERS[Math.floor(Math.random() * PLACEHOLDERS.length)],
    [],
  );

  const toggle = (setter: React.Dispatch<React.SetStateAction<string[]>>) => (v: string) => {
    setter((cur) => (cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v]));
  };

  const run = async (overrideThought?: string) => {
    const text = (overrideThought ?? thought).trim();
    if (!text) {
      toast("Start with the messy version. Even one sentence is enough.");
      return;
    }
    setBusy(true);
    setError(null);
    setResult(null);
    setWithheldNotice(null);
    setDigDeeper(false);
    try {
      const r = await translateFn({
        data: {
          thought: text,
          emotion_tags: tags,
          time_of_day: time,
          role_pressures: roles,
          values,
        },
      });
      setResult(r);
      // Wall preview must use the user's ORIGINAL words (only redacted),
      // never the AI's reframe or softened "wall_safe_version".
      setPostText(prepareWallSubmissionText(text));
      setTimeout(() => outputRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    } catch (e) {
      const msg = (e as Error).message || "Something glitched. Your thought is still valid. Try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  const dontKnow = () => {
    const seed =
      "I don't even know what I feel right now. Everything is loud and I am tired and I just want to disappear for a minute without anyone needing me.";
    setThought(seed);
    void run(seed);
  };

  const saveLocally = (label: string, payload: unknown) => {
    try {
      const key = "whelmful.translator.private";
      const raw = typeof window !== "undefined" ? window.localStorage.getItem(key) : null;
      const list = raw ? (JSON.parse(raw) as unknown[]) : [];
      list.unshift({ label, at: new Date().toISOString(), payload });
      window.localStorage.setItem(key, JSON.stringify(list.slice(0, 50)));
      toast("Saved privately on this device.");
    } catch {
      toast.error("Couldn't save locally.");
    }
  };

  const addToLight = () => {
    if (!result) return;
    try {
      const raw = typeof window !== "undefined" ? window.localStorage.getItem("whelmful.light") : null;
      const list = raw ? (JSON.parse(raw) as Array<{ text: string; at: string }>) : [];
      list.unshift({
        text: result.reframe.new_thought || result.self_compassion_phrase || "A softer truth.",
        at: new Date().toISOString(),
      });
      window.localStorage.setItem("whelmful.light", JSON.stringify(list.slice(0, 100)));
      toast("Added to your Light list.");
    } catch {
      toast.error("Couldn't add to Light list.");
    }
  };

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast("Copied.");
    } catch {
      toast.error("Copy failed.");
    }
  };

  const postAnon = async () => {
    const text = postText.trim();
    if (!text) {
      toast("Write a short version first.");
      return;
    }
    setPosting(true);
    setWithheldNotice(null);
    try {
      // Risk-check only — do NOT use the AI-rewritten text. Post the user's exact words.
      const processed = await processFn({ data: { transcript: text } });
      const submitted = await submitFn({
        data: {
          anonymous_session_id: sessionId,
          processed: {
            ...processed,
            public_quote: text,
            deidentified_confession: text,
          },
          user_public_consent: true,
        },
      });
      if (submitted.withheld) {
        setWithheldNotice({ reason: submitted.withheld_reason });
        toast("This one needs support, not the wall. Please reach out for immediate help now.");
      } else {
        toast("Submitted for review. If approved, it will appear anonymously on the wall.");
        setConfirmPost(false);
      }
    } catch (e) {
      console.error(e);
      toast.error("Couldn't post that right now. It is still safe and private.");
    } finally {
      setPosting(false);
    }
  };

  const reset = () => {
    setResult(null);
    setError(null);
    setConfirmPost(false);
    setPostText("");
    setWithheldNotice(null);
    setDigDeeper(false);
  };

  return (
    <div>
      {/* INPUT CARD — confessional booth */}
      <div
        className="wm-card wm-card-lg"
        style={{
          background: "var(--wm-warm-white)",
          padding: "1.5rem",
        }}
      >
        <div className="flex flex-wrap items-center gap-2">
          <span className="wm-sticker">
            <Lock size={12} style={{ display: "inline", marginRight: 4 }} />
            Private by default
          </span>
          <span className="wm-sticker wm-sticker-pink">No judgement</span>
        </div>

        <h2
          className="mt-4 text-2xl md:text-3xl"
          style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.15 }}
        >
          What&rsquo;s the thought you don&rsquo;t want to say out loud?
        </h2>
        <p className="mt-2 text-sm" style={{ color: "var(--wm-espresso)", opacity: 0.75 }}>
          You don&rsquo;t have to make it pretty. Start with the messy version.
        </p>

        <textarea
          value={thought}
          onChange={(e) => setThought(e.target.value)}
          rows={5}
          maxLength={4000}
          placeholder={`e.g. "${placeholder}"`}
          className="w-textarea mt-4"
        />
        <div className="mt-1 text-right text-xs" style={{ color: "var(--wm-espresso)", opacity: 0.5 }}>
          {thought.length} / 4000
        </div>

        {/* Emotion chips */}
        <div className="mt-4">
          <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
            What&rsquo;s underneath? (optional)
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {EMOTION_CHIPS.map((c) => (
              <button
                key={c}
                type="button"
                className="wm-chip"
                data-on={tags.includes(c)}
                onClick={() => toggle(setTags)(c)}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowContext((s) => !s)}
          className="mt-4 text-xs underline"
          style={{ color: "var(--wm-olive)" }}
        >
          {showContext ? "Hide context" : "Add a little more context (optional)"}
        </button>

        {showContext && (
          <div className="mt-3 space-y-4 rounded-2xl p-4" style={{ background: "var(--wm-cream)" }}>
            <ChipGroup label="Time of day / moment" options={TIMES} value={time ? [time] : []} onToggle={(v) => setTime(time === v ? "" : v)} single />
            <ChipGroup label="Role pressure right now" options={ROLES} value={roles} onToggle={toggle(setRoles)} />
            <ChipGroup label="Values you want to live by" options={VALUES} value={values} onToggle={toggle(setValues)} />
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => run()}
            disabled={busy || !thought.trim()}
            className="wm-btn wm-btn-primary"
          >
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                {LOADING_LINES[loadingIdx]}
              </>
            ) : (
              <>
                <Sparkles size={16} /> Translate this
              </>
            )}
          </button>
          <button
            type="button"
            onClick={dontKnow}
            disabled={busy}
            className="wm-btn wm-btn-cream"
          >
            I don&rsquo;t know what I feel
          </button>
        </div>

        {error && (
          <p className="mt-4 text-sm" style={{ color: "var(--wm-wine)" }}>
            {error}
          </p>
        )}
      </div>

      {/* OUTPUT */}
      <div ref={outputRef}>
        {result && (
          <div className="mt-8 space-y-6">
            {result.risk_level === "urgent" && (
              <CrisisBanner note={result.safety_note} />
            )}

            {/* PRIMARY: Body-Brain Translator cards */}
            {result.risk_level !== "urgent" && (
              <BodyBrainCards translation={result} />
            )}

            {/* Validation */}
            <SectionCard
              sticker={result.validation.title || "First, this makes sense"}
              stickerVariant="wm-sticker-pink"
              background="var(--wm-blush)"
            >
              <p
                className="text-xl md:text-2xl"
                style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.3 }}
              >
                {result.validation.body || "What you’re carrying is real."}
              </p>
            </SectionCard>

            {/* Nervous system */}
            <SectionCard
              sticker={result.nervous_system.title || "What your system might be protecting you from"}
              stickerVariant="wm-sticker-lavender"
              background="var(--wm-lavender)"
            >
              <p className="text-base md:text-lg" style={{ color: "var(--wm-espresso)", lineHeight: 1.55 }}>
                {result.nervous_system.body}
              </p>
            </SectionCard>

            {/* Top selected cards (max 4) */}
            {getVisibleTranslatorCards(result).length > 0 && (
              <div>
                <div className="mb-3 flex items-center gap-3">
                  <span className="wm-sticker wm-sticker-apricot">The parts that showed up</span>
                  <span className="wm-marker text-xl" style={{ color: "var(--wm-olive)" }}>
                    not a diagnosis — a way to listen
                  </span>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  {getVisibleTranslatorCards(result).map((c, i) => (
                    <CardTile key={(c.id || c.name) + i} card={c} index={i} />
                  ))}
                </div>
              </div>
            )}

            {/* Reframe */}
            <SectionCard
              sticker="The reframe"
              stickerVariant="wm-sticker-pink"
              background="var(--wm-warm-white)"
              accentBorder="var(--wm-bubblegum)"
            >
              {result.reframe.old_thought && (
                <>
                  <p className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
                    instead of
                  </p>
                  <p className="mt-1 text-base line-through" style={{ color: "var(--wm-espresso)", opacity: 0.65 }}>
                    {result.reframe.old_thought}
                  </p>
                </>
              )}
              <p className="mt-4 text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
                try
              </p>
              <p
                className="mt-1 text-2xl md:text-3xl"
                style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.2 }}
              >
                “{result.reframe.new_thought}”
              </p>
              {result.reframe.why_it_feels_lighter && (
                <p className="mt-3 text-sm" style={{ color: "var(--wm-espresso)", opacity: 0.8 }}>
                  {result.reframe.why_it_feels_lighter}
                </p>
              )}
              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => copy(result.reframe.new_thought)} className="wm-btn wm-btn-cream">
                  <Copy size={14} /> Copy reframe
                </button>
                <button onClick={addToLight} className="wm-btn wm-btn-butter">
                  <Bookmark size={14} /> Add to my Light list
                </button>
              </div>
            </SectionCard>

            {/* Values bridge */}
            {(result.values_bridge.selected_value || result.values_bridge.alignment_statement) && (
              <SectionCard
                sticker={`Your values bridge${result.values_bridge.selected_value ? " · " + result.values_bridge.selected_value : ""}`}
                stickerVariant="wm-sticker-lime"
                background="var(--wm-lime)"
              >
                <p className="text-lg" style={{ color: "var(--wm-espresso)", lineHeight: 1.5 }}>
                  {result.values_bridge.alignment_statement}
                </p>
                {result.values_bridge.tiny_values_question && (
                  <p className="wm-marker mt-3 text-lg" style={{ color: "var(--wm-wine)" }}>
                    {result.values_bridge.tiny_values_question}
                  </p>
                )}
              </SectionCard>
            )}

            {/* Tiny next step — always renders something usable */}
            <SectionCard
              sticker="One tiny thing for right now"
              stickerVariant="wm-sticker-apricot"
              background="var(--wm-apricot)"
            >
              <p className="text-xs uppercase tracking-[0.16em]" style={{ color: "#FFFDF8", opacity: 0.9 }}>
                Tiny next move
              </p>
              <p
                className="mt-2 text-2xl md:text-3xl"
                style={{ fontFamily: "var(--font-display)", color: "#FFFDF8", lineHeight: 1.25 }}
              >
                {(() => {
                  const tns: unknown = result.tiny_next_step;
                  if (typeof tns === "string" && tns.trim()) return tns;
                  if (tns && typeof tns === "object") {
                    const o = tns as { body?: unknown; title?: unknown };
                    if (typeof o.body === "string" && o.body.trim()) return o.body;
                    if (typeof o.title === "string" && o.title.trim()) return o.title;
                  }
                  const v = result.values_bridge.selected_value;
                  return v
                    ? `Take one slow breath and ask: what would ${v} look like in the next minute?`
                    : "Take one slow breath and ask: what do I need less of right now?";
                })()}
              </p>
                {result.tiny_next_step.time_required && (
                  <p className="mt-2 text-xs uppercase tracking-wider" style={{ color: "#FFFDF8", opacity: 0.85 }}>
                    takes about {result.tiny_next_step.time_required}
                  </p>
                )}
                {result.self_compassion_phrase && (
                  <p
                    className="wm-marker mt-4 text-xl"
                    style={{ color: "#FFFDF8" }}
                  >
                    say to yourself: “{result.self_compassion_phrase}”
                  </p>
                )}
              <button
                type="button"
                className="wm-btn wm-btn-cream mt-4"
                onClick={() => {
                  try {
                    if (typeof window !== "undefined") {
                      const key = "whelmful.tiny.steps";
                      const raw = window.localStorage.getItem(key);
                      const list = raw ? (JSON.parse(raw) as Array<{ text: string; at: string }>) : [];
                      const text =
                        (typeof result.tiny_next_step === "object" && result.tiny_next_step?.body) ||
                        "Take one slow breath.";
                      list.unshift({ text: String(text), at: new Date().toISOString() });
                      window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
                    }
                    toast("Saved — you said you’ll try this.");
                  } catch {
                    /* ignore */
                  }
                }}
              >
                I’ll try this
              </button>
            </SectionCard>

            {/* Dig deeper */}
            <div>
              <button
                type="button"
                className="wm-btn wm-btn-cream"
                onClick={() => setDigDeeper((s) => !s)}
              >
                {digDeeper ? <><ChevronUp size={14}/> Hide deeper view</> : <><ChevronDown size={14}/> Dig deeper</>}
              </button>
              {digDeeper && (
                <div className="mt-4 space-y-6">
                  {result.dig_deeper.additional_cards.length > 0 && (
                    <div>
                      <div className="mb-3 flex items-center gap-3">
                        <span className="wm-sticker wm-sticker-lavender">Another way to see it</span>
                      </div>
                      <div className="grid gap-4 md:grid-cols-2">
                        {result.dig_deeper.additional_cards.map((c, i) => (
                          <CardTile key={(c.id || c.name) + "extra" + i} card={c} index={i} />
                        ))}
                      </div>
                    </div>
                  )}
                  {result.dig_deeper.reflection_questions.length > 0 && (
                    <div className="wm-card" style={{ background: "var(--wm-warm-white)" }}>
                      <span className="wm-sticker wm-sticker-pink">Sit with these</span>
                      <ul className="mt-3 list-disc pl-5 space-y-2" style={{ color: "var(--wm-espresso)" }}>
                        {result.dig_deeper.reflection_questions.filter(Boolean).map((q, i) => (
                          <li key={i}>{q}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {result.dig_deeper.why_this_helps && (
                    <div className="wm-card" style={{ background: "var(--wm-cream)" }}>
                      <span className="wm-sticker">Why this helps</span>
                      <p className="mt-3" style={{ color: "var(--wm-espresso)", lineHeight: 1.55 }}>
                        {result.dig_deeper.why_this_helps}
                      </p>
                    </div>
                  )}
                  {result.wall_safe_version && (
                    <div className="wm-card" style={{ background: "var(--wm-butter)" }}>
                      <span className="wm-sticker">Wall-safe version</span>
                      <p className="mt-3 italic" style={{ color: "var(--wm-espresso)" }}>
                        “{result.wall_safe_version}”
                      </p>
                      <p className="mt-2 text-xs" style={{ color: "var(--wm-espresso)", opacity: 0.7 }}>
                        An identifier-free version you could post anonymously. Your words, just softer at the edges.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Safety note */}
            {result.safety_note && result.risk_level !== "urgent" && (
              <p className="text-xs" style={{ color: "var(--wm-espresso)", opacity: 0.7 }}>
                {result.safety_note}
              </p>
            )}

            {/* Actions */}
            <div className="wm-card" style={{ background: "var(--wm-cream)" }}>
              <p
                className="text-xl"
                style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)" }}
              >
                What you can do with this
              </p>
              <div className="mt-3 flex flex-wrap gap-3">
                <button
                  className="wm-btn wm-btn-cream"
                  onClick={() => saveLocally("translation", { thought, tags, time, roles, values, result })}
                >
                  <Lock size={14} /> Save privately
                </button>
                <button
                  className="wm-btn wm-btn-pink"
                  onClick={() => {
                    setConfirmPost(true);
                    setPostText(prepareWallSubmissionText(thought));
                  }}
                >
                  Post anonymously to the wall
                </button>
                <button className="wm-btn wm-btn-butter" onClick={() => run()}>
                  Try another perspective
                </button>
                <button className="wm-btn wm-btn-ghost" onClick={reset}>
                  Start another translation
                </button>
              </div>

              {confirmPost && (
                <div className="mt-4 rounded-2xl p-4" style={{ background: "var(--wm-warm-white)", border: "2px solid var(--wm-espresso)" }}>
                  <p
                    className="text-lg"
                    style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)" }}
                  >
                    Post this anonymously?
                  </p>
                  <p className="mt-1 text-sm" style={{ color: "var(--wm-espresso)", opacity: 0.8 }}>
                    Your name will not be shown. Your words stay yours — we only remove names, places, identifying details, or unsafe content.
                    Nothing publishes automatically — a human moderator reviews it first.
                  </p>
                  <textarea
                    className="w-textarea mt-3"
                    rows={4}
                    maxLength={500}
                    value={postText}
                    onChange={(e) => setPostText(e.target.value)}
                  />
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      onClick={postAnon}
                      disabled={posting || !postText.trim()}
                      className="wm-btn wm-btn-primary"
                    >
                      {posting ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</> : "Submit for review"}
                    </button>
                    <button
                      onClick={() => setConfirmPost(false)}
                      className="wm-btn wm-btn-cream"
                    >
                      Keep private
                    </button>
                  </div>
                  {withheldNotice && (
                    <div className="mt-4 rounded-2xl p-4" style={{ background: "#F2C6C6", border: "2px solid var(--wm-wine)" }}>
                      <p className="text-sm" style={{ color: "var(--wm-espresso)" }}>
                        We didn’t post this to the wall — it sounded too heavy to leave un-held.
                        You’re not in trouble. Please reach a real person who can support you right now:
                      </p>
                      <ul className="mt-2 list-disc pl-5 text-sm" style={{ color: "var(--wm-espresso)" }}>
                        <li>Immediate danger: your local emergency number (000 AU · 911 US · 999 UK).</li>
                        <li>Australia — Lifeline 13 11 14 · PANDA 1300 726 306</li>
                        <li>US — 988 Suicide &amp; Crisis Lifeline</li>
                        <li>UK — Samaritans 116 123</li>
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ChipGroup({
  label, options, value, onToggle, single,
}: {
  label: string;
  options: string[];
  value: string[];
  onToggle: (v: string) => void;
  single?: boolean;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
        {label}{single ? " (pick one)" : ""}
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o}
            type="button"
            className="wm-chip"
            data-on={value.includes(o)}
            onClick={() => onToggle(o)}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}

function SectionCard({
  sticker, stickerVariant, background, accentBorder, children,
}: {
  sticker: string;
  stickerVariant: string;
  background: string;
  accentBorder?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="wm-card"
      style={{
        background,
        borderColor: accentBorder ?? undefined,
        borderWidth: accentBorder ? 3 : undefined,
      }}
    >
      <span className={`wm-sticker ${stickerVariant}`}>{sticker}</span>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function Dl({ label, value }: { label: string; value: string }) {
  if (!value) return null;
  return (
    <div className="mt-3">
      <p className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
        {label}
      </p>
      <p className="mt-1 text-sm" style={{ color: "var(--wm-espresso)" }}>{value}</p>
    </div>
  );
}

function CardTile({ card, index }: { card: SelectedCard; index: number }) {
  const c = PART_COLORS[card.name] ?? { bg: "var(--wm-warm-white)", sticker: "wm-sticker" };
  const tilt = index % 2 === 0 ? -0.4 : 0.5;
  return (
    <div
      className="wm-card"
      style={{ background: c.bg, transform: `rotate(${tilt}deg)` }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className={`wm-sticker ${c.sticker}`}>{card.name}</span>
        {card.type && card.type !== "part" && (
          <span className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
            {card.type.replace("_", " ")}
          </span>
        )}
      </div>
      {card.why_selected && (
        <p className="mt-2 text-xs italic" style={{ color: "var(--wm-olive)" }}>
          why this one: {card.why_selected}
        </p>
      )}
      {card.what_it_might_be_saying && (
        <p className="mt-3 italic" style={{ color: "var(--wm-espresso)" }}>
          “{card.what_it_might_be_saying}”
        </p>
      )}
      <Dl label="trying to protect" value={card.what_it_is_protecting} />
      <Dl label="what it might need" value={card.what_it_might_need} />
      {card.soft_response && (
        <div className="mt-3 rounded-xl p-3" style={{ background: "var(--wm-warm-white)" }}>
          <p className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
            a softer response
          </p>
          <p className="mt-1 text-sm" style={{ color: "var(--wm-espresso)" }}>
            {card.soft_response}
          </p>
        </div>
      )}
      {card.question && (
        <p className="wm-marker mt-3 text-lg" style={{ color: "var(--wm-wine)" }}>
          {card.question}
        </p>
      )}
    </div>
  );
}

function CrisisBanner({ note }: { note: string }) {
  return (
    <div
      className="wm-card"
      style={{ background: "#F2C6C6", borderColor: "var(--wm-wine)", borderWidth: 3 }}
    >
      <span className="wm-sticker" style={{ background: "var(--wm-wine)", color: "#FFFDF8" }}>
        Pause — this matters more than this app can hold
      </span>
      <p className="mt-3 text-base" style={{ color: "var(--wm-espresso)" }}>
        {note ||
          "What you wrote sounds heavy. If you or someone else is in immediate danger, please contact your local emergency services."}
      </p>
      <ul className="mt-3 list-disc pl-5 text-sm" style={{ color: "var(--wm-espresso)" }}>
        <li>In immediate danger: call your local emergency number (e.g. 000 in AU, 911 in US, 999 in UK).</li>
        <li>Australia — Lifeline 13 11 14 · PANDA (perinatal) 1300 726 306</li>
        <li>US — 988 Suicide &amp; Crisis Lifeline</li>
        <li>UK — Samaritans 116 123</li>
      </ul>
    </div>
  );
}