import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { TiltCard } from "@/components/visual/TiltCard";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { CharacterBadge } from "@/components/visual/CharacterBadge";
import type { BrainCharacterId } from "@/config/wholeBrain";
import { supabase } from "@/integrations/supabase/client";
import { listModerationQueue, moderateConfession } from "@/lib/sanctuary/admin.functions";
import { generateConfessionImage } from "@/lib/sanctuary/confessions.functions";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

type Status = "pending_moderation" | "published" | "rejected" | "private";

export const Route = createFileRoute("/admin/moderation")({
  head: () => ({
    meta: [
      { title: "Moderation queue — The Sanctuary" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: ModerationPage,
});

function ModerationPage() {
  const nav = useNavigate();
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<Status>("pending_moderation");
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(false);
  const listFn = useServerFn(listModerationQueue);
  const modFn = useServerFn(moderateConfession);
  const imgFn = useServerFn(generateConfessionImage);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (!data.user) nav({ to: "/auth" });
      else setReady(true);
    });
  }, [nav]);

  useEffect(() => {
    if (!ready) return;
    let cancelled = false;
    setLoading(true);
    listFn({ data: { status } })
      .then((r) => { if (!cancelled) setRows(r as Array<Record<string, unknown>>); })
      .catch((e) => {
        toast.error((e as Error).message);
        if ((e as Error).message.includes("Forbidden")) {
          toast.error("Signed in but not a moderator yet. Ask an admin to grant you the role.");
        }
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [ready, status, listFn]);

  const refresh = async () => {
    setLoading(true);
    try { setRows(await listFn({ data: { status } }) as Array<Record<string, unknown>>); }
    finally { setLoading(false); }
  };

  const act = async (id: string, action: "approve" | "reject" | "delete" | "restore", patch?: { public_quote?: string; title?: string }) => {
    try {
      await modFn({ data: { confession_id: id, action, ...patch } });
      toast.success(`Marked as ${action}.`);
      refresh();
    } catch (e) {
      toast.error((e as Error).message);
    }
  };

  const regen = async (id: string) => {
    try { await imgFn({ data: { confession_id: id } }); toast.success("Image regenerated."); refresh(); }
    catch (e) { toast.error((e as Error).message); }
  };

  const signOut = async () => { await supabase.auth.signOut(); nav({ to: "/auth" }); };

  if (!ready) return <SiteLayout><div className="py-20 text-center"><Loader2 className="mx-auto animate-spin" /></div></SiteLayout>;

  return (
    <SiteLayout>
      <section className="mx-auto mt-10 max-w-5xl px-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <StickerLabel variant="pink" rotation={-3}>Moderation</StickerLabel>
            <h1 className="display-xl mt-2 text-[var(--charcoal)]">The queue.</h1>
          </div>
          <button onClick={signOut} className="btn-chunky cream text-sm">Sign out</button>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {(["pending_moderation","published","rejected","private"] as Status[]).map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`rounded-full border-[3px] border-[var(--charcoal)] px-4 py-2 text-sm font-[family-name:var(--font-chunky)] ${status === s ? "bg-[var(--hot-pink)] text-[var(--paper)]" : "bg-[var(--paper)]"}`}
            >{s.replace("_", " ")}</button>
          ))}
        </div>

        <div className="mt-6 space-y-5">
          {loading ? <p>Loading…</p> : rows.length === 0 ? (
            <TiltCard tilt={0} background="var(--cream)"><p>Nothing here.</p></TiltCard>
          ) : rows.map((r) => <ModerationRow key={r.id as string} row={r} onAct={act} onRegen={regen} />)}
        </div>

        <p className="mt-10 text-center text-xs text-[var(--charcoal)]/60">
          <Link to="/" className="underline">← Back to site</Link>
        </p>
      </section>
    </SiteLayout>
  );
}

function ModerationRow({
  row,
  onAct,
  onRegen,
}: {
  row: Record<string, unknown>;
  onAct: (id: string, action: "approve" | "reject" | "delete" | "restore", patch?: { public_quote?: string; title?: string }) => void;
  onRegen: (id: string) => void;
}) {
  const id = row.id as string;
  const [quote, setQuote] = useState((row.public_quote as string) ?? "");
  const [title, setTitle] = useState((row.title as string) ?? "");
  const flags = (row.clinical_flags as string[]) ?? [];
  const chars = (row.brain_characters as string[]) ?? [];
  const dominant = row.dominant_character as BrainCharacterId | null;
  const risk = row.risk_level as string;

  return (
    <TiltCard tilt={0} background="white">
      <div className="flex flex-wrap items-center gap-2">
        <span className={`rounded-full border-2 border-[var(--charcoal)] px-2 py-0.5 text-xs font-[family-name:var(--font-chunky)] ${risk === "urgent" || risk === "high" ? "bg-[var(--coral)] text-[var(--paper)]" : risk === "medium" ? "bg-[var(--peach)]" : "bg-[var(--mint)]"}`}>risk: {risk}</span>
        <span className="rounded-full border-2 border-[var(--charcoal)] bg-[var(--lavender-light)] px-2 py-0.5 text-xs">{row.status as string}</span>
        {dominant && <CharacterBadge id={dominant} size="sm" />}
        {chars.filter((c) => c !== dominant).map((c) => <CharacterBadge key={c} id={c as BrainCharacterId} size="sm" />)}
        {flags.map((f) => <span key={f} className="rounded-full border-2 border-[var(--coral)] bg-[var(--cream)] px-2 py-0.5 text-xs">⚠ {f}</span>)}
      </div>

      <div className="mt-3 grid gap-3 md:grid-cols-2">
        <div>
          <p className="font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Raw transcript</p>
          <p className="mt-1 text-sm whitespace-pre-wrap text-[var(--charcoal)]/80">{row.raw_transcript as string}</p>
        </div>
        <div>
          <label className="font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Public quote</label>
          <textarea value={quote} onChange={(e) => setQuote(e.target.value)} rows={3} className="mt-1 w-full rounded-xl border-2 border-[var(--charcoal)] bg-[var(--mint-light)] p-2 font-[family-name:var(--font-display)] italic" />
          <label className="mt-2 block font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[var(--charcoal)] bg-[var(--paper)] p-2" />
        </div>
      </div>

      {row.image_url ? (
        <img src={row.image_url as string} alt="quote card" className="mt-3 w-48 rounded-xl border-2 border-[var(--charcoal)]" loading="lazy" />
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2">
        <button onClick={() => onAct(id, "approve", { public_quote: quote, title })} className="btn-chunky text-sm" style={{ paddingBlock: "0.5rem" }}>Approve → publish</button>
        <button onClick={() => onAct(id, "reject")} className="btn-chunky cream text-sm" style={{ paddingBlock: "0.5rem" }}>Reject</button>
        <button onClick={() => onAct(id, "delete")} className="btn-chunky text-sm" style={{ paddingBlock: "0.5rem", background: "var(--coral)" }}>Delete</button>
        <button onClick={() => onRegen(id)} className="btn-chunky mint text-sm" style={{ paddingBlock: "0.5rem" }}>Regenerate image</button>
      </div>
    </TiltCard>
  );
}