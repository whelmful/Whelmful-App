import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { Sparkle } from "@/components/visual/Sparkle";
import { Squiggle } from "@/components/visual/Squiggle";
import { BlobShape } from "@/components/visual/BlobShape";
import { TiltCard } from "@/components/visual/TiltCard";
import { ConsentPanel } from "@/components/visual/ConsentPanel";
import { RecordButton } from "@/components/visual/RecordButton";
import { QuoteImagePreview } from "@/components/visual/QuoteImagePreview";
import { useVoiceRecorder } from "@/lib/sanctuary/useVoiceRecorder";
import { useAnonSession } from "@/lib/sanctuary/useAnonSession";
import { processConfession, submitConfession, generateConfessionImage } from "@/lib/sanctuary/confessions.functions";
import type { ProcessedConfession } from "@/lib/sanctuary/confessions.functions";
import { toast } from "sonner";
import { Loader2, RotateCcw } from "lucide-react";

export const Route = createFileRoute("/confessional")({
  head: () => ({
    meta: [
      { title: "The Confessional — one minute, anonymous, no judgment" },
      { name: "description", content: "Say the thing you are not supposed to say. One minute. Anonymous. We will turn the heavy bit into something softer." },
      { property: "og:title", content: "The Confessional" },
      { property: "og:description", content: "One minute. Anonymous. No judgment." },
    ],
  }),
  component: ConfessionalPage,
});

type Step = "consent" | "record" | "processing" | "preview" | "done" | "urgent";

function ConfessionalPage() {
  const [step, setStep] = useState<Step>("consent");
  const [processed, setProcessed] = useState<ProcessedConfession | null>(null);
  const [editedQuote, setEditedQuote] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [imgLoading, setImgLoading] = useState(false);
  const [deletionCode, setDeletionCode] = useState<string | null>(null);

  const recorder = useVoiceRecorder({ maxSeconds: 60 });
  const sessionId = useAnonSession();
  const processFn = useServerFn(processConfession);
  const submitFn = useServerFn(submitConfession);
  const generateImageFn = useServerFn(generateConfessionImage);

  const handleProcess = async () => {
    const text = recorder.transcript.trim();
    if (!text) {
      toast.error("Nothing to send yet. Hit record and speak for a moment.");
      return;
    }
    setStep("processing");
    try {
      const result = await processFn({ data: { transcript: text } });
      setProcessed(result);
      setEditedQuote(result.public_quote);
      if (result.risk_level === "urgent" || result.publish_recommendation === "block_publication") {
        setStep("urgent");
      } else {
        setStep("preview");
      }
    } catch (e) {
      console.error(e);
      toast.error("Couldn't process that. Try again in a moment.");
      setStep("record");
    }
  };

  const handleSubmit = async (makePublic: boolean) => {
    if (!processed) return;
    const payload: ProcessedConfession = { ...processed, public_quote: editedQuote };
    try {
      const res = await submitFn({
        data: {
          anonymous_session_id: sessionId,
          processed: payload,
          user_public_consent: makePublic,
        },
      });
      setDeletionCode(res.deletion_code);

      if (makePublic && res.status === "pending_moderation") {
        setImgLoading(true);
        try {
          const img = await generateImageFn({ data: { confession_id: res.id } });
          setImageUrl(img.image_url);
        } catch (e) {
          console.error(e);
        } finally {
          setImgLoading(false);
        }
      }
      setStep("done");
    } catch (e) {
      console.error(e);
      toast.error("Couldn't save that. Your words are still safe on this page.");
    }
  };

  return (
    <SiteLayout>
      <section className="relative mx-auto mt-10 max-w-3xl px-5">
        <BlobShape size={220} color="var(--soft-pink)" className="absolute -top-8 -left-16 -z-0 opacity-70" />
        <BlobShape size={200} color="var(--lavender)" className="absolute top-32 -right-16 -z-0 opacity-70" />

        <div className="text-center">
          <Sparkle size={32} color="var(--hot-pink)" className="mx-auto wiggle" />
          <StickerLabel variant="pink" rotation={-4} className="mt-2">The Confessional</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--charcoal)]">
            Say the thing you are not supposed to say.
          </h1>
          <Squiggle width={140} color="var(--teal-dark)" className="mx-auto mt-3" />
          <p className="mx-auto mt-4 max-w-xl text-[var(--charcoal)]/80">
            One minute. Anonymous. No judgment. We will turn the heavy bit into something softer, safer, and less lonely.
          </p>
        </div>

        <div className="mt-10">
          {step === "consent" && <ConsentPanel onAgree={() => setStep("record")} />}

          {step === "record" && (
            <TiltCard tilt={-0.5} background="var(--cream)">
              {!recorder.supported && (
                <p className="mb-4 rounded-xl border-2 border-[var(--coral)] bg-[var(--cream)] p-3 text-sm">
                  Your browser does not support live transcription. You can type your confession below instead.
                </p>
              )}

              <RecordButton
                isRecording={recorder.isRecording}
                seconds={recorder.seconds}
                onStart={recorder.start}
                onStop={recorder.stop}
              />

              <p className="mt-5 text-sm font-[family-name:var(--font-chunky)] uppercase tracking-wider text-[var(--charcoal)]/70">
                What we heard (you can tidy this up)
              </p>
              <textarea
                value={recorder.transcript}
                onChange={(e) => recorder.setTranscript(e.target.value)}
                rows={6}
                placeholder="Or type it here if you'd rather not speak…"
                className="mt-2 w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-4 text-[var(--charcoal)] placeholder:text-[var(--charcoal)]/40 focus:outline-none focus:ring-4 focus:ring-[var(--hot-pink)]/40"
              />

              <div className="mt-5 flex flex-wrap gap-3">
                <button onClick={recorder.reset} className="btn-chunky cream text-sm">
                  <RotateCcw size={16} /> Re-record
                </button>
                <button
                  onClick={handleProcess}
                  disabled={!recorder.transcript.trim() || recorder.isRecording}
                  className="btn-chunky disabled:opacity-50"
                >
                  Use this confession →
                </button>
              </div>
              <p className="mt-3 text-xs text-[var(--charcoal)]/60">
                Your voice never leaves your device. Only the typed transcript is sent for processing.
              </p>
            </TiltCard>
          )}

          {step === "processing" && (
            <TiltCard tilt={0} className="text-center" background="var(--mint-light)">
              <Loader2 className="mx-auto h-10 w-10 animate-spin text-[var(--hot-pink)]" />
              <p className="mt-3 font-[family-name:var(--font-chunky)] text-lg">
                Softening the edges…
              </p>
              <p className="mt-1 text-sm text-[var(--charcoal)]/70">
                Removing any names or identifying bits, finding the truth underneath.
              </p>
            </TiltCard>
          )}

          {step === "preview" && processed && (
            <TiltCard tilt={-0.5} background="white">
              <StickerLabel variant="mint" rotation={-3}>Your version, your call</StickerLabel>
              <p className="mt-3 text-[var(--charcoal)]/80">
                Here is the de-identified, quote-style version. Edit anything that does not feel right, then choose what happens next.
              </p>

              <label className="mt-5 block text-sm font-[family-name:var(--font-chunky)] uppercase tracking-wider text-[var(--charcoal)]/70">
                Public quote
              </label>
              <textarea
                value={editedQuote}
                onChange={(e) => setEditedQuote(e.target.value)}
                rows={3}
                className="mt-2 w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--mint-light)] p-4 font-[family-name:var(--font-display)] text-lg italic text-[var(--charcoal)] focus:outline-none focus:ring-4 focus:ring-[var(--hot-pink)]/40"
              />

              {processed.support_message && (
                <div className="mt-5 rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--lavender-light)] p-4">
                  <p className="font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/70">From The Sanctuary, to you</p>
                  <p className="mt-1 text-[var(--charcoal)]">{processed.support_message}</p>
                </div>
              )}

              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={() => handleSubmit(false)} className="btn-chunky cream">
                  Keep it just for me
                </button>
                <button onClick={() => handleSubmit(true)} className="btn-chunky">
                  Submit anonymously to help another parent feel less alone
                </button>
              </div>
              <p className="mt-3 text-xs text-[var(--charcoal)]/60">
                Public confessions go to a human moderator first. Nothing is published automatically.
              </p>
            </TiltCard>
          )}

          {step === "urgent" && processed && (
            <TiltCard tilt={0} background="var(--cream)" className="border-[var(--coral)]">
              <StickerLabel variant="pink" rotation={-3}>Please read this</StickerLabel>
              <h2 className="mt-3 font-[family-name:var(--font-display)] text-3xl text-[var(--charcoal)]">
                What you said matters more than this app can hold tonight.
              </h2>
              <p className="mt-3 text-[var(--charcoal)]/80">
                {processed.support_message ||
                  "If you are in immediate danger, or you might hurt yourself or someone else, please contact your local emergency services right now, or reach out to a trusted person nearby. You do not have to do this alone, and you do not have to do it through a screen."}
              </p>
              <p className="mt-3 text-sm text-[var(--charcoal)]/70">
                We have not published anything. Your words stayed private.
              </p>
              <div className="mt-5 flex gap-3">
                <button
                  onClick={() => { setStep("consent"); recorder.reset(); setProcessed(null); }}
                  className="btn-chunky cream"
                >
                  Start again
                </button>
              </div>
            </TiltCard>
          )}

          {step === "done" && processed && (
            <TiltCard tilt={-0.5} background="var(--mint)">
              <StickerLabel variant="pink" rotation={-4}>Safely tucked away</StickerLabel>
              <h2 className="mt-3 font-[family-name:var(--font-display)] text-3xl text-[var(--charcoal)]">
                Thank you for trusting us with that.
              </h2>
              <p className="mt-3 text-[var(--charcoal)]/80">
                Your confession is safely tucked away for review. If it becomes public, it will be anonymous and de-identified first.
              </p>

              {imgLoading && (
                <p className="mt-4 flex items-center gap-2 text-sm text-[var(--charcoal)]/70">
                  <Loader2 className="h-4 w-4 animate-spin" /> Painting your quote card…
                </p>
              )}
              {imageUrl && (
                <div className="mt-6">
                  <p className="mb-3 font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/70">
                    Preview of your quote card (still pending moderation)
                  </p>
                  <QuoteImagePreview quote={editedQuote} title={processed.title} imageUrl={imageUrl} />
                </div>
              )}
              {!imageUrl && !imgLoading && (
                <div className="mt-6">
                  <QuoteImagePreview quote={editedQuote} title={processed.title} />
                </div>
              )}

              {deletionCode && (
                <div className="mt-6 rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-4">
                  <p className="font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/70">
                    Your private deletion code
                  </p>
                  <p className="mt-1 font-mono text-lg tracking-widest text-[var(--charcoal)]">{deletionCode}</p>
                  <p className="mt-1 text-xs text-[var(--charcoal)]/60">
                    Keep this if you might want to ask us to delete this confession later.
                  </p>
                </div>
              )}

              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  onClick={() => { setStep("consent"); recorder.reset(); setProcessed(null); setImageUrl(null); setDeletionCode(null); }}
                  className="btn-chunky cream"
                >
                  Leave another
                </button>
              </div>
            </TiltCard>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}
