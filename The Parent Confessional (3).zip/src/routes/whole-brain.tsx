import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { TiltCard } from "@/components/visual/TiltCard";
import { Sparkle } from "@/components/visual/Sparkle";
import { Squiggle } from "@/components/visual/Squiggle";
import { BlobShape } from "@/components/visual/BlobShape";
import { BRAIN_CHARACTERS, DAILY_PRACTICES, WHOLE_BRAIN_PUBLIC_DISCLAIMER } from "@/config/wholeBrain";

export const Route = createFileRoute("/whole-brain")({
  head: () => ({
    meta: [
      { title: "Whole Brain Living for tired parents — The Sanctuary" },
      { name: "description", content: "Meet the four parts of your brain. A plain-language, parent-friendly guide inspired by Dr. Jill Bolte Taylor's Whole Brain Living — for the messy real world." },
      { property: "og:title", content: "Whole Brain Living for parents" },
      { property: "og:description", content: "Four parts of you. One messy parenting life. Plain-language tools to feel less hijacked." },
    ],
  }),
  component: WholeBrainPage,
});

function WholeBrainPage() {
  return (
    <SiteLayout>
      <section className="relative mx-auto mt-10 max-w-5xl px-5">
        <BlobShape size={260} color="var(--mint)" className="absolute -top-10 -left-16 -z-0 opacity-70" />
        <BlobShape size={220} color="var(--soft-pink)" className="absolute top-20 -right-10 -z-0 opacity-70" />
        <div className="text-center">
          <Sparkle size={32} color="var(--hot-pink)" className="mx-auto wiggle" />
          <StickerLabel variant="mint" rotation={-4} className="mt-2">Whole Brain Living, for the messy real world</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--charcoal)]">Meet the four parts of you that all want the wheel.</h1>
          <Squiggle width={140} color="var(--teal-dark)" className="mx-auto mt-3" />
          <p className="mx-auto mt-4 max-w-2xl text-[var(--charcoal)]/80">
            Inspired by Harvard-trained neuroanatomist Dr. Jill Bolte Taylor. Two hemispheres, four characters, one exhausted parent trying to get through bedtime. Knowing who is driving is the start of getting your whole brain back online.
          </p>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {BRAIN_CHARACTERS.map((c, i) => (
            <TiltCard key={c.id} tilt={i % 2 ? 1.2 : -1.2} background="white">
              <div className="flex items-center justify-between">
                <span
                  className="inline-flex items-center gap-2 rounded-full border-[3px] border-[var(--charcoal)] px-3 py-1 font-[family-name:var(--font-chunky)] text-sm shadow-[3px_3px_0_var(--charcoal)]"
                  style={{ background: c.color, color: c.hemisphere === "left" ? "white" : "var(--charcoal)" }}
                >
                  Character {c.number} · {c.short}
                </span>
                <span className="text-xs uppercase tracking-wider text-[var(--charcoal)]/60">{c.hemisphere}-brain · {c.mode}</span>
              </div>
              <p className="mt-3 font-[family-name:var(--font-display)] text-xl text-[var(--charcoal)]">{c.vibe}</p>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-xl border-2 border-[var(--charcoal)] bg-[var(--mint-light)] p-3">
                  <p className="font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Strengths</p>
                  <ul className="mt-1 list-disc pl-4 text-[var(--charcoal)]/80">
                    {c.strengths.map((s) => <li key={s}>{s}</li>)}
                  </ul>
                </div>
                <div className="rounded-xl border-2 border-[var(--charcoal)] bg-[var(--soft-pink)]/40 p-3">
                  <p className="font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Shadow</p>
                  <ul className="mt-1 list-disc pl-4 text-[var(--charcoal)]/80">
                    {c.shadow.map((s) => <li key={s}>{s}</li>)}
                  </ul>
                </div>
              </div>
              <p className="mt-3 text-sm italic text-[var(--charcoal)]/80">{c.parentExample}</p>
              <div className="mt-3 rounded-xl border-2 border-dashed border-[var(--charcoal)]/50 bg-[var(--cream)] p-3 text-sm">
                <span className="font-[family-name:var(--font-chunky)] text-[11px] uppercase tracking-wider text-[var(--charcoal)]/70">Invite this part forward</span>
                <p className="mt-1">{c.invitation}</p>
              </div>
            </TiltCard>
          ))}
        </div>

        <section className="mt-16">
          <div className="text-center">
            <StickerLabel variant="pink" rotation={3}>Daily whole-brain practices</StickerLabel>
            <h2 className="display-xl mt-3 text-[var(--charcoal)]">Tiny moves. Big neuroplasticity.</h2>
            <p className="mx-auto mt-3 max-w-xl text-[var(--charcoal)]/80">
              You build a whole brain the same way you build a kid: small, repeated, imperfect moments. Pick one. Try it twice today.
            </p>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {DAILY_PRACTICES.map((p, i) => (
              <TiltCard key={p.id} tilt={i % 2 ? -1 : 1} background={i % 3 === 0 ? "var(--lavender-light)" : i % 3 === 1 ? "var(--mint-light)" : "var(--peach)"}>
                <h3 className="font-[family-name:var(--font-chunky)] text-xl text-[var(--charcoal)]">{p.title}</h3>
                <p className="mt-2 text-[var(--charcoal)]/80">{p.body}</p>
              </TiltCard>
            ))}
          </div>
        </section>

        <section className="mt-16 text-center">
          <div className="rounded-3xl border-[3px] border-[var(--charcoal)] bg-[var(--cream)] p-8 shadow-[6px_6px_0_var(--charcoal)]">
            <h2 className="display-xl text-[var(--charcoal)]">Try it live.</h2>
            <p className="mx-auto mt-3 max-w-xl text-[var(--charcoal)]/80">
              Two short tools to practise whole-brain living when the wheels fall off.
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <Link to="/huddle" className="btn-chunky">Run a BRAIN Huddle →</Link>
              <Link to="/translator" className="btn-chunky mint">Try the Translator →</Link>
            </div>
          </div>
          <p className="mt-4 text-xs text-[var(--charcoal)]/60">{WHOLE_BRAIN_PUBLIC_DISCLAIMER}</p>
        </section>
      </section>
    </SiteLayout>
  );
}