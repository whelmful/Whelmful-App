import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Suspense, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { ConfessionCard } from "@/components/visual/ConfessionCard";
import { getPublishedConfessions, reportConfession } from "@/lib/sanctuary/confessions.functions";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";

const wallQuery = queryOptions({
  queryKey: ["confessions", "wall"],
  queryFn: () => getPublishedConfessions(),
});

export const Route = createFileRoute("/confessions")({
  head: () => ({
    meta: [
      { title: "The Wall — Whelmful" },
      { name: "description", content: "Anonymous, de-identified truths from parents who are also barely holding it together." },
      { property: "og:title", content: "The Wall — Whelmful" },
      { property: "og:description", content: "Anonymous, human-reviewed truths from overwhelmed parents." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(wallQuery),
  component: WallPage,
  errorComponent: ({ error }) => (
    <SiteLayout>
      <div className="mx-auto max-w-2xl px-5 py-20 text-center">
        <p className="wm-display text-2xl">Couldn't load the wall right now.</p>
        <p className="mt-2 text-[color:var(--wm-espresso)]/70">{error.message}</p>
      </div>
    </SiteLayout>
  ),
});

function WallPage() {
  return (
    <SiteLayout>
      <section className="wm-bg relative mx-auto mt-10 max-w-6xl px-5 pb-20">
        <div className="text-center">
          <div className="wm-sticker wm-sticker-pink inline-block">The Wall</div>
          <h1 className="wm-display mt-4 text-4xl sm:text-5xl">
            Tiny anonymous truths from parents barely holding it together.
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-[color:var(--wm-espresso)]/80">
            No names. No faces. No audio. Every quote is de-identified and human-reviewed before it lands here.
          </p>
          <div className="mt-5 flex justify-center gap-3">
            <Link to="/app" className="wm-btn wm-btn-primary">Add yours →</Link>
            <Link to="/resources" className="wm-btn wm-btn-cream">Need support now</Link>
          </div>
        </div>

        <div className="mt-12">
          <Suspense fallback={<p className="text-center text-[color:var(--wm-espresso)]/60">Loading…</p>}>
            <WallGrid />
          </Suspense>
        </div>
      </section>
    </SiteLayout>
  );
}

function WallGrid() {
  const { data } = useSuspenseQuery(wallQuery);
  const reportFn = useServerFn(reportConfession);
  const [reportingId, setReportingId] = useState<string | null>(null);

  if (data.length === 0) {
    return (
      <div className="wm-card mx-auto max-w-xl p-8 text-center">
        <p className="wm-display text-2xl">
          The wall is quiet right now.
        </p>
        <p className="mt-2 text-[color:var(--wm-espresso)]/70">
          Be the first to say the messy thing out loud.
        </p>
        <Link to="/app" className="wm-btn wm-btn-primary mt-5 inline-flex">Leave one →</Link>
      </div>
    );
  }

  return (
    <>
      <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5 [&>*]:break-inside-avoid">
        {data.map((c) => (
          <ConfessionCard
            key={c.id}
            confession={{
              id: c.id,
              title: c.title,
              public_quote: c.public_quote,
              tags: c.tags,
              image_url: c.image_url,
              support_count: c.support_count,
              dominant_character: c.dominant_character,
            }}
            onReport={(id) => setReportingId(id)}
          />
        ))}
      </div>

      {reportingId && (
        <ReportDialog
          id={reportingId}
          onClose={() => setReportingId(null)}
          onSubmit={async (reason, notes) => {
            try {
              await reportFn({ data: { confession_id: reportingId, reason, notes } });
              toast.success("Thanks for flagging this. It's gone back to moderation.");
            } catch (e) {
              console.error(e);
              toast.error("Couldn't send that report. Try again.");
            }
            setReportingId(null);
          }}
        />
      )}
    </>
  );
}

type ReportReason = "identifying_information" | "unsafe_content" | "harmful_advice" | "child_safety" | "other";

function ReportDialog({
  id,
  onClose,
  onSubmit,
}: {
  id: string;
  onClose: () => void;
  onSubmit: (reason: ReportReason, notes: string) => void;
}) {
  const [reason, setReason] = useState<ReportReason>("identifying_information");
  const [notes, setNotes] = useState("");
  void id;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--charcoal)]/40 p-4">
      <div className="paper-card max-w-md w-full p-6">
        <h3 className="font-[family-name:var(--font-display)] text-2xl">Report this confession</h3>
        <p className="mt-1 text-sm text-[var(--charcoal)]/70">
          Thanks for looking out. Tell us what is wrong and we will pull it back into review.
        </p>
        <div className="mt-4 space-y-2">
          {([
            ["identifying_information", "Contains identifying details"],
            ["unsafe_content", "Unsafe content"],
            ["harmful_advice", "Harmful advice"],
            ["child_safety", "Child safety concern"],
            ["other", "Something else"],
          ] as const).map(([val, label]) => (
            <label key={val} className="flex cursor-pointer items-center gap-2">
              <input
                type="radio"
                name="reason"
                checked={reason === val}
                onChange={() => setReason(val)}
                className="h-4 w-4 accent-[var(--hot-pink)]"
              />
              <span>{label}</span>
            </label>
          ))}
        </div>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          maxLength={1000}
          placeholder="Anything else we should know (optional)"
          className="mt-3 w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3 text-sm"
        />
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="btn-chunky cream text-sm" style={{ paddingBlock: "0.5rem" }}>
            Cancel
          </button>
          <button onClick={() => onSubmit(reason, notes)} className="btn-chunky text-sm" style={{ paddingBlock: "0.5rem" }}>
            Send report
          </button>
        </div>
      </div>
    </div>
  );
}
