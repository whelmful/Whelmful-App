import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Whelmful — say the thing you're not supposed to say" },
      { name: "description", content: "An anonymous place for the 3am thoughts, the 5pm witching-hour spirals, and the messy mum moments motherhood doesn't leave room for." },
      { property: "og:title", content: "Whelmful — say the thing you're not supposed to say" },
      { property: "og:description", content: "An anonymous place for the 3am thoughts, the 5pm witching-hour spirals, and the messy mum moments." },
    ],
  }),
  component: Home,
});

const STICKERS = [
  { label: "3:07am", tone: "wm-sticker-pink", tilt: -6 },
  { label: "touched out", tone: "wm-sticker-lime", tilt: 3 },
  { label: "not a bad mum", tone: "wm-sticker-lavender", tilt: -3 },
  { label: "someone else felt this too", tone: "wm-sticker-apricot", tilt: 5 },
];

const STEPS = [
  { n: 1, t: "Dump it", b: "Say the thing you're not supposed to say.", bg: "var(--wm-blush)" },
  { n: 2, t: "Name it", b: "Pick what's actually in the room.", bg: "var(--wm-butter)" },
  { n: 3, t: "See another angle", b: "Plain-language, not clinical.", bg: "var(--wm-lime)" },
  { n: 4, t: "Share or save", b: "Private by default. You choose.", bg: "var(--wm-lavender)" },
  { n: 5, t: "Leave lighter", b: "One tiny good thing before you go.", bg: "var(--wm-apricot)" },
];

function Home() {
  return (
    <SiteLayout>
      <section className="wm-bg">
      <div className="mx-auto max-w-6xl px-5 py-12 md:py-16">
        <div className="grid items-center gap-10 md:grid-cols-[1.15fr_1fr]">
          <div>
            <span className="wm-sticker wm-sticker-pink" style={{ transform: "rotate(-3deg)", display: "inline-block" }}>
              Mums mode · 3am safe
            </span>
            <h1 className="wm-display mt-5 text-5xl sm:text-6xl md:text-7xl">
              Say the thing<br />you&rsquo;re{" "}
              <span className="wm-underline">not supposed</span>
              {" "}to say.
            </h1>
            <p className="mt-6 max-w-xl text-lg md:text-xl wm-ui" style={{ color: "var(--wm-espresso)" }}>
              An anonymous place for the 3am thoughts, the 5pm witching-hour spirals,
              and the messy human moments motherhood doesn&rsquo;t leave room for.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link to="/app" className="wm-btn wm-btn-primary">
                Start a dump →
              </Link>
              <Link to="/confessions" className="wm-btn wm-btn-butter">
                Read the wall
              </Link>
            </div>
            <p className="mt-4 wm-marker text-lg" style={{ color: "var(--wm-olive)" }}>
              anonymous · no sign-up · nothing posts unless you choose it.
            </p>
          </div>

          <div className="relative">
            <div className="wm-card wm-card-lg relative" style={{ background: "var(--wm-warm-white)", transform: "rotate(-1.5deg)" }}>
              <div className="wm-tape" style={{ top: -12, left: "50%", marginLeft: -46 }} />
              <p className="text-xs uppercase tracking-[0.18em]" style={{ color: "var(--wm-olive)" }}>
                Anonymous · the wall
              </p>
              <p className="mt-3 wm-display text-2xl sm:text-3xl" style={{ lineHeight: 1.15 }}>
                &ldquo;I love them more than anything, but tonight I wanted no one to touch me, need me, or say my name.&rdquo;
              </p>
              <p className="mt-4 wm-marker text-lg" style={{ color: "var(--wm-olive)" }}>
                — a mum, somewhere at 3:07am
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                {STICKERS.map((s) => (
                  <span
                    key={s.label}
                    className={`wm-sticker ${s.tone}`}
                    style={{ transform: `rotate(${s.tilt}deg)` }}
                  >
                    {s.label}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      </section>

      {/* Process strip */}
      <section className="mx-auto mt-10 max-w-6xl px-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {STEPS.map((s, i) => (
            <div
              key={s.n}
              className="wm-card relative"
              style={{
                background: s.bg,
                padding: "1.1rem 1.1rem",
                transform: `rotate(${(i % 2 === 0 ? -1 : 1) * 1.2}deg)`,
              }}
            >
              <span className="wm-sticker" style={{ background: "var(--wm-warm-white)", transform: "rotate(-4deg)" }}>
                {s.n}
              </span>
              <h3 className="mt-3 wm-display text-xl">{s.t}</h3>
              <p className="mt-1 text-[14px] wm-ui" style={{ color: "var(--wm-espresso)" }}>
                {s.b}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Wall preview tease */}
      <section className="mx-auto mt-20 max-w-6xl px-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <span className="wm-sticker wm-sticker-lime" style={{ transform: "rotate(-2deg)" }}>The wall</span>
            <h2 className="wm-display mt-3 text-4xl md:text-5xl">
              You are <span className="wm-underline">not</span> the only one.
            </h2>
            <p className="mt-3 max-w-xl wm-ui" style={{ color: "var(--wm-espresso)" }}>
              Tiny anonymous truths from mums also barely holding it together. No likes. No followers. Just &ldquo;same&rdquo; and &ldquo;me too.&rdquo;
            </p>
          </div>
          <Link to="/confessions" className="wm-btn wm-btn-cream">Read the wall →</Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { q: "I cried in the pantry so no one would ask me for anything.", bg: "var(--wm-blush)", tilt: -1.5 },
            { q: "I miss who I was before I became needed all the time.", bg: "var(--wm-butter)", tilt: 1.2 },
            { q: "I don't want to disappear. I just want ten minutes where no one needs my body.", bg: "var(--wm-lavender)", tilt: -0.8 },
            { q: "I love my baby and I miss my old life. Both are true.", bg: "var(--wm-lime)", tilt: 1.8 },
            { q: "Today I was jealous of my partner leaving for work.", bg: "var(--wm-warm-white)", tilt: -1.2 },
            { q: "I don't want advice. I want one person to say this is hard.", bg: "var(--wm-apricot)", tilt: 1 },
          ].map((c, i) => (
            <div
              key={i}
              className="wm-card"
              style={{ background: c.bg, transform: `rotate(${c.tilt}deg)` }}
            >
              <p className="wm-display text-xl" style={{ lineHeight: 1.25 }}>&ldquo;{c.q}&rdquo;</p>
              <div className="mt-4 flex flex-wrap gap-2 text-[12px]" style={{ color: "var(--wm-olive)" }}>
                <span className="wm-chip" style={{ background: "var(--wm-warm-white)" }}>same</span>
                <span className="wm-chip" style={{ background: "var(--wm-warm-white)" }}>me too</span>
                <span className="wm-chip" style={{ background: "var(--wm-warm-white)" }}>sending softness</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Closing CTA */}
      <section className="mx-auto mt-20 max-w-3xl px-5 text-center">
        <h2 className="wm-display text-4xl md:text-5xl">
          You are doing more than anyone can see.
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-lg wm-ui">
          Whelmful isn&rsquo;t a fix. It&rsquo;s a place to put the heavy thing down for a minute so you can carry it tomorrow.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/app" className="wm-btn wm-btn-primary">Start a dump</Link>
          <Link to="/about" className="wm-btn wm-btn-cream">What is Whelmful?</Link>
        </div>
        <p className="mt-6 text-xs" style={{ color: "var(--wm-olive)" }}>
          For reflection and support — not emergency care. <Link to="/resources" className="underline">Need urgent help?</Link>
        </p>
      </section>
    </SiteLayout>
  );
}
