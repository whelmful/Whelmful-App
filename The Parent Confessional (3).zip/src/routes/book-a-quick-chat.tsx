import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { TiltCard } from "@/components/visual/TiltCard";
import { StickerLabel } from "@/components/visual/StickerLabel";

export const Route = createFileRoute("/book-a-quick-chat")({
  head: () => ({
    meta: [
      { title: "Book a quick chat — The Sanctuary" },
      { name: "description", content: "Booking with a real human is coming soon. Until then, The Sanctuary will sit with you." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="mx-auto mt-16 max-w-2xl px-5">
        <TiltCard tilt={1} background="var(--hot-pink)" className="text-[var(--paper)]">
          <StickerLabel variant="cream" rotation={-4}>Coming soon</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--paper)]">Book a quick chat.</h1>
          <p className="mt-4 text-[var(--paper)]/90">
            Real-person 1:1 sessions are on the way. While we set them up, The Sanctuary is here 24/7 — no appointment, no waiting room.
          </p>
          <div className="mt-6">
            <Link to="/sanctuary" className="btn-chunky cream">Talk now</Link>
          </div>
        </TiltCard>
      </section>
    </SiteLayout>
  ),
});
