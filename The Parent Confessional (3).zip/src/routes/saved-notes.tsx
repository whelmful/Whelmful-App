import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PaperCard } from "@/components/ui/PaperCard";

export const Route = createFileRoute("/saved-notes")({
  head: () => ({
    meta: [
      { title: "Saved Notes — Whelmful" },
      { name: "description", content: "Your private dumps, reflections, light moments and one tiny good things — kept on this device." },
      { property: "og:title", content: "Saved Notes — Whelmful" },
      { property: "og:description", content: "Private notes from your Whelmful flow, kept on this device." },
    ],
  }),
  component: SavedNotesPage,
});

type Entry = { text?: string; dumpText?: string; chips?: string[]; at: string };

function readList(key: string): Entry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function Group({ title, tone, entries, getText }: { title: string; tone: "blush" | "lilac" | "butter" | "cream"; entries: Entry[]; getText: (e: Entry) => string }) {
  return (
    <section className="mt-8">
      <h2 className="text-2xl" style={{ fontFamily: "var(--font-display)", color: "var(--charcoal)" }}>{title}</h2>
      {entries.length === 0 ? (
        <p className="mt-2 text-sm" style={{ color: "var(--charcoal)", opacity: 0.7 }}>Nothing here yet.</p>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {entries.map((e, i) => (
            <PaperCard key={i} tone={tone} rotate={i % 2 === 0 ? -0.4 : 0.5}>
              <p className="whitespace-pre-wrap" style={{ color: "var(--charcoal)" }}>{getText(e)}</p>
              <p className="mt-3 text-xs" style={{ color: "var(--charcoal)", opacity: 0.6 }}>
                {new Date(e.at).toLocaleString()}
              </p>
            </PaperCard>
          ))}
        </div>
      )}
    </section>
  );
}

function SavedNotesPage() {
  const [dumps, setDumps] = useState<Entry[]>([]);
  const [reflections, setReflections] = useState<Entry[]>([]);
  const [tinies, setTinies] = useState<Entry[]>([]);
  const [light, setLight] = useState<Entry[]>([]);

  useEffect(() => {
    setDumps(readList("whelmful.private.dumps"));
    setReflections(readList("whelmful.saved.reflections"));
    setTinies(readList("whelmful.tiny.good.things"));
    setLight(readList("whelmful.light"));
  }, []);

  return (
    <SiteLayout>
      <section className="w-container w-section">
        <p className="text-sm font-semibold uppercase tracking-[0.18em]" style={{ color: "var(--olive)" }}>
          Just for you
        </p>
        <h1 className="mt-2 text-4xl md:text-5xl" style={{ fontFamily: "var(--font-display)", color: "var(--charcoal)", lineHeight: 1.1 }}>
          Saved Notes
        </h1>
        <p className="mt-3 max-w-2xl" style={{ color: "var(--charcoal)" }}>
          Private to this device. Nothing here is shared anywhere.
        </p>

        <Group title="Dumps" tone="cream" entries={dumps} getText={(e) => e.dumpText || e.text || ""} />
        <Group title="Reflections" tone="lilac" entries={reflections} getText={(e) => e.dumpText || e.text || ""} />
        <Group title="One Tiny Good Things" tone="butter" entries={tinies} getText={(e) => e.text || ""} />
        <Group title="Light moments" tone="blush" entries={light} getText={(e) => e.text || ""} />

        <p className="mt-10 text-sm" style={{ color: "var(--charcoal)", opacity: 0.7 }}>
          Want to add another? <Link to="/app" className="underline">Start a dump</Link>.
        </p>
      </section>
    </SiteLayout>
  );
}