import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PaperCard } from "@/components/ui/PaperCard";
import { toast } from "sonner";

export const Route = createFileRoute("/one-tiny-good-thing")({
  head: () => ({
    meta: [
      { title: "One Tiny Good Thing — Whelmful" },
      { name: "description", content: "Not toxic positivity. Just one small steady thing your brain can notice today." },
      { property: "og:title", content: "One Tiny Good Thing — Whelmful" },
      { property: "og:description", content: "Small, real, not forced — one tiny good thing to notice today." },
    ],
  }),
  component: TinyGoodPage,
});

const CHIPS = [
  "The room is quiet for one minute.",
  "I asked for help instead of swallowing it.",
  "The sky looked nice for half a second.",
  "I got through today.",
  "My coffee was warm.",
  "I did one small thing.",
];

type Entry = { text: string; at: string };

function TinyGoodPage() {
  const [text, setText] = useState("");
  const [list, setList] = useState<Entry[]>([]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem("whelmful.tiny.good.things");
      if (raw) setList(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);

  const save = () => {
    const v = text.trim();
    if (!v) return;
    const next: Entry[] = [{ text: v, at: new Date().toISOString() }, ...list].slice(0, 200);
    setList(next);
    setText("");
    try { window.localStorage.setItem("whelmful.tiny.good.things", JSON.stringify(next)); } catch { /* ignore */ }
    toast("Saved.");
  };

  return (
    <SiteLayout>
      <section className="w-container w-section">
        <p className="text-sm font-semibold uppercase tracking-[0.18em]" style={{ color: "var(--olive)" }}>
          Before you go
        </p>
        <h1 className="mt-2 text-4xl md:text-5xl" style={{ fontFamily: "var(--font-display)", color: "var(--charcoal)", lineHeight: 1.1 }}>
          One Tiny Good Thing
        </h1>
        <p className="mt-3 max-w-2xl" style={{ color: "var(--charcoal)" }}>
          Small, real, not forced. Just helping your brain notice one steady thing.
        </p>

        <div className="mt-6 max-w-2xl">
          <label htmlFor="tgt" className="sr-only">One tiny good thing</label>
          <textarea
            id="tgt"
            rows={3}
            maxLength={280}
            className="w-textarea"
            placeholder="One tiny thing I can notice is…"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {CHIPS.map((c) => (
              <button key={c} type="button" className="wm-chip" onClick={() => setText(c)}>
                {c}
              </button>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" onClick={save} disabled={!text.trim()} className="wm-btn wm-btn-primary">
              Save this
            </button>
            <Link to="/app" className="wm-btn wm-btn-cream">Start a dump</Link>
            <Link to="/saved-notes" className="wm-btn wm-btn-cream">Read my saved notes</Link>
          </div>
        </div>

        {list.length > 0 && (
          <section className="mt-10">
            <h2 className="text-2xl" style={{ fontFamily: "var(--font-display)", color: "var(--charcoal)" }}>What you’ve noticed</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {list.slice(0, 12).map((e, i) => (
                <PaperCard key={i} tone="butter" rotate={i % 2 === 0 ? -0.4 : 0.5}>
                  <p style={{ color: "var(--charcoal)" }}>{e.text}</p>
                  <p className="mt-3 text-xs" style={{ color: "var(--charcoal)", opacity: 0.6 }}>
                    {new Date(e.at).toLocaleString()}
                  </p>
                </PaperCard>
              ))}
            </div>
          </section>
        )}
      </section>
    </SiteLayout>
  );
}