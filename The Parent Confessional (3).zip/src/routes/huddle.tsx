import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { TiltCard } from "@/components/visual/TiltCard";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { Sparkle } from "@/components/visual/Sparkle";
import { Squiggle } from "@/components/visual/Squiggle";
import { BRAIN_HUDDLE_STEPS, BRAIN_CHARACTERS } from "@/config/wholeBrain";

export const Route = createFileRoute("/huddle")({
  head: () => ({
    meta: [
      { title: "The BRAIN Huddle — a 90-second whole-brain check-in" },
      { name: "description", content: "B.R.A.I.N. — a five-step pause inspired by Dr. Jill Bolte Taylor. Breathe, recognise the part at the wheel, appreciate it, ask the others in, then navigate one tiny next move." },
    ],
  }),
  component: HuddlePage,
});

function HuddlePage() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>(BRAIN_HUDDLE_STEPS.map(() => ""));
  const [character, setCharacter] = useState<string>("");
  const done = step >= BRAIN_HUDDLE_STEPS.length;
  const current = BRAIN_HUDDLE_STEPS[step];

  const summary = useMemo(() => {
    return BRAIN_HUDDLE_STEPS.map((s, i) => ({ ...s, answer: answers[i] })).filter((s) => s.answer.trim());
  }, [answers]);

  const reset = () => { setStep(0); setAnswers(BRAIN_HUDDLE_STEPS.map(() => "")); setCharacter(""); };

  return (
    <SiteLayout>
      <section className="relative mx-auto mt-10 max-w-2xl px-5">
        <div className="text-center">
          <Sparkle size={32} color="var(--hot-pink)" className="mx-auto wiggle" />
          <StickerLabel variant="mint" rotation={-4} className="mt-2">90 seconds. Whole brain.</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--charcoal)]">The BRAIN Huddle.</h1>
          <Squiggle width={140} color="var(--teal-dark)" className="mx-auto mt-3" />
          <p className="mt-4 text-[var(--charcoal)]/80">
            Five tiny steps to get all four parts of you in the room before you act. Inspired by Dr. Jill Bolte Taylor's BRAIN protocol.
          </p>
        </div>

        {!done ? (
          <TiltCard tilt={-0.5} background="var(--cream)" className="mt-8">
            <div className="flex items-center justify-between">
              <span className="font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/60">
                Step {step + 1} / {BRAIN_HUDDLE_STEPS.length}
              </span>
              <div className="flex gap-1">
                {BRAIN_HUDDLE_STEPS.map((_, i) => (
                  <span key={i} className={`h-2 w-6 rounded-full border border-[var(--charcoal)] ${i <= step ? "bg-[var(--hot-pink)]" : "bg-[var(--paper)]"}`} />
                ))}
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-4">
              <span className="font-[family-name:var(--font-display)] text-7xl text-[var(--hot-pink)]">{current.letter}</span>
              <div>
                <h2 className="font-[family-name:var(--font-chunky)] text-3xl text-[var(--charcoal)]">{current.word}</h2>
                <p className="text-[var(--charcoal)]/80">{current.prompt}</p>
              </div>
            </div>

            {step === 1 ? (
              <div className="mt-5 grid grid-cols-2 gap-2">
                {BRAIN_CHARACTERS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setCharacter(c.id)}
                    className={`rounded-2xl border-[3px] border-[var(--charcoal)] p-3 text-left font-[family-name:var(--font-chunky)] text-sm shadow-[3px_3px_0_var(--charcoal)] transition ${character === c.id ? "ring-4 ring-[var(--hot-pink)]/60" : ""}`}
                    style={{ background: c.color, color: c.hemisphere === "left" ? "white" : "var(--charcoal)" }}
                  >
                    C{c.number} — {c.short}
                    <span className="block opacity-80 text-[11px] mt-1 normal-case font-[family-name:var(--font-body)]">{c.vibe}</span>
                  </button>
                ))}
              </div>
            ) : null}

            <textarea
              value={answers[step]}
              onChange={(e) => setAnswers((a) => a.map((x, i) => (i === step ? e.target.value : x)))}
              rows={3}
              placeholder={current.placeholder}
              className="mt-4 w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3 text-[var(--charcoal)] placeholder:text-[var(--charcoal)]/40 focus:outline-none focus:ring-4 focus:ring-[var(--hot-pink)]/40"
            />

            <div className="mt-4 flex justify-between">
              <button
                disabled={step === 0}
                onClick={() => setStep((s) => Math.max(0, s - 1))}
                className="btn-chunky cream text-sm disabled:opacity-50"
              >
                ← Back
              </button>
              <button
                onClick={() => setStep((s) => s + 1)}
                className="btn-chunky text-sm"
              >
                {step === BRAIN_HUDDLE_STEPS.length - 1 ? "Finish huddle →" : "Next →"}
              </button>
            </div>
          </TiltCard>
        ) : (
          <TiltCard tilt={-0.5} background="var(--mint)" className="mt-8">
            <StickerLabel variant="pink" rotation={-4}>Whole-brain check-in complete</StickerLabel>
            <h2 className="mt-3 font-[family-name:var(--font-display)] text-3xl text-[var(--charcoal)]">Nice. All four parts heard.</h2>
            <ul className="mt-5 space-y-3">
              {summary.map((s) => (
                <li key={s.letter} className="rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3">
                  <p className="font-[family-name:var(--font-chunky)] text-sm uppercase tracking-wider text-[var(--charcoal)]/70">{s.letter} — {s.word}</p>
                  <p className="mt-1 text-[var(--charcoal)]">{s.answer}</p>
                </li>
              ))}
            </ul>
            <div className="mt-6 flex flex-wrap gap-3">
              <button onClick={reset} className="btn-chunky cream text-sm">Do another</button>
              <Link to="/sanctuary" className="btn-chunky text-sm">Talk it through →</Link>
            </div>
            <p className="mt-3 text-xs text-[var(--charcoal)]/60">
              Inspired by Dr. Jill Bolte Taylor's Whole Brain Living. Not therapy or treatment.
            </p>
          </TiltCard>
        )}
      </section>
    </SiteLayout>
  );
}