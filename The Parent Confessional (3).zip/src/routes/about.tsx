import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Whelmful" },
      { name: "description", content: "Whelmful is a soft, anonymous place for overwhelmed parents. What it is, and what it isn't." },
      { property: "og:title", content: "About — Whelmful" },
      { property: "og:description", content: "A soft, anonymous place for overwhelmed parents. Reflective support, never therapy." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="wm-bg mx-auto mt-12 max-w-2xl px-5 pb-20">
        <div className="wm-sticker wm-sticker-pink inline-block">About</div>
        <h1 className="wm-display mt-4 text-4xl sm:text-5xl">A soft place for overwhelmed parents.</h1>
        <div className="wm-card mt-6 p-6 space-y-4 text-[color:var(--wm-espresso)]/85">
          <p>Whelmful is an anonymous space for the parents who are quietly losing it at 11:47pm — and don't want to be fixed, just heard.</p>
          <p>The Translator is an AI reflection tool. It is not a therapist, doctor, or friend with lived experience. It listens without flinching, reframes the messy thought through whole-brain and parts-informed lenses, and helps you find a tiny next step that fits your values.</p>
          <p>The Wall is where parents leave anonymous, de-identified truths. Posts are reviewed by a human moderator before they appear. Your private dumps stay on your device unless you choose to share.</p>
          <p className="text-sm opacity-70">This is reflective support — not therapy, diagnosis, or crisis care. If you are in danger, please use the resources page.</p>
        </div>
        <div className="mt-6 flex gap-3">
          <Link to="/app" className="wm-btn wm-btn-primary">Try it →</Link>
          <Link to="/resources" className="wm-btn wm-btn-cream">Resources</Link>
        </div>
      </section>
    </SiteLayout>
  ),
});
