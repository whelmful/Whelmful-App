import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { TiltCard } from "@/components/visual/TiltCard";
import { StickerLabel } from "@/components/visual/StickerLabel";

export const Route = createFileRoute("/free-guide")({
  head: () => ({
    meta: [
      { title: "Free guide — The Sanctuary" },
      { name: "description", content: "A short, soft guide for the nights you are running on fumes." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="mx-auto mt-16 max-w-2xl px-5">
        <TiltCard tilt={-1} background="var(--peach)">
          <StickerLabel variant="pink" rotation={-4}>Coming soon</StickerLabel>
          <h1 className="display-xl mt-3">A free guide for the nights you are running on fumes.</h1>
          <p className="mt-4 text-[var(--charcoal)]/80">
            We are putting together a tiny, no-bullshit guide for the worst parenting nights. While we finish writing it, the best thing we can offer you is somewhere to put down the heavy thing.
          </p>
          <div className="mt-6 flex gap-3">
            <Link to="/sanctuary" className="btn-chunky">Talk to The Sanctuary</Link>
            <Link to="/confessional" className="btn-chunky mint">Leave a confession</Link>
          </div>
        </TiltCard>
      </section>
    </SiteLayout>
  ),
});
