import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { Sparkle } from "@/components/visual/Sparkle";
import { Squiggle } from "@/components/visual/Squiggle";
import { BlobShape } from "@/components/visual/BlobShape";
import { SANCTUARY_OPENING_MESSAGE } from "@/config/sanctuaryPrompt";
import { toast } from "sonner";
import { Send } from "lucide-react";

export const Route = createFileRoute("/sanctuary")({
  head: () => ({
    meta: [
      { title: "The Sanctuary — anonymous AI companion for tired parents" },
      { name: "description", content: "A calm, anonymous space to vent the heavy thing. No advice, no judgment. The Sanctuary is an AI support companion, not a crisis service." },
      { property: "og:title", content: "Talk to The Sanctuary" },
      { property: "og:description", content: "A soft AI companion for parents who are running on empty." },
    ],
  }),
  component: SanctuaryPage,
});

type Msg = { role: "user" | "assistant"; content: string };

function SanctuaryPage() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: SANCTUARY_OPENING_MESSAGE },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setBusy(true);

    try {
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      if (!resp.ok || !resp.body) {
        let msg = "Something went wrong reaching the companion.";
        try {
          const j = await resp.json();
          if (j?.error) msg = j.error;
        } catch {}
        toast.error(msg);
        setBusy(false);
        return;
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let acc = "";
      setMessages((m) => [...m, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buf.indexOf("\n")) !== -1) {
          let line = buf.slice(0, idx);
          buf = buf.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line || line.startsWith(":") || !line.startsWith("data: ")) continue;
          const json = line.slice(6).trim();
          if (json === "[DONE]") { buf = ""; break; }
          try {
            const parsed = JSON.parse(json);
            const delta: string | undefined = parsed?.choices?.[0]?.delta?.content;
            if (delta) {
              acc += delta;
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: acc };
                return copy;
              });
            }
          } catch {
            buf = line + "\n" + buf;
            break;
          }
        }
      }
    } catch (e) {
      console.error(e);
      toast.error("Lost the connection. Try again in a sec.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <SiteLayout>
      <section className="relative mx-auto mt-10 max-w-3xl px-5">
        <BlobShape size={220} color="var(--mint)" className="absolute -top-6 -left-16 -z-0 opacity-70" />
        <BlobShape size={200} color="var(--soft-pink)" className="absolute top-32 -right-16 -z-0 opacity-70" />

        <div className="text-center">
          <Sparkle size={32} color="var(--hot-pink)" className="mx-auto wiggle" />
          <StickerLabel variant="mint" rotation={-4} className="mt-2">No judgment. No advice.</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--charcoal)]">The Sanctuary</h1>
          <Squiggle width={140} color="var(--teal-dark)" className="mx-auto mt-3" />
        </div>

        <div className="paper-card mt-8 flex h-[60vh] flex-col">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-5">
            <ul className="flex flex-col gap-4">
              {messages.map((m, i) => (
                <li
                  key={i}
                  className={
                    m.role === "user"
                      ? "self-end max-w-[80%] rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--lavender)] px-4 py-3 shadow-[3px_3px_0_var(--charcoal)]"
                      : "self-start max-w-[85%] rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--mint-light)] px-4 py-3 shadow-[3px_3px_0_var(--charcoal)]"
                  }
                >
                  <p className="whitespace-pre-wrap text-[var(--charcoal)] leading-relaxed">
                    {m.content || (busy && i === messages.length - 1 ? "…" : "")}
                  </p>
                </li>
              ))}
            </ul>
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); send(); }}
            className="flex items-end gap-2 border-t-[3px] border-[var(--charcoal)] bg-[var(--cream)] p-3"
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
              }}
              rows={2}
              placeholder="Tell me what's heavy tonight…"
              className="flex-1 resize-none rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3 text-[var(--charcoal)] placeholder:text-[var(--charcoal)]/40 focus:outline-none focus:ring-4 focus:ring-[var(--hot-pink)]/40"
              disabled={busy}
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              className="btn-chunky disabled:opacity-50"
              style={{ padding: "0.9rem 1.1rem" }}
            >
              <Send size={18} />
            </button>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-[var(--charcoal)]/60">
          The Sanctuary is an AI support companion, not a crisis service, therapist, or emergency contact.
        </p>
      </section>
    </SiteLayout>
  );
}
