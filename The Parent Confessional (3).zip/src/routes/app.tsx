import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { useAnonSession } from "@/lib/sanctuary/useAnonSession";
import {
  prepareWallSubmissionText,
  processConfession,
  submitConfession,
} from "@/lib/sanctuary/confessions.functions";
import {
  whelmfulTranslate,
  getVisibleTranslatorCards,
  type WhelmfulTranslation,
  type SelectedCard,
} from "@/lib/sanctuary/whelmfulTranslate.functions";
import { toast } from "sonner";
import { Loader2, ChevronDown, ChevronUp } from "lucide-react";
import {
  TinyHeart,
  DoodleUnderline,
  NextArrow,
} from "@/components/visual/SoftDoodle";
import { BodyBrainCards } from "@/components/translator/BodyBrainCards";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { title: "Whelmful — Dump · Sort · Translate · Choose · Light" },
      {
        name: "description",
        content:
          "Dump what's heavy, name what's there, see it through softer perspectives, choose what happens next, and land somewhere lighter. Five soft steps. No pressure.",
      },
      { property: "og:title", content: "Whelmful — Dump · Sort · Translate · Choose · Light" },
      {
        property: "og:description",
        content:
          "A calm, guided flow that moves overwhelmed parents from emotional overload to one small steady moment.",
      },
    ],
  }),
  component: AppPage,
});

const DUMP_FLOW_STEPS = [
  "dump",
  "sort",
  "translate",
  "choice",
  "tinyMove",
  "choose",
  "light",
  "checkIn",
] as const;
type FlowStep = (typeof DUMP_FLOW_STEPS)[number];
type Step = FlowStep | "crisis";

const OLD_MOVE_COSTS = [
  "my energy", "my self-trust", "my connection", "my calm",
  "my dignity", "my time", "my body", "my relationship", "my confidence",
];

const TINY_MOVE_WHEN = [
  "now",
  "in the next ten minutes",
  "before bed",
  "tomorrow morning",
  "when this feeling shows up again",
];

const TINY_MOVE_WHERE = [
  "kitchen", "bedroom", "bathroom", "car", "outside", "couch", "wherever I am",
];

const CHECKIN_OPTIONS = [
  { id: "lighter", label: "A tiny bit lighter" },
  { id: "chose", label: "Still heavy, but I chose differently" },
  { id: "noshift", label: "No shift yet" },
  { id: "couldnt", label: "I could not do the move" },
  { id: "smaller", label: "I need to make it smaller" },
] as const;
type CheckInId = typeof CHECKIN_OPTIONS[number]["id"];

const EMOTION_CHIPS = [
  "touched out", "rage", "guilt", "resentment", "fear", "shame",
  "overstimulated", "lonely", "invisible", "not good enough",
  "pressure", "grief", "identity loss", "exhaustion",
  "perfectionism", "panic spiral", "sensory overload",
  "needing space", "missing myself",
];

const TIMES = [
  "3am", "5pm witching hour", "after bedtime", "before school/daycare",
  "during a feed", "after an argument", "after a long day",
];

const ROLES = [
  "mother", "partner", "worker", "daughter", "friend",
  "household manager", "the one who holds everything",
];

const VALUES = [
  "calm", "connection", "honesty", "freedom", "rest", "play",
  "presence", "repair", "self-respect", "kindness", "courage", "boundaries",
];

const SOFT_PROMPTS = [
  "What feels too loud today?",
  "What are you pretending is fine?",
  "What do you wish someone understood without you explaining it?",
  "What are you carrying that is not actually yours?",
];

const LOADING_LINES = [
  "Listening for the part underneath…",
  "Finding the softer truth…",
  "Choosing the most useful perspectives…",
];

const CRISIS_PATTERNS = [
  /\bkill (myself|him|her|them|the kids?|the baby)\b/i,
  /\bend (it|my life|everything)\b/i,
  /\bsuicid/i,
  /\bhurt (the )?(baby|kid|child|kids|children|partner|him|her)\b/i,
  /\bshake (the )?(baby|him|her)\b/i,
  /\bwant to die\b/i,
  /\bcan'?t go on\b/i,
];
function looksLikeCrisis(text: string) {
  return CRISIS_PATTERNS.some((re) => re.test(text));
}

function getTinyStepText(t: WhelmfulTranslation | null, fallbackValue?: string): string {
  if (!t) return "Take one slow breath and ask: what do I need less of right now?";
  const tns: unknown = t.tiny_next_step;
  if (typeof tns === "string" && tns.trim()) return tns.trim();
  if (tns && typeof tns === "object") {
    const obj = tns as { body?: unknown; title?: unknown };
    if (typeof obj.body === "string" && obj.body.trim()) return obj.body.trim();
    if (typeof obj.title === "string" && obj.title.trim()) return obj.title.trim();
  }
  if (fallbackValue) {
    return `Take one slow breath and ask: what would ${fallbackValue} look like in the next minute?`;
  }
  return "Take one slow breath and ask: what do I need less of right now?";
}

function StepIndicator({ step }: { step: Step }) {
  const order = DUMP_FLOW_STEPS;
  const idx = order.indexOf(step as FlowStep);
  const labels: Record<Step, string> = {
    dump: "Dump",
    sort: "Name it",
    translate: "Translate",
    choice: "Choose",
    tinyMove: "Move",
    choose: "Wall",
    light: "Tiny Good Thing",
    checkIn: "Check-in",
    crisis: "Pause",
  };
  return (
    <ol className="flex flex-wrap items-center gap-x-4 gap-y-2">
      {order.map((s, i) => (
        <li
          key={s}
          className="w-step-dot"
          data-active={s === step}
          data-done={i < idx}
        >
          <span className="dot" />
          <span>{labels[s]}</span>
        </li>
      ))}
    </ol>
  );
}

function FlowPanel({ children, panelRef }: { children: React.ReactNode; panelRef?: React.RefObject<HTMLDivElement | null> }) {
  return <div ref={panelRef} className="w-flow-panel">{children}</div>;
}

function CrisisCard({ onBack }: { onBack: () => void }) {
  return (
    <FlowPanel>
      <p className="text-sm font-semibold uppercase tracking-wider" style={{ color: "var(--w-deep-olive)" }}>
        Pause for a second
      </p>
      <h2
        className="mt-2 text-3xl"
        style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)" }}
      >
        What you said matters more than this app can hold tonight.
      </h2>
      <p className="mt-4 text-base" style={{ color: "var(--w-charcoal)" }}>
        If you or someone else is in immediate danger, please call your local emergency
        services. You do not have to do this through a screen.
      </p>
      <div
        className="mt-5 rounded-2xl p-4"
        style={{ background: "var(--w-soft-pink)", border: "1px solid rgba(47,47,47,0.12)" }}
      >
        <p className="font-semibold" style={{ color: "var(--w-deep-charcoal)" }}>
          Right now
        </p>
        <ul className="mt-1 list-disc pl-5 text-[15px]" style={{ color: "var(--w-charcoal)" }}>
          <li>Immediate danger — your local emergency number (000 AU · 911 US · 999 UK)</li>
          <li>Australia — Lifeline 13 11 14 · PANDA 1300 726 306</li>
          <li>US — 988 Suicide &amp; Crisis Lifeline</li>
          <li>UK — Samaritans 116 123</li>
        </ul>
      </div>
      <p className="mt-4 text-sm" style={{ color: "var(--w-charcoal)", opacity: 0.75 }}>
        Nothing you wrote here has been shared or published.
      </p>
      <div className="mt-5 flex flex-wrap gap-3">
        <button type="button" onClick={onBack} className="w-btn w-btn-secondary">
          Start again
        </button>
      </div>
    </FlowPanel>
  );
}

function AppPage() {
  // --- Single source of truth for navigation -----------------------------
  const [step, setStepInternal] = useState<Step>("dump");
  const panelRef = useRef<HTMLDivElement | null>(null);

  const setCurrentStep = (s: Step) => {
    setStepInternal(s);
    // Best-effort: scroll the flow card into view at the top
    if (typeof window !== "undefined") {
      requestAnimationFrame(() => {
        panelRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }
  };

  const goToNextStep = () => {
    const idx = DUMP_FLOW_STEPS.indexOf(step as FlowStep);
    if (idx >= 0 && idx < DUMP_FLOW_STEPS.length - 1) {
      setCurrentStep(DUMP_FLOW_STEPS[idx + 1]);
    }
  };
  const goToPreviousStep = () => {
    const idx = DUMP_FLOW_STEPS.indexOf(step as FlowStep);
    if (idx > 0) setCurrentStep(DUMP_FLOW_STEPS[idx - 1]);
  };

  // --- Flow state (preserved across steps) -------------------------------
  const [dumpText, setDumpText] = useState("");
  const [dumpError, setDumpError] = useState<string | null>(null);
  const [promptIdx, setPromptIdx] = useState(0);

  const [chips, setChips] = useState<string[]>([]);
  const [customChip, setCustomChip] = useState("");
  const [timeOfDay, setTimeOfDay] = useState<string>("");
  const [roles, setRoles] = useState<string[]>([]);
  const [values, setValues] = useState<string[]>([]);

  const [translating, setTranslating] = useState(false);
  const [loadingIdx, setLoadingIdx] = useState(0);
  const [translation, setTranslation] = useState<WhelmfulTranslation | null>(null);
  const [translateError, setTranslateError] = useState<string | null>(null);
  const [digDeeper, setDigDeeper] = useState(false);

  const [wallText, setWallText] = useState("");
  const [confirmPost, setConfirmPost] = useState(false);
  const [posting, setPosting] = useState(false);
  const [withheldNotice, setWithheldNotice] = useState<string | null>(null);
  const [chosenAction, setChosenAction] = useState<null | "private" | "wall" | "saved" | "another" | "light">(null);
  const [tinyAccepted, setTinyAccepted] = useState(false);
  const [tinyGoodThing, setTinyGoodThing] = useState("");
  const [tinyGoodThingSaved, setTinyGoodThingSaved] = useState(false);

  // Choice Point state
  const [oldMoveCost, setOldMoveCost] = useState<string[]>([]);
  const [chosenInstead, setChosenInstead] = useState("");

  // Tiny Move Commitment state
  const [tinyMoveText, setTinyMoveText] = useState("");
  const [tinyMoveWhen, setTinyMoveWhen] = useState("");
  const [tinyMoveWhere, setTinyMoveWhere] = useState("");
  const [tinyMoveCustomWhere, setTinyMoveCustomWhere] = useState("");
  const [tinyMoveConfidence, setTinyMoveConfidence] = useState<number>(3);

  // Check-in state
  const [checkInChoice, setCheckInChoice] = useState<CheckInId | "">("");

  const saveTinyGoodThing = () => {
    const v = tinyGoodThing.trim();
    if (!v) return;
    try {
      if (typeof window !== "undefined") {
        const key = "whelmful.tiny.good.things";
        const raw = window.localStorage.getItem(key);
        const list = raw ? (JSON.parse(raw) as Array<{ text: string; at: string }>) : [];
        list.unshift({ text: v, at: new Date().toISOString() });
        window.localStorage.setItem(key, JSON.stringify(list.slice(0, 200)));
      }
      setTinyGoodThingSaved(true);
      toast("Saved.");
    } catch { /* ignore */ }
  };

  // --- Helpers ----------------------------------------------------------
  const sessionId = useAnonSession();
  const translateFn = useServerFn(whelmfulTranslate);
  const processFn = useServerFn(processConfession);
  const submitFn = useServerFn(submitConfession);

  const softPrompt = useMemo(() => SOFT_PROMPTS[promptIdx % SOFT_PROMPTS.length], [promptIdx]);

  useEffect(() => {
    if (!translating) return;
    const t = setInterval(() => setLoadingIdx((i) => (i + 1) % LOADING_LINES.length), 1800);
    return () => clearInterval(t);
  }, [translating]);

  const toggleIn = (setter: React.Dispatch<React.SetStateAction<string[]>>) => (v: string) => {
    setter((cur) => (cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v]));
  };

  const toggleChip = (c: string) => toggleIn(setChips)(c);
  const addCustomChip = () => {
    const v = customChip.trim();
    if (!v) return;
    setChips((cur) => (cur.includes(v) ? cur : [...cur, v]));
    setCustomChip("");
  };

  const saveFlowDraft = () => {
    try {
      if (typeof window === "undefined") return;
      window.localStorage.setItem(
        "whelmful.flow.draft",
        JSON.stringify({ dumpText, chips, timeOfDay, roles, values, at: new Date().toISOString() }),
      );
    } catch {
      /* best effort */
    }
  };
  useEffect(() => { saveFlowDraft(); }, [dumpText, chips, timeOfDay, roles, values]);

  const resetDumpFlow = () => {
    setCurrentStep("dump");
    setDumpText("");
    setDumpError(null);
    setChips([]);
    setCustomChip("");
    setTimeOfDay("");
    setRoles([]);
    setValues([]);
    setTranslation(null);
    setTranslateError(null);
    setDigDeeper(false);
    setWallText("");
    setConfirmPost(false);
    setWithheldNotice(null);
    setChosenAction(null);
    setTinyAccepted(false);
    setOldMoveCost([]);
    setChosenInstead("");
    setTinyMoveText("");
    setTinyMoveWhen("");
    setTinyMoveWhere("");
    setTinyMoveCustomWhere("");
    setTinyMoveConfidence(3);
    setCheckInChoice("");
    setTinyGoodThing("");
    setTinyGoodThingSaved(false);
  };

  // --- Step handlers ----------------------------------------------------
  const handleDumpNext = () => {
    const t = dumpText.trim();
    if (!t) {
      setDumpError("You do not have to make it pretty. Start with the messy version.");
      return;
    }
    setDumpError(null);
    if (looksLikeCrisis(t)) {
      setCurrentStep("crisis");
      return;
    }
    setCurrentStep("sort");
  };

  const handleSortTranslate = async () => {
    if (!dumpText.trim()) {
      setCurrentStep("dump");
      setDumpError("You do not have to make it pretty. Start with the messy version.");
      return;
    }
    setTranslating(true);
    setTranslateError(null);
    try {
      const r = await translateFn({
        data: {
          thought: dumpText,
          emotion_tags: chips,
          time_of_day: timeOfDay,
          role_pressures: roles,
          values,
        },
      });
      setTranslation(r);
      setWallText(prepareWallSubmissionText(dumpText));
      setCurrentStep("translate");
    } catch (e) {
      console.error("whelmfulTranslate failed", e);
      setTranslateError("Something glitched. Your thought is still valid. Try again.");
      toast.error("Something glitched. Your thought is still valid.");
    } finally {
      setTranslating(false);
    }
  };

  const handleTranslateNext = () => setCurrentStep("choice");

  // Derive a suggested "old move" + "next move" from the translation.
  const suggestedOldMove = useMemo(() => {
    const t = translation;
    if (!t) return "shut down, snap, or over-explain";
    const parts = getVisibleTranslatorCards(t);
    const protector = parts.find((p) => /protect|alarm|critic|fixer/i.test(p.name));
    if (protector?.what_it_might_be_saying) return protector.what_it_might_be_saying;
    return "shut down, snap, or over-explain";
  }, [translation]);

  const suggestedNextMove = useMemo(() => {
    return getTinyStepText(translation, translation?.values_bridge.selected_value);
  }, [translation]);

  // Pre-fill tiny move text when entering the commitment step.
  useEffect(() => {
    if (step === "tinyMove" && !tinyMoveText && suggestedNextMove) {
      setTinyMoveText(suggestedNextMove);
    }
  }, [step, suggestedNextMove, tinyMoveText]);

  const shrinkTinyMove = () => {
    const cur = tinyMoveText.trim();
    if (!cur) return;
    // Heuristic shrink: keep the first 6 words and add a concrete frame.
    const words = cur.replace(/[.!?]+$/, "").split(/\s+/);
    const head = words.slice(0, 6).join(" ");
    setTinyMoveText(`Just this: ${head}. Six words, ten seconds.`);
    setTinyMoveConfidence((c) => Math.max(c, 4));
  };

  const saveLearning = () => {
    try {
      if (typeof window === "undefined") return;
      const key = "whelmful.flow.learnings";
      const raw = window.localStorage.getItem(key);
      const list = raw ? (JSON.parse(raw) as unknown[]) : [];
      list.unshift({
        at: new Date().toISOString(),
        dump: dumpText,
        chips,
        translation,
        old_move: suggestedOldMove,
        old_move_cost: oldMoveCost,
        chosen_instead: chosenInstead,
        tiny_move: {
          move: tinyMoveText,
          when: tinyMoveWhen,
          where: tinyMoveWhere || tinyMoveCustomWhere,
          confidence: tinyMoveConfidence,
        },
        tiny_good_thing: tinyGoodThing,
        check_in: checkInChoice,
      });
      window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
      toast("Saved the learning.");
    } catch {
      /* ignore */
    }
  };

  const handleChooseAction = async (action: "private" | "wall" | "saved" | "another" | "light") => {
    if (action === "another") {
      setChosenAction("another");
      // re-run translate with same inputs
      await handleSortTranslate();
      setCurrentStep("translate");
      return;
    }
    if (action === "private") {
      setChosenAction("private");
      try {
        if (typeof window !== "undefined") {
          const key = "whelmful.private.dumps";
          const raw = window.localStorage.getItem(key);
          const list = raw ? (JSON.parse(raw) as unknown[]) : [];
          list.unshift({ dumpText, chips, at: new Date().toISOString() });
          window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
        }
        toast("Kept private on this device.");
      } catch {
        /* ignore */
      }
      setCurrentStep("light");
      return;
    }
    if (action === "saved") {
      setChosenAction("saved");
      try {
        if (typeof window !== "undefined") {
          const key = "whelmful.saved.reflections";
          const raw = window.localStorage.getItem(key);
          const list = raw ? (JSON.parse(raw) as unknown[]) : [];
          list.unshift({ dumpText, chips, translation, at: new Date().toISOString() });
          window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
        }
        toast("Saved for later.");
      } catch {
        /* ignore */
      }
      setCurrentStep("light");
      return;
    }
    if (action === "light") {
      setChosenAction("light");
      try {
        if (typeof window !== "undefined") {
          const key = "whelmful.light";
          const raw = window.localStorage.getItem(key);
          const list = raw ? (JSON.parse(raw) as Array<{ text: string; at: string }>) : [];
          const text =
            translation?.reframe.new_thought ||
            translation?.self_compassion_phrase ||
            "A softer truth.";
          list.unshift({ text, at: new Date().toISOString() });
          window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
        }
        toast("Added to your Light list.");
      } catch {
        /* ignore */
      }
      setCurrentStep("light");
      return;
    }
    if (action === "wall") {
      setChosenAction("wall");
      setWallText(prepareWallSubmissionText(dumpText));
      setConfirmPost(true);
    }
  };

  const submitToWall = async () => {
    const text = wallText.trim();
    if (!text) {
      toast("Write a short version first.");
      return;
    }
    setPosting(true);
    setWithheldNotice(null);
    try {
      // Risk-check the original text — but POST exactly what the user (or the
      // redactor) approved. Never publish the AI's reframe.
      const processed = await processFn({ data: { transcript: text } });
      const submitted = await submitFn({
        data: {
          anonymous_session_id: sessionId,
          processed: {
            ...processed,
            public_quote: text,
            deidentified_confession: text,
          },
          user_public_consent: true,
        },
      });
      if (submitted.withheld) {
        setWithheldNotice(
          "This one needs support, not the wall. Please reach out for immediate help now.",
        );
        toast("We held this one back — please reach a real person who can support you.");
      } else {
        toast("Submitted for review. If approved, it will appear anonymously on the wall.");
        setConfirmPost(false);
        setCurrentStep("light");
      }
    } catch (e) {
      console.error("submitToWall failed", e);
      toast.error("Couldn't send that. You can still keep it private.");
    } finally {
      setPosting(false);
    }
  };

  const acceptTinyStep = () => {
    setTinyAccepted(true);
    try {
      if (typeof window !== "undefined") {
        const key = "whelmful.tiny.steps";
        const raw = window.localStorage.getItem(key);
        const list = raw ? (JSON.parse(raw) as Array<{ text: string; at: string }>) : [];
        list.unshift({
          text: getTinyStepText(translation, translation?.values_bridge.selected_value),
          at: new Date().toISOString(),
        });
        window.localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
      }
    } catch {
      /* ignore */
    }
    if (step !== "tinyMove") setCurrentStep("tinyMove");
  };

  // -------------------- Render ----------------------------------------
  return (
    <SiteLayout>
      <section className="w-container w-section">
        <div className="mb-6 flex items-center justify-between gap-4">
          <p
            className="text-sm font-semibold uppercase tracking-[0.18em]"
            style={{ color: "var(--wm-olive)" }}
          >
            Whelmful
          </p>
          {step !== "crisis" && <StepIndicator step={step} />}
        </div>

        {step === "crisis" && <CrisisCard onBack={resetDumpFlow} />}

        {/* STEP 1 — DUMP */}
        {step === "dump" && (
          <FlowPanel panelRef={panelRef}>
            <h1
              className="text-4xl md:text-5xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.1 }}
            >
              What do you want to{" "}
              <span className="relative inline-block">
                <span>dump</span>
                <DoodleUnderline className="absolute left-0 right-0 -bottom-2" />
              </span>{" "}
              today?
            </h1>
            <p className="mt-4 text-base md:text-lg" style={{ color: "var(--w-charcoal)" }}>
              No perfect words. No fixing. Just get the heavy bit out of your head.
            </p>

            <label htmlFor="dump" className="sr-only">Your dump</label>
            <textarea
              id="dump"
              className="w-textarea mt-5"
              rows={7}
              maxLength={6000}
              placeholder="Today I need to dump…"
              value={dumpText}
              onChange={(e) => { setDumpText(e.target.value); if (dumpError) setDumpError(null); }}
            />
            {dumpError && (
              <p className="mt-2 text-sm" style={{ color: "var(--wm-wine, #E6844A)" }}>{dumpError}</p>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button type="button" onClick={handleDumpNext} className="w-btn w-btn-primary">
                Next: name what&rsquo;s here
                <NextArrow size={20} color="#fff" />
              </button>
              <button
                type="button"
                onClick={() => setPromptIdx((i) => i + 1)}
                className="w-btn w-btn-secondary"
              >
                I need a softer prompt
              </button>
            </div>
            <p
              className="mt-3 text-sm"
              style={{ color: "var(--w-charcoal)", opacity: 0.75, fontFamily: "var(--font-accent)", fontSize: "1.05rem" }}
            >
              try: &ldquo;{softPrompt}&rdquo;
            </p>
          </FlowPanel>
        )}

        {/* STEP 2 — SORT */}
        {step === "sort" && (
          <FlowPanel panelRef={panelRef}>
            <h2
              className="text-3xl md:text-4xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
            >
              Name what&rsquo;s in the room.
            </h2>
            <p className="mt-3 text-base" style={{ color: "var(--w-charcoal)" }}>
              Not to judge it. Just to see it. Tap whatever fits — or add your own.
            </p>

            <div className="mt-5 flex flex-wrap gap-2">
              {EMOTION_CHIPS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className="wm-chip"
                  data-on={chips.includes(c)}
                  onClick={() => toggleChip(c)}
                >
                  {c}
                </button>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <input
                value={customChip}
                onChange={(e) => setCustomChip(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addCustomChip(); } }}
                placeholder="add my own words…"
                className="wm-input"
                style={{ maxWidth: 320, padding: "0.6rem 0.9rem", fontSize: "0.95rem" }}
              />
              <button type="button" onClick={addCustomChip} className="wm-btn wm-btn-cream" style={{ minHeight: 42, padding: "0.55rem 1rem", fontSize: "0.9rem" }}>
                Add
              </button>
            </div>

            <div className="mt-6 space-y-4">
              <ChipGroup label="Time of day / moment (optional)" options={TIMES} value={timeOfDay ? [timeOfDay] : []} onToggle={(v) => setTimeOfDay(timeOfDay === v ? "" : v)} />
              <ChipGroup label="Role pressure right now (optional)" options={ROLES} value={roles} onToggle={toggleIn(setRoles)} />
              <ChipGroup label="Values you want to live by (optional)" options={VALUES} value={values} onToggle={toggleIn(setValues)} />
            </div>

            {chips.length > 0 && (
              <p className="mt-4 wm-marker text-lg" style={{ color: "var(--w-olive)" }}>
                in the room right now: {chips.join(" · ")}
              </p>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleSortTranslate}
                disabled={translating}
                className="w-btn w-btn-primary"
              >
                {translating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> {LOADING_LINES[loadingIdx]}
                  </>
                ) : (
                  <>
                    Translate this
                    <NextArrow size={20} color="#fff" />
                  </>
                )}
              </button>
              <button type="button" onClick={goToPreviousStep} className="w-btn w-btn-link">
                Back
              </button>
            </div>
            {translateError && (
              <p className="mt-3 text-sm" style={{ color: "var(--wm-wine, #E6844A)" }}>{translateError}</p>
            )}
          </FlowPanel>
        )}

        {/* STEP 3 — TRANSLATE */}
        {step === "translate" && translation && (
          <FlowPanel panelRef={panelRef}>
            <span className="wm-sticker wm-sticker-pink">{translation.validation.title || "First, this makes sense"}</span>
            <h2
              className="mt-3 text-3xl md:text-4xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
            >
              {translation.validation.body || "What you’re carrying is real."}
            </h2>

            {/* Body-Brain Translator — primary surface */}
            {translation.risk_level !== "urgent" && (
              <div className="mt-6">
                <BodyBrainCards translation={translation} />
              </div>
            )}

            {translation.risk_level === "urgent" && translation.safety_message && (
              <div className="mt-6 rounded-2xl p-5" style={{ background: "var(--wm-blush)", border: "2px solid var(--wm-espresso)" }}>
                <p className="wm-display text-xl" style={{ color: "var(--wm-espresso)" }}>
                  Pause for a second.
                </p>
                <p className="mt-2" style={{ color: "var(--wm-espresso)" }}>
                  {translation.safety_message}
                </p>
              </div>
            )}

            <div className="mt-5 wm-card" style={{ background: "var(--wm-lavender)" }}>
              <span className="wm-sticker wm-sticker-lavender">{translation.nervous_system.title}</span>
              <p className="mt-3" style={{ color: "var(--wm-espresso)", lineHeight: 1.55 }}>
                {translation.nervous_system.body}
              </p>
            </div>

            {getVisibleTranslatorCards(translation).length > 0 && (
              <div className="mt-6">
                <span className="wm-sticker wm-sticker-apricot">The parts that showed up</span>
                <div className="mt-3 grid gap-4 md:grid-cols-2">
                  {getVisibleTranslatorCards(translation).map((c, i) => (
                    <PartCardTile key={(c.id || c.name) + i} card={c} index={i} />
                  ))}
                </div>
              </div>
            )}

            {/* Reframe */}
            <div className="mt-6 wm-card" style={{ background: "var(--wm-warm-white)", borderColor: "var(--wm-bubblegum)", borderWidth: 3 }}>
              <span className="wm-sticker wm-sticker-pink">The reframe</span>
              <p
                className="mt-3 text-2xl md:text-3xl"
                style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.2 }}
              >
                &ldquo;{translation.reframe.new_thought}&rdquo;
              </p>
              {translation.reframe.why_it_feels_lighter && (
                <p className="mt-2 text-sm" style={{ color: "var(--wm-espresso)", opacity: 0.8 }}>
                  {translation.reframe.why_it_feels_lighter}
                </p>
              )}
            </div>

            {/* Values bridge */}
            {(translation.values_bridge.alignment_statement || translation.values_bridge.selected_value) && (
              <div className="mt-6 wm-card" style={{ background: "var(--wm-lime)" }}>
                <span className="wm-sticker wm-sticker-lime">
                  Your values bridge{translation.values_bridge.selected_value ? ` · ${translation.values_bridge.selected_value}` : ""}
                </span>
                <p className="mt-3" style={{ color: "var(--wm-espresso)" }}>
                  {translation.values_bridge.alignment_statement}
                </p>
              </div>
            )}

            {/* Tiny next step — bulletproof rendering */}
            <div className="mt-6 wm-card" style={{ background: "var(--wm-apricot)" }}>
              <span className="wm-sticker wm-sticker-apricot">One tiny thing for right now</span>
              <p className="mt-2 text-xs uppercase tracking-[0.16em]" style={{ color: "#FFFDF8", opacity: 0.9 }}>
                Tiny next move
              </p>
              <p
                className="mt-2 text-2xl md:text-3xl"
                style={{ fontFamily: "var(--font-display)", color: "#FFFDF8", lineHeight: 1.25 }}
              >
                {getTinyStepText(translation, translation.values_bridge.selected_value)}
              </p>
              <button type="button" onClick={acceptTinyStep} className="wm-btn wm-btn-cream mt-4">
                I&rsquo;ll try this
              </button>
            </div>

            {/* Dig deeper */}
            <div className="mt-6">
              <button
                type="button"
                className="wm-btn wm-btn-cream"
                onClick={() => setDigDeeper((s) => !s)}
              >
                {digDeeper ? (<><ChevronUp size={14}/> Hide deeper view</>) : (<><ChevronDown size={14}/> Dig deeper</>)}
              </button>
              {digDeeper && (
                <div className="mt-4 space-y-4">
                  {translation.dig_deeper.additional_cards.length > 0 && (
                    <div className="grid gap-4 md:grid-cols-2">
                      {translation.dig_deeper.additional_cards.map((c, i) => (
                        <PartCardTile key={(c.id || c.name) + "x" + i} card={c} index={i + 10} />
                      ))}
                    </div>
                  )}
                  {translation.dig_deeper.reflection_questions.filter(Boolean).length > 0 && (
                    <div className="wm-card" style={{ background: "var(--wm-warm-white)" }}>
                      <span className="wm-sticker wm-sticker-pink">Sit with these</span>
                      <ul className="mt-3 list-disc pl-5 space-y-2" style={{ color: "var(--wm-espresso)" }}>
                        {translation.dig_deeper.reflection_questions.filter(Boolean).map((q, i) => (<li key={i}>{q}</li>))}
                      </ul>
                    </div>
                  )}
                  {translation.dig_deeper.why_this_helps && (
                    <div className="wm-card" style={{ background: "var(--wm-cream)" }}>
                      <span className="wm-sticker">Why this helps</span>
                      <p className="mt-3" style={{ color: "var(--wm-espresso)" }}>{translation.dig_deeper.why_this_helps}</p>
                    </div>
                  )}
                  {translation.self_compassion_phrase && (
                    <p className="wm-marker text-lg" style={{ color: "var(--wm-wine, #E6844A)" }}>
                      say to yourself: &ldquo;{translation.self_compassion_phrase}&rdquo;
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" onClick={handleTranslateNext} className="w-btn w-btn-primary">
                Find the choice point
                <NextArrow size={20} color="#fff" />
              </button>
              <button type="button" onClick={goToPreviousStep} className="w-btn w-btn-link">
                Back
              </button>
            </div>
          </FlowPanel>
        )}

        {/* STEP 3b — CHOICE POINT */}
        {step === "choice" && (
          <FlowPanel panelRef={panelRef}>
            <span className="wm-sticker wm-sticker-lavender">Choice point</span>
            <h2
              className="mt-3 text-3xl md:text-4xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
            >
              Here&rsquo;s the choice point.
            </h2>
            <p className="mt-3 text-base" style={{ color: "var(--w-charcoal)" }}>
              This is the tiny gap where the old pattern doesn&rsquo;t have to run the whole show.
            </p>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <div className="wm-card" style={{ background: "var(--wm-blush)" }}>
                <span className="wm-sticker wm-sticker-pink">The old move</span>
                <p className="mt-3 text-sm uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
                  what your body/brain usually tries
                </p>
                <p className="mt-2" style={{ color: "var(--wm-espresso)", lineHeight: 1.5 }}>
                  {suggestedOldMove}
                </p>
              </div>
              <div className="wm-card" style={{ background: "var(--wm-lime)" }}>
                <span className="wm-sticker wm-sticker-lime">The next move</span>
                <p className="mt-3 text-sm uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>
                  the smallest move toward who you&rsquo;re becoming
                </p>
                <p className="mt-2" style={{ color: "var(--wm-espresso)", lineHeight: 1.5 }}>
                  {suggestedNextMove}
                </p>
              </div>
            </div>

            <div className="mt-6">
              <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                What does the old move usually cost you?
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {OLD_MOVE_COSTS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    className="wm-chip"
                    data-on={oldMoveCost.includes(c)}
                    onClick={() => toggleIn(setOldMoveCost)(c)}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <label
                htmlFor="chosen-instead"
                className="text-xs font-semibold uppercase tracking-[0.16em]"
                style={{ color: "var(--wm-olive)" }}
              >
                What do you want to choose instead, just this once?
              </label>
              <textarea
                id="chosen-instead"
                className="w-textarea mt-2"
                rows={2}
                maxLength={300}
                placeholder="Just this once, I want to choose…"
                value={chosenInstead}
                onChange={(e) => setChosenInstead(e.target.value)}
              />
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" onClick={() => setCurrentStep("tinyMove")} className="w-btn w-btn-primary">
                Choose the next move
                <NextArrow size={20} color="#fff" />
              </button>
              <button type="button" onClick={goToPreviousStep} className="w-btn w-btn-link">
                Back
              </button>
            </div>
          </FlowPanel>
        )}

        {/* STEP 3c — TINY MOVE COMMITMENT */}
        {step === "tinyMove" && (
          <FlowPanel panelRef={panelRef}>
            <span className="wm-sticker wm-sticker-apricot">Make it real</span>
            <h2
              className="mt-3 text-3xl md:text-4xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
            >
              Make the tiny move real.
            </h2>
            <p className="mt-3 text-base" style={{ color: "var(--w-charcoal)" }}>
              Not impressive. Doable. That&rsquo;s the point.
            </p>

            <div className="mt-5">
              <label htmlFor="tiny-move" className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                My tiny move is…
              </label>
              <textarea
                id="tiny-move"
                className="w-textarea mt-2"
                rows={2}
                maxLength={280}
                value={tinyMoveText}
                onChange={(e) => setTinyMoveText(e.target.value)}
              />
            </div>

            <div className="mt-5">
              <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                I will do it…
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {TINY_MOVE_WHEN.map((w) => (
                  <button
                    key={w}
                    type="button"
                    className="wm-chip"
                    data-on={tinyMoveWhen === w}
                    onClick={() => setTinyMoveWhen(tinyMoveWhen === w ? "" : w)}
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                Where will I do it?
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {TINY_MOVE_WHERE.map((w) => (
                  <button
                    key={w}
                    type="button"
                    className="wm-chip"
                    data-on={tinyMoveWhere === w}
                    onClick={() => { setTinyMoveWhere(tinyMoveWhere === w ? "" : w); setTinyMoveCustomWhere(""); }}
                  >
                    {w}
                  </button>
                ))}
              </div>
              <input
                className="wm-input mt-2"
                style={{ maxWidth: 360, padding: "0.6rem 0.9rem", fontSize: "0.95rem" }}
                placeholder="or somewhere else…"
                value={tinyMoveCustomWhere}
                onChange={(e) => { setTinyMoveCustomWhere(e.target.value); if (e.target.value) setTinyMoveWhere(""); }}
              />
            </div>

            <div className="mt-5">
              <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                How doable does this feel? (1 = too hard · 5 = easy enough)
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    className="wm-chip"
                    data-on={tinyMoveConfidence === n}
                    onClick={() => setTinyMoveConfidence(n)}
                    aria-label={`Confidence ${n} of 5`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              {tinyMoveConfidence > 0 && tinyMoveConfidence < 3 && (
                <p className="mt-3 text-sm" style={{ color: "var(--wm-espresso)" }}>
                  Let&rsquo;s make it smaller. If it feels too hard, it&rsquo;s not tiny enough.
                </p>
              )}
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => { acceptTinyStep(); setCurrentStep("choose"); }}
                disabled={!tinyMoveText.trim()}
                className="w-btn w-btn-primary"
              >
                I&rsquo;ll try this
                <NextArrow size={20} color="#fff" />
              </button>
              <button type="button" onClick={shrinkTinyMove} className="w-btn w-btn-secondary">
                Make it smaller
              </button>
              <button type="button" onClick={goToPreviousStep} className="w-btn w-btn-link">
                Back
              </button>
            </div>
          </FlowPanel>
        )}

        {/* STEP 4 — CHOOSE */}
        {step === "choose" && (
          <FlowPanel panelRef={panelRef}>
            <div className="flex items-start gap-3">
              <TinyHeart />
              <h2
                className="text-3xl md:text-4xl"
                style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
              >
                What do you want to do with this?
              </h2>
            </div>
            <p className="mt-3 text-base" style={{ color: "var(--w-charcoal)" }}>
              Default is private. Nothing publishes unless you confirm it.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <button type="button" onClick={() => handleChooseAction("private")} className="wm-btn wm-btn-cream justify-start">Keep private</button>
              <button type="button" onClick={() => handleChooseAction("wall")} className="wm-btn wm-btn-pink justify-start">Post anonymously to the wall</button>
              <button type="button" onClick={() => handleChooseAction("saved")} className="wm-btn wm-btn-butter justify-start">Save for later</button>
              <button type="button" onClick={() => handleChooseAction("another")} className="wm-btn wm-btn-cream justify-start">Try another perspective</button>
              <button type="button" onClick={() => handleChooseAction("light")} className="wm-btn wm-btn-butter justify-start">Add to my Light list</button>
            </div>

            {confirmPost && (
              <div className="mt-6 rounded-2xl p-5" style={{ background: "var(--wm-warm-white)", border: "2px solid var(--wm-espresso)" }}>
                <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
                  Anonymous wall version
                </p>
                <h3 className="mt-1 text-xl" style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)" }}>
                  Do you want this to help someone else feel less alone?
                </h3>
                <p className="mt-2 text-sm" style={{ color: "var(--wm-espresso)" }}>
                  You can keep it private, or submit your anonymous words to the wall. Nothing publishes
                  automatically — a human moderator reviews it first.
                </p>
                <p className="mt-3 text-xs" style={{ color: "var(--wm-espresso)", opacity: 0.75 }}>
                  This is what others would see. We only remove identifying details or content that breaches safety guidelines.
                </p>
                <textarea
                  className="w-textarea mt-3"
                  rows={4}
                  maxLength={500}
                  value={wallText}
                  onChange={(e) => setWallText(e.target.value)}
                />
                <p className="mt-2 text-xs" style={{ color: "var(--wm-espresso)", opacity: 0.7 }}>
                  Your words stay yours. We only remove names, places, identifying details, or unsafe content.
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={submitToWall}
                    disabled={posting || !wallText.trim()}
                    className="wm-btn wm-btn-primary"
                  >
                    {posting ? (<><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</>) : "Submit for review"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setConfirmPost(false); setChosenAction(null); }}
                    className="wm-btn wm-btn-cream"
                  >
                    Keep private
                  </button>
                </div>
                {withheldNotice && (
                  <div className="mt-4 rounded-2xl p-4" style={{ background: "#F2C6C6", border: "2px solid var(--wm-wine, #E6844A)" }}>
                    <p className="text-sm" style={{ color: "var(--wm-espresso)" }}>{withheldNotice}</p>
                    <ul className="mt-2 list-disc pl-5 text-sm" style={{ color: "var(--wm-espresso)" }}>
                      <li>Immediate danger: your local emergency number (000 AU · 911 US · 999 UK)</li>
                      <li>Australia — Lifeline 13 11 14 · PANDA 1300 726 306</li>
                      <li>US — 988 Suicide &amp; Crisis Lifeline</li>
                      <li>UK — Samaritans 116 123</li>
                    </ul>
                  </div>
                )}
              </div>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" onClick={goToPreviousStep} className="w-btn w-btn-link">
                Back
              </button>
            </div>
          </FlowPanel>
        )}

        {/* STEP 5 — LIGHT */}
        {step === "light" && (
          <FlowPanel panelRef={panelRef}>
            <span className="wm-sticker wm-sticker-lime">Light</span>
            <h2
              className="mt-3 text-4xl md:text-5xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.1 }}
            >
              You said it. You saw it. You do not have to carry it the same way.
            </h2>

            <div className="mt-5 wm-card" style={{ background: "var(--wm-apricot)" }}>
              <p className="text-xs uppercase tracking-[0.16em]" style={{ color: "#FFFDF8", opacity: 0.85 }}>
                Your tiny next step
              </p>
              <p
                className="mt-2 text-2xl"
                style={{ fontFamily: "var(--font-display)", color: "#FFFDF8", lineHeight: 1.25 }}
              >
                {getTinyStepText(translation, translation?.values_bridge.selected_value)}
              </p>
              {tinyAccepted && (
                <p className="wm-marker mt-3 text-base" style={{ color: "#FFFDF8" }}>saved — you said you&rsquo;ll try this.</p>
              )}
            </div>

            {translation?.self_compassion_phrase && (
              <p className="wm-marker mt-4 text-xl" style={{ color: "var(--w-olive)" }}>
                say to yourself: &ldquo;{translation.self_compassion_phrase}&rdquo;
              </p>
            )}

            {chosenAction === "wall" && (
              <p className="mt-4 text-sm" style={{ color: "var(--w-charcoal)", opacity: 0.8 }}>
                If approved, your words will appear anonymously on the wall.
              </p>
            )}

            {/* One Tiny Good Thing — capture before leaving */}
            <div className="mt-6 wm-card" style={{ background: "var(--wm-warm-white)" }}>
              <span className="wm-sticker wm-sticker-lime">One Tiny Good Thing</span>
              <p className="mt-3 text-base" style={{ color: "var(--wm-espresso)" }}>
                Not toxic positivity. Just one small steady thing your brain can notice before you go.
              </p>
              <label htmlFor="tgt" className="sr-only">One tiny good thing</label>
              <textarea
                id="tgt"
                className="w-textarea mt-3"
                rows={2}
                maxLength={280}
                placeholder="One tiny thing I can notice is…"
                value={tinyGoodThing}
                onChange={(e) => { setTinyGoodThing(e.target.value); setTinyGoodThingSaved(false); }}
              />
              <div className="mt-2 flex flex-wrap gap-2">
                {[
                  "The room is quiet for one minute.",
                  "I asked for help instead of swallowing it.",
                  "The sky looked nice for half a second.",
                  "I got through today.",
                  "My coffee was warm.",
                  "I did one small thing.",
                ].map((s) => (
                  <button
                    key={s}
                    type="button"
                    className="wm-chip"
                    onClick={() => { setTinyGoodThing(s); setTinyGoodThingSaved(false); }}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={saveTinyGoodThing}
                  disabled={!tinyGoodThing.trim()}
                  className="wm-btn wm-btn-primary"
                >
                  Save this
                </button>
                {tinyGoodThingSaved && (
                  <span className="wm-marker text-lg" style={{ color: "var(--w-olive)" }}>
                    saved.
                  </span>
                )}
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" onClick={() => setCurrentStep("checkIn")} className="w-btn w-btn-primary">
                Continue to check-in
                <NextArrow size={20} color="#fff" />
              </button>
              <Link to="/confessions" className="w-btn w-btn-secondary">
                Visit the wall
              </Link>
              <button
                type="button"
                onClick={() => handleChooseAction("saved")}
                className="w-btn w-btn-link"
              >
                Save this reflection
              </button>
            </div>
          </FlowPanel>
        )}

        {/* STEP 7 — CHECK-IN */}
        {step === "checkIn" && (
          <FlowPanel panelRef={panelRef}>
            <span className="wm-sticker wm-sticker-lavender">Check-in</span>
            <h2
              className="mt-3 text-3xl md:text-4xl"
              style={{ fontFamily: "var(--font-display)", color: "var(--w-charcoal)", lineHeight: 1.15 }}
            >
              Did anything shift by one percent?
            </h2>
            <p className="mt-3 text-base" style={{ color: "var(--w-charcoal)" }}>
              No pressure for a miracle. We&rsquo;re just teaching your brain to notice what happens
              after a different move.
            </p>

            <div className="mt-5 grid gap-2">
              {CHECKIN_OPTIONS.map((o) => (
                <button
                  key={o.id}
                  type="button"
                  className="wm-chip justify-start"
                  data-on={checkInChoice === o.id}
                  onClick={() => setCheckInChoice(o.id)}
                  style={{ width: "100%", textAlign: "left" }}
                >
                  {o.label}
                </button>
              ))}
            </div>

            {checkInChoice === "couldnt" && (
              <p className="mt-4 text-sm" style={{ color: "var(--wm-espresso)" }}>
                That&rsquo;s useful information, not failure. The move was probably too big.
              </p>
            )}
            {checkInChoice === "smaller" && (
              <p className="mt-4 text-sm" style={{ color: "var(--wm-espresso)" }}>
                Good catch. Smaller is the whole point.
              </p>
            )}
            {checkInChoice === "noshift" && (
              <p className="mt-4 text-sm" style={{ color: "var(--wm-espresso)" }}>
                No shift is still data. You still practised choosing.
              </p>
            )}
            {(checkInChoice === "lighter" || checkInChoice === "chose") && (
              <p className="mt-4 text-sm" style={{ color: "var(--wm-espresso)" }}>
                Good. Tiny counts.
              </p>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              {(checkInChoice === "couldnt" || checkInChoice === "smaller") ? (
                <button
                  type="button"
                  onClick={() => { shrinkTinyMove(); setCurrentStep("tinyMove"); }}
                  className="w-btn w-btn-primary"
                >
                  Shrink the move
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => { saveLearning(); resetDumpFlow(); }}
                  disabled={!checkInChoice}
                  className="w-btn w-btn-primary"
                >
                  Save the learning
                </button>
              )}
              <Link to="/saved-notes" className="w-btn w-btn-secondary">
                Read saved notes
              </Link>
              <button type="button" onClick={resetDumpFlow} className="w-btn w-btn-link">
                Start another dump
              </button>
            </div>
          </FlowPanel>
        )}

        <p
          className="mt-8 text-xs"
          style={{ color: "var(--w-charcoal)", opacity: 0.7 }}
        >
          For reflection and support, not therapy, diagnosis, or emergency care.{" "}
          <Link to="/resources" className="underline">Need urgent help?</Link>
        </p>
      </section>
    </SiteLayout>
  );
}

function ChipGroup({
  label, options, value, onToggle,
}: {
  label: string;
  options: string[];
  value: string[];
  onToggle: (v: string) => void;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: "var(--wm-olive)" }}>
        {label}
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o}
            type="button"
            className="wm-chip"
            data-on={value.includes(o)}
            onClick={() => onToggle(o)}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}

const PART_BG: Record<string, string> = {
  "The Protector":          "var(--wm-lavender)",
  "The Alarm":              "var(--wm-apricot)",
  "The Fixer":              "var(--wm-butter)",
  "The Inner Critic":       "var(--wm-blush)",
  "The Tired Body":         "var(--wm-lavender)",
  "The Wise Self":          "var(--wm-lime)",
  "The Wounded Protector":  "var(--wm-blush)",
  "The Rational Planner":   "var(--wm-warm-white)",
  "The Creative Connector": "var(--wm-butter)",
  "The Wise Whole Self":    "var(--wm-lime)",
  "The Values Step":        "var(--wm-lime)",
};

function PartCardTile({ card, index }: { card: SelectedCard; index: number }) {
  const bg = PART_BG[card.name] ?? "var(--wm-warm-white)";
  const tilt = index % 2 === 0 ? -0.4 : 0.5;
  return (
    <div className="wm-card" style={{ background: bg, transform: `rotate(${tilt}deg)` }}>
      <span className="wm-sticker">{card.name}</span>
      {card.what_it_might_be_saying && (
        <p className="mt-3 italic" style={{ color: "var(--wm-espresso)" }}>
          &ldquo;{card.what_it_might_be_saying}&rdquo;
        </p>
      )}
      {card.what_it_might_need && (
        <p className="mt-2 text-sm" style={{ color: "var(--wm-espresso)" }}>
          <span className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>what it might need: </span>
          {card.what_it_might_need}
        </p>
      )}
      {card.soft_response && (
        <div className="mt-3 rounded-xl p-3" style={{ background: "var(--wm-warm-white)" }}>
          <p className="text-xs uppercase tracking-wider" style={{ color: "var(--wm-olive)" }}>a softer response</p>
          <p className="mt-1 text-sm" style={{ color: "var(--wm-espresso)" }}>{card.soft_response}</p>
        </div>
      )}
    </div>
  );
}
