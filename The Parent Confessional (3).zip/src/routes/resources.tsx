import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/layout/SiteLayout";

export const Route = createFileRoute("/resources")({
  head: () => ({
    meta: [
      { title: "Resources — Whelmful" },
      { name: "description", content: "Real-world support when this app is not enough. Crisis lines and parent support." },
      { property: "og:title", content: "Resources — Whelmful" },
      { property: "og:description", content: "Crisis and parent support lines for when reflection isn't enough." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="wm-bg mx-auto mt-12 max-w-2xl px-5 pb-20">
        <div className="wm-sticker wm-sticker-pink inline-block">Real-world support</div>
        <h1 className="wm-display mt-4 text-4xl sm:text-5xl">When this app is not enough.</h1>
        <div className="wm-card mt-6 p-6">
          <p className="text-[color:var(--wm-espresso)]/85">
            Whelmful offers AI-supported reflection. It is not therapy, diagnosis, crisis support, or medical advice. If you are in immediate danger — to yourself, your baby, or anyone else — please contact emergency services or a trusted person nearby now.
          </p>
          <div className="mt-6 space-y-4">
            <div>
              <h2 className="wm-display text-2xl">Australia</h2>
              <ul className="mt-2 space-y-2 text-[color:var(--wm-espresso)]/85">
                <li><a href="tel:000" className="underline"><strong>Triple Zero — 000.</strong></a> Immediate danger.</li>
                <li><a href="tel:131114" className="underline"><strong>Lifeline — 13 11 14.</strong></a> 24/7 crisis &amp; suicide prevention.</li>
                <li><a href="tel:1300726306" className="underline"><strong>PANDA — 1300 726 306.</strong></a> Perinatal Anxiety &amp; Depression Australia.</li>
                <li><a href="tel:1800737732" className="underline"><strong>1800RESPECT — 1800 737 732.</strong></a> Family &amp; sexual violence support.</li>
                <li><a href="tel:139276" className="underline"><strong>13YARN — 13 92 76.</strong></a> Crisis support for Aboriginal &amp; Torres Strait Islander people.</li>
              </ul>
            </div>
            <div>
              <h2 className="wm-display text-2xl">Outside Australia</h2>
              <p className="mt-2 text-[color:var(--wm-espresso)]/85">
                Please use your country's emergency number and a verified local crisis line. We don't list numbers we haven't confirmed — we'd rather send you nowhere than send you wrong.
              </p>
            </div>
          </div>
        </div>
        <div className="mt-6 flex gap-3">
          <Link to="/" className="wm-btn wm-btn-cream">Back home</Link>
          <Link to="/app" className="wm-btn wm-btn-primary">Open Whelmful</Link>
        </div>
      </section>
    </SiteLayout>
  ),
});
