import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { WhelmfulTranslator } from "@/components/translator/WhelmfulTranslator";

export const Route = createFileRoute("/translator")({
  head: () => ({
    meta: [
      { title: "Body-Brain Translator — Whelmful" },
      {
        name: "description",
        content:
          "Dump the spiral. Get back a softer translation of what your body and brain might be trying to say. Not therapy. Not diagnosis. Just a plain-language pattern translator.",
      },
      { property: "og:title", content: "Body-Brain Translator — Whelmful" },
      {
        property: "og:description",
        content:
          "Dump the spiral. Get back a softer translation of what your body and brain might be trying to say.",
      },
    ],
  }),
  component: TranslatorPage,
});

function TranslatorPage() {
  const [busy, setBusy] = useState(false);
  return (
    <SiteLayout>
      <section className="w-container w-section" style={{ paddingTop: "1.5rem" }}>
        <header className="mx-auto max-w-3xl text-center">
          <span
            className="wm-sticker wm-sticker-lavender"
            style={{ display: "inline-block" }}
          >
            Body-Brain Translator · Private by default
          </span>
          <h1
            className="mt-4 text-4xl md:text-6xl"
            style={{ fontFamily: "var(--font-display)", color: "var(--wm-espresso)", lineHeight: 1.05 }}
          >
            Body-Brain Translator.
          </h1>
          <p
            className="mx-auto mt-4 max-w-2xl text-base md:text-lg"
            style={{ color: "var(--wm-espresso)", opacity: 0.85 }}
          >
            Dump the spiral. Get back a softer translation of what your body and brain might be
            trying to say.
          </p>
          <p
            className="mx-auto mt-3 max-w-2xl text-xs uppercase tracking-[0.18em]"
            style={{ color: "var(--wm-olive)" }}
          >
            Not a diagnosis. Not a therapy tool. Just a plain-language pattern translator.
          </p>
        </header>

        <div className="mx-auto mt-8 max-w-4xl">
          <WhelmfulTranslator onBusyChange={setBusy} />
        </div>

        <p
          className="mx-auto mt-10 max-w-2xl text-center text-xs"
          style={{ color: "var(--wm-espresso)", opacity: 0.6 }}
        >
          Nothing publishes anywhere unless you tap “Post anonymously” and confirm.
          You can also keep what you wrote private, or{" "}
          <Link to="/app" className="underline">
            move through the full Dump flow
          </Link>
          .{busy ? " · listening…" : ""}
        </p>
      </section>
    </SiteLayout>
  );
}