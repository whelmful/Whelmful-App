import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { TiltCard } from "@/components/visual/TiltCard";
import { StickerLabel } from "@/components/visual/StickerLabel";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Staff sign-in — The Sanctuary" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await (mode === "signin"
        ? supabase.auth.signInWithPassword({ email, password })
        : supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/admin/moderation` } }));
      if (res.error) throw res.error;
      toast.success(mode === "signin" ? "Welcome back." : "Account created. Ask an admin to grant you moderator role.");
      nav({ to: "/admin/moderation" });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <SiteLayout>
      <section className="mx-auto mt-16 max-w-md px-5">
        <TiltCard tilt={-1} background="var(--cream)">
          <StickerLabel variant="pink" rotation={-4}>Staff only</StickerLabel>
          <h1 className="display-xl mt-3 text-[var(--charcoal)]">Sign in.</h1>
          <p className="mt-2 text-sm text-[var(--charcoal)]/70">
            This area is for The Sanctuary moderators. Public confessions are handled here.
          </p>
          <form onSubmit={submit} className="mt-5 space-y-3">
            <input
              type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email"
              className="w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3"
            />
            <input
              type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" minLength={6}
              className="w-full rounded-2xl border-[3px] border-[var(--charcoal)] bg-[var(--paper)] p-3"
            />
            <button disabled={busy} className="btn-chunky w-full disabled:opacity-50">
              {busy ? "…" : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>
          <button onClick={() => setMode(mode === "signin" ? "signup" : "signin")} className="mt-3 text-sm underline">
            {mode === "signin" ? "Need an account?" : "Already have one?"}
          </button>
        </TiltCard>
      </section>
    </SiteLayout>
  );
}